#!BPY
"""
Name: '_Wall_beta_248'
Blender: 248
Group: 'Wizards'
Tooltip: 'Make a wall.'
"""
__author__  = 'Johan Badenhorst'
__url__     = ('blender', 'http://wiki.blender.org/index.php/Scripts/Manual/Misc/Walls_%26_Tiles')
__version__ = '1.0'
__bpydoc__  = """\
Creates pretty good walls.
This script is depreciated & returns several errors.
It is here to show capabilities of python scripting in Blender.
"""

#/***************************************************************************
# *   Copyright (C) Walls & Tiles by Johan Badenhorst                                   *
# *                                                   *
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General Public License as published by  *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# *   This program is distributed in the hope that it will be useful,       *
# *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
# *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
# *   GNU General Public License for more details.                          *
# *                                                                         *
# *   You should have received a copy of the GNU General Public License     *
# *   along with this program; if not, write to the                         *
# *   Free Software Foundation, Inc.,                                       *
# *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
# ***************************************************************************/
# Walls & Tiles by Johan Badenhorst
# ---------------------------------
# Version 1.0 Beta
# ----------------- 
#
# Uses Random.py from Python 2.2
# Created using Blender 2.28a
#
#
# Feel free to use this script, 
# just give me credit and let me 
# know if it helped you in any way.
#
# 
# 
# Features: 
# 
# Completed:
# ----------
# - Bevel ( Not really a bevel just a rounder edge)
# - Grout
# - Random brick dimesion variations
# - Random colour variation
# - Horizontal / Verticle option
#
# NOTE:
# -----
# Remember to recalc wall normals after
# it is created so that they show up 
# correctly in faceselect mode
  

import Blender
from Blender import NMesh
from math import *
from Blender.Draw import *
from Blender.BGL import *
import random
from random import *

 # Events
PCreateWall = 10
Slide       = 11
TIsBricks   = 13
TIsTiles    = 14
THasGrout   = 15
THasMaterials = 16
TColVar    = 17
THor       = 18
TVert      = 19

 # Current Scene
sce = Blender.Scene.getCurrent()

 # Wall type
IsBricks = Create(1)
IsTiles = Create(0)
HasGrout = Create(0)
HasMaterials = Create(1)

 # Wall dimensions
Length = Create(20.0)
Height = Create(10.0)

 # Wall Colour
Red = Create(0.5)
Green = Create (0.1)
Blue = Create(0.05)

 # Brick dimensions
BrickLength  = Create(1.5)
BrickHeight  = Create(0.5)
BrickBreadth = Create(0.6)
BrickBevel   = Create(0.0)

 # Brick dimesion variances
LengthVar  = Create(0.05)
HeightVar  = Create(0.05)
BreadthVar = Create(0.25)

 # Colour settings
HasColVar      = Create(1)
ColourVar      = Create(0.1)

 # Horizontal or Vertical
IsVertical = Create(1)
IsHorizontal = Create(0)

 # Grout variables
Spacing   = Create(0.1)
GroutColour = 1, 1, 1

def MakeBrick(x, y, z, l, b, h, bev, grout, vertical):

    # BrickMesh
   me = NMesh.GetRaw()

    # Adjust Brick size to allow for grout
   if vertical == 1:
     l = l - grout
     h = h - grout
   else:
     l = l - grout
     b = b - grout

   if bev <= 0:   
       # Vertice coordinates
      verts = ([x + l / 2, y + h / 2, z + b / 2],
               [x - l / 2, y + h / 2, z + b / 2],
               [x - l / 2, y - h / 2, z + b / 2],
               [x + l / 2, y - h / 2, z + b / 2],
               [x + l / 2, y + h / 2, z - b / 2],
               [x - l / 2, y + h / 2, z - b / 2],
               [x - l / 2, y - h / 2, z - b / 2],
               [x + l / 2, y - h / 2, z - b / 2])

       # Add vertices to mesh
      for vert in verts:
         me.verts.append(NMesh.Vert(vert[0], vert[2], vert[1]))

       # Create and add faces to mesh
      face = NMesh.Face()
      faceVerts = 0, 1, 2, 3
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 4, 5, 6, 7   
      for i in range(4,8):
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 1, 0, 4, 5
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 2, 6, 7, 3
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 3, 7, 4, 0
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 5, 1, 2, 6
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)
   else:
  
       # Vertice coordinates
      verts = ([(x + l / 2) - bev, (y + h / 2) - bev, z + b / 2],
               [(x - l / 2) + bev, (y + h / 2) - bev, z + b / 2],
               [(x - l / 2) + bev, (y - h / 2) + bev, z + b / 2],
               [(x + l / 2) - bev, (y - h / 2) + bev, z + b / 2],
               [(x + l / 2) - bev, (y + h / 2) - bev, z - b / 2],
               [(x - l / 2) + bev, (y + h / 2) - bev, z - b / 2],
               [(x - l / 2) + bev, (y - h / 2) + bev, z - b / 2],
               [(x + l / 2) - bev, (y - h / 2) + bev, z - b / 2],

               [(x + l / 2) - bev, y + h / 2, (z + b / 2) - bev],
               [(x - l / 2) + bev, y + h / 2, (z + b / 2) - bev],
               [(x - l / 2) + bev, y - h / 2, (z + b / 2) - bev],
               [(x + l / 2) - bev, y - h / 2, (z + b / 2) - bev],
               [(x + l / 2) - bev, y + h / 2, (z - b / 2) + bev],
               [(x - l / 2) + bev, y + h / 2, (z - b / 2) + bev],
               [(x - l / 2) + bev, y - h / 2, (z - b / 2) + bev],
               [(x + l / 2) - bev, y - h / 2, (z - b / 2) + bev],

               [x + l / 2, (y + h / 2) - bev, (z + b / 2) - bev],
               [x - l / 2, (y + h / 2) - bev, (z + b / 2) - bev],
               [x - l / 2, (y - h / 2) + bev, (z + b / 2) - bev],
               [x + l / 2, (y - h / 2) + bev, (z + b / 2) - bev],
               [x + l / 2, (y + h / 2) - bev, (z - b / 2) + bev],
               [x - l / 2, (y + h / 2) - bev, (z - b / 2) + bev],
               [x - l / 2, (y - h / 2) + bev, (z - b / 2) + bev],
               [x + l / 2, (y - h / 2) + bev, (z - b / 2) + bev])

       # Add vertices to mesh
      for vert in verts:
         me.verts.append(NMesh.Vert(vert[0], vert[2], vert[1]))
 
       # Create and add faces to mesh
      face = NMesh.Face()
      faceVerts = 0, 3, 2, 1
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 4, 5, 6, 7
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 12, 8, 9, 13
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 14, 10, 11, 15
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 20, 23, 19, 16
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 21, 17, 18, 22
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 9, 17, 21, 13
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 13, 21, 5
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 13, 5, 4, 12
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 12, 4, 20
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 12, 20, 16, 8
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 8, 16, 0
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 8, 0, 1, 9
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 9, 1, 17
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 1, 2, 18, 17
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 21, 22, 6, 5
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 4, 7, 23, 20
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 16, 19, 3, 0
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 19, 11, 3
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 3, 11, 10, 2
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 2, 10, 18
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 18, 10, 14, 22
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 22, 14, 6
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 6, 14, 15, 7
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 7, 15, 23
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

      face = NMesh.Face()
      faceVerts = 23, 15, 11, 19
      for i in faceVerts:
         face.v.append(me.verts[i])
      me.faces.append(face)

   return me

def MakeWall(Name, Vertical):
   WallMesh = NMesh.GetRaw()
     
    # Calculate Number of rows and colums
   if Vertical == 1:
      Rows = Height.val / BrickHeight.val
      Columns = Length.val / BrickLength.val
   else:
      Rows = Height.val / BrickBreadth.val
      Columns = Length.val / BrickLength.val


    # Set offset for zig-zagging of bricks
   if IsBricks.val == 1:
      RowOffset = BrickLength.val / 4
   else:
      RowOffset = 0

   for r in range(-Rows / 2, Rows / 2):
      for c in range(-Columns / 2, Columns/ 2):
         if Vertical == 1:
            CurrentMesh = MakeBrick(c * (BrickLength.val) + RowOffset, r * (BrickHeight.val),
                                    0.0, 
                                    BrickLength.val + random() * LengthVar.val, 
                                    BrickBreadth.val + random() * BreadthVar.val,
                                    BrickHeight.val + random() * HeightVar.val,
                                    BrickBevel.val,
                                    Spacing.val,
                                    Vertical)
         else:
            CurrentMesh = MakeBrick(c * (BrickLength.val) + RowOffset, 0.0,
                                    r * (BrickBreadth.val), 
                                    BrickLength.val + random() * LengthVar.val, 
                                    BrickBreadth.val + random() * BreadthVar.val,
                                    BrickHeight.val + random() * HeightVar.val,
                                    BrickBevel.val,
                                    Spacing.val,
                                    Vertical)
    

          # Add brick vertices and face to wall and
          # set brick colour
         ThisVar = (random() * 255.0) * (ColourVar.val)
         ThisVar = ThisVar - (0.5 * ColourVar.val * 255)
         R = int(Red.val * 255) + ThisVar
         G = int(Green.val * 255) + ThisVar
         B = int(Blue.val * 255) + ThisVar
   
          # Keep within limits
         if R > 255:
            R = 255
         if R < 1:
            R = 1
         if G > 255:
            G = 255
         if G < 1:
            G = 1
         if B > 255:
            B = 255
         if B < 1:
            B = 1

         for vert in CurrentMesh.verts:
            WallMesh.verts.append(vert)
         for face in CurrentMesh.faces:
            if HasColVar.val == 1:
               face.col = [NMesh.Col(R, G, B), 
                           NMesh.Col(R, G, B),
                           NMesh.Col(R, G, B),
                           NMesh.Col(R, G, B)]

            WallMesh.faces.append(face)
         CurrentMesh.hasVertexColours(1)

       # Flip row offset for zig zag
      RowOffset = -RowOffset

    # Create grout
   if HasGrout.val == 1:
      if IsVertical.val == 1:
         if IsBricks.val == 1:
            GroutHeight = BrickHeight.val * Rows + (BrickHeight.val / 4)
            GroutLength = BrickLength.val * Columns - (BrickLength.val / 2)  
         else:
            GroutHeight = BrickHeight.val * Rows + (BrickHeight.val / 4)
            GroutLength = BrickLength.val * Columns - (BrickLength.val)  
         Grout = MakeBrick(0.0 - (BrickLength.val / 2), 
                  0.0 - (BrickHeight.val / 2), 
                  0.0, 
                  GroutLength, 
                  BrickBreadth.val - BreadthVar.val,  
                  GroutHeight, 
                  0.0, 0.0, 0)
      else:
         if IsBricks.val == 1:
            GroutHeight = BrickHeight.val - (2 * HeightVar.val)
            GroutLength = BrickLength.val * Columns - (BrickLength.val / 2) 
            GroutBreadth = BrickBreadth.val * Rows + (BrickBreadth.val / 2)
         else:
            GroutHeight = BrickHeight.val - (2 * HeightVar.val)
            GroutLength = BrickLength.val * Columns - (BrickLength.val)  
            GroutBreadth = BrickBreadth.val * Rows + (BrickBreadth.val / 2)
         Grout = MakeBrick(0.0 - (BrickLength.val / 2), 
                  0.0, 
                  0.0 - (BrickBreadth.val / 2), 
                  GroutLength, 
                  GroutBreadth,  
                  GroutHeight, 
                  0.0, 0.0, 0)
  
       
       # Create grout material
      if HasMaterials.val == 1:
         HasGroutMat = 0
         for mat in Blender.Material.Get():
            if mat.getName() == "GroutMat":
               HasGroutMat = 1
         if HasGroutMat == 1:
            GroutMat = Blender.Material.Get("GroutMat")
            Grout.materials.append(GroutMat)
         else:  
            GroutMat = Blender.Material.New("GroutMat")
            GroutMat.setRGBCol(0.5, 0.5, 0.5)
            GroutMat.setSpec(0.1)
            GroutMat.setHardness(20) 
            GroutMat.setMode('Shadow', 'Traceable')
            Grout.materials.append(GroutMat)
      NMesh.PutRaw(Grout)

    # Create Material
   HasWallMat = 0
   if HasMaterials.val == 1:
      for mat in Blender.Material.Get():
         if mat.getName() == "WallMat":
            HasWallMat = 1
      if HasWallMat == 1:
         WallMat = Blender.Material.Get("WallMat")
         if HasColVar.val == 1:
            WallMat.setMode('VColPaint', 'Shadow', 'Traceable')
         else:
            WallMat.setMode('Shadow', 'Traceable')
         WallMat.setRGBCol(Red.val, Green.val, Blue.val)
         WallMat.setSpec(0.1)
         WallMat.setHardness(20)
         WallMesh.materials.append(WallMat)

      else:
         WallMat = Blender.Material.New("WallMat")
         WallMat.setRGBCol(Red.val, Green.val, Blue.val)
         WallMat.setSpec(0.1)
         WallMat.setHardness(20)
         if HasColVar.val == 1:
            WallMat.setMode('VColPaint', 'Shadow', 'Traceable')
         else:
            WallMat.setMode('Shadow', 'Traceable')
         WallMesh.materials.append(WallMat)  
   
    # Set Brick Colours
   WallMesh.hasVertexColours(1)

    # Add Wall To Scene      
   NMesh.PutRaw(WallMesh)
   WallMesh.update(1)

        
 # ------ GUI ------
def draw():
   global Length, Height, IsBricks, IsTiles, HasGrout, BrickLength
   global BrickBreadth, BrickHeight, BreadthVar, HeightVar, LengthVar
   global BrickBevel, Spacing, MaxBevel, HasMaterials, Red, Green, Blue
   global ColourVar, HasColVar, IsHorizontal, IsVertical

    # ------ Clear Color ------
   glClearColor(0.8, 0.8, 0.8, 1.0)
   glColor3f(0,0,0)
   glClear(GL_COLOR_BUFFER_BIT)


    # ------ Create GUI ------
    # Surface settings
   glRasterPos2f(120, 480)
   Text("Surface Settings")
   IsHorizontal = Toggle("Horizontal", THor, 180, 445, 70, 20, IsHorizontal.val)
   IsVertical = Toggle("Vertical", TVert, 260, 445, 70, 20, IsVertical.val)
   IsBricks = Toggle("Bricks", TIsBricks, 20, 410, 50, 20, IsBricks.val)
   IsTiles = Toggle("Tiles", TIsTiles, 80, 410, 50, 20, IsTiles.val)
   HasGrout = Toggle("Grout", THasGrout, 280, 410, 50, 20, HasGrout.val)
   HasMaterials = Toggle("Materials", THasMaterials, 210, 410, 60, 20, HasMaterials.val)
   Length = Slider("Length ", Slide, 20, 375, 310, 20, Length.val, 1.0, 100.0, 0)
   if IsVertical.val == 1:
      Height = Slider("Height ", Slide, 20, 350, 310, 20, Height.val, 1.0, 100.0, 0)
   else:
      Height = Slider("Bredth ", Slide, 20, 350, 310, 20, Height.val, 1.0, 100.0, 0)

   Red = Slider("Red ", Slide, 20, 320, 230, 20, Red.val, 0.0, 1.0, 0)
   Green = Slider("Green ", Slide, 20, 295, 230, 20, Green.val, 0.0, 1.0, 0)
   Blue = Slider("Blue ", Slide, 20, 270, 230, 20, Blue.val, 0.0, 1.0, 0)

   glColor3f(Red.val, Green.val, Blue.val) 

   glRectf(260, 270, 330, 340)
  
   glColor3i(1,1,1)  

    # Set slider maxes
   MaxBevel = ((BrickHeight.val + BrickLength.val + BrickBreadth.val) / 3) / 5

   if IsVertical.val == 1:
      MaxHeight = Height.val / 3
      MaxLength = Length.val / 3
      MaxBredth = 3.0
      MaxLVar = Spacing.val / 2      
      MaxHVar = Spacing.val / 2      
      MaxBVar = BrickBreadth.val / 2
   else:
      MaxHeight = 3.0
      MaxLength = Length.val / 3
      MaxBredth = Height.val / 3
      MaxLVar = Spacing.val / 2      
      MaxBVar = Spacing.val / 2      
      MaxHVar = BrickHeight.val / 2

    # Brick / Tile Settings
   glRasterPos2f(115, 235)
   Text("Brick / Tile Settings")
   HasColVar = Toggle("Col Var", TColVar, 20, 205, 50, 20, HasColVar.val)
   ColourVar = Slider("Col Var ", Slide, 75, 205, 250, 20,ColourVar.val, 0.0, 1.0, 0)

   lr = Red.val - (ColourVar.val / 2)
   lg = Green.val - (ColourVar.val / 2)
   lb = Blue.val - (ColourVar.val / 2)

   mr = Red.val
   mg = Green.val 
   mb = Blue.val

   hr = Red.val + (ColourVar.val / 2)
   hg = Green.val + (ColourVar.val / 2)
   hb = Blue.val + (ColourVar.val / 2)

   glColor3f(lr, lg, lb)
   glRectf(20, 180, 120, 200)
   glColor3f(mr, mg, mb)
   glRectf(125, 180, 225, 200)
   glColor3f(hr, hg, hb)
   glRectf(230, 180, 330, 200)

   glColor3f(0,0,0)

   Spacing = Slider("Spacing ", Slide, 20, 155, 310, 20, Spacing.val, 0.0, 1.0, 0)
   BrickBevel = Slider("Bevel ", Slide, 20, 130, 310, 20, BrickBevel.val, 0.0, MaxBevel, 0)
   BrickLength = Slider("Length ", Slide, 20, 100, 150, 20, BrickLength.val, 0.1, MaxLength, 0)
   BrickHeight = Slider("Height ", Slide, 20, 75, 150, 20, BrickHeight.val, 0.1, MaxHeight, 0)
   BrickBreadth = Slider("Bredth ", Slide, 20, 50, 150, 20, BrickBreadth.val, 0.1, MaxBredth, 0)

   LengthVar = Slider("L Var ", Slide, 180, 100, 150, 20, LengthVar.val, 0.0, MaxLVar, 0)
   HeightVar = Slider("H Var ", Slide, 180, 75, 150, 20, HeightVar.val, 0.0, MaxHVar, 0)
   BreadthVar = Slider("B Var ", Slide, 180, 50, 150, 20, BreadthVar.val, 0.0, MaxBVar, 0)

    # Create Button
   Button("Create", PCreateWall, 25, 20, 50, 20, "Create Wall")

    # ------ Other GUI Stuff ------ 
    # Credits
   glRasterPos2f(20, 500)
   Text("Walls & Tiles 0.6 Alpha  by Johan Badenhorst")
    # Exit Button
   Button("Exit", 1, 275, 20, 50, 20, "Close Walls & Tiles")

 # ------ Events ------     
def event(evt, val):
   if (evt == QKEY and not val):
      Exit()

 # ------ Button Events ------
def bevent(evt):

    # Exit
   if (evt == 1):
      Exit()

    # Create Wall
   elif evt == PCreateWall:
      MakeWall("Wall", IsVertical.val)
      Blender.Redraw()
 
    # Toggle Surface Type
   elif evt == TIsBricks:
      if IsBricks.val == 1:
         IsTiles.val = 0
      else:
         IsTiles.val = 1
      Register(draw, event, bevent)

   elif evt == TIsTiles:
      if IsTiles.val == 1:
         IsBricks.val = 0
      else:
         IsBricks.val = 1
      Register(draw, event, bevent)

    # Toggle surface orientation
   elif evt == THor:
      if IsHorizontal.val == 1:
         IsVertical.val = 0
      else:
         IsVertical.val = 1
      Register(draw, event, bevent)

   elif evt == TVert:
      if IsVertical.val == 1:
         IsHorizontal.val = 0
      else:
         IsVertical.val = 1
      Register(draw, event, bevent)
   

    # Update slider values
   elif evt == Slide:
      Register(draw, event, bevent)

 # ------ Register Events ------
Register(draw, event, bevent)