#!BPY
# -*- coding: latin-1 -*-
"""
Name: '_Tesselate_248_link'
Blender: 248
Group: 'Wizards'
Tip: 'Create Tesselated Objects. open in Help/script help browser/wizards for link'
"""
__author__  = 'JM Soler (jms)'
__url__     = ('http://jmsoler.free.fr/didacticiel/blender/tutor/python_wireshadows.htm', 
'http://wiki.blender.org/index.php/Scripts/Manual/Wizards/tesselate8',
'http://www.zoo-logique.org/3D.Blender/newsportal/thread.php?group=3D.Blender')
__version__ = '90f'
__bpydoc__  = """\
Description: A beautiful Shell generator.
you need to download this script then paste the script, below this section.
Open the text editor & load/open =shell_blendv90f.
Then paste the script, below this bpydoc.
"""
########################################################################################

#----------------------------------------------
# wire and tesselate project
# jean-michel soler january/october  2000
#                     -> october 2004 
#----------------------------------------------
# Official page :
#   http://jmsoler.free.fr/didacticiel/blender/tutor/python_wireshadows.htm
# Communicate problems or errors on:
#   http://www.zoo-logique.org/3D.Blender/newsportal/thread.php?group=3D.Blender
#---------------------------------------------
#---------------------------------------------
# Insert script minus the header on the next line: