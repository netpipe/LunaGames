#!BPY

""" Registration info for Blender menus: <- these words are ignored
Name: '_BarGraph_248'
Blender: 248
Group: 'Misc'
Tip: 'Create a bar graph from a data set'
"""

__author__ = 'Jesse McMillan - jessethemid'
__version__ = '2.42'
__email__=["Jesse, mcmillanje@gmail.com"]
__url__ = ("blender", "http://wiki.blender.org/index.php/Scripts/Manual/Misc/Bar-Graph-O-Matic")

__bpydoc__ = """\
This script makes a Bar Graph.

Usage:
	
Add the script to your blender/scripts directory
Execute this script from the "Scripts->Misc" menu and choose Bar Graph.
This script is currently producing console errors, but it still works.
"""


#############################################################################
# ------------------------------------------------------------------------- #
# ***** BEGIN GPL LICENSE BLOCK *****                                       #
#                                                                           #
# Copyright (C) 2006: Jesse McMillan                                        #
#                                                                           #
# This program is free software; you can redistribute it and/or             #
# modify it under the terms of the GNU General Public License               #
# as published by the Free Software Foundation; either version 2            #
# of the License, or (at your option) any later version.                    #
#                                                                           #
# This program is distributed in the hope that it will be useful,           #
# but WITHOUT ANY WARRANTY; without even the implied warranty of            #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the             #
# GNU General Public License for more details.                              #
#                                                                           #
# You should have received a copy of the GNU General Public License         #
# along with this program; if not, write to the Free Software Foundation,   #
# Inc.  59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.           #
#                                                                           #
# ***** END GPL LICENCE BLOCK *****                                         #
# --------------------------------------------------------------------------#
#############################################################################

"""
many thanks to Cambo and R3gis, i learned everything i know from their scripts
-except what i learned from other sources
"""



################################
import Blender
from Blender import *
from Blender.Draw import *
from Blender.BGL import *
import random #for random data sets...
import graph
from graph import *






# Interface

#variables to change
global refl, matbool, shade, s, data, scale, c1, c2, c3, matc, backcol, wire
#create buttons
refl = Create(1)
matbool = Create(0)
shade = Create(1)
numvals = Create(5)
data = Create("1,2,3,4,5,4.5,3.5,2.5,1.5,0.5")
scale = Create(1.0)
c1 = Create(.8,.8,.25)
c2 = Create(.25,.25,.8)
c3 = Create(.25,.8,.25)
matc = Create(3)
backcol = Create(.9,.9,.9)
wire = Create(1)

# Events
EVENT_NOEVENT = 1
EVENT_GRAPH = 2
EVENT_UPDATE = 3
EVENT_EXIT = 4
EVENT_RANDOM = 5

def draw():
	#variables and events
	global refl, matbool, shade, s, data, scale, c1, c2, c3, matc, backcol, wire
	global EVENT_NOEVENT, EVENT_BEVEL, EVENT_UPDATE, EVENT_EXIT

	#materials
	refl = Toggle("Reflect", EVENT_NOEVENT,310,101,100,20,refl.val,"Whether to make the backdrop reflective")
	shade = Toggle("Shade", EVENT_NOEVENT,10,121,50,20,shade.val,"Shaded or shadeless?")
	wire = Toggle("Outline", EVENT_NOEVENT,60,121,50,20,wire.val,"Add Wire Outline?")
	#colors
	c1 = ColorPicker(EVENT_NOEVENT,10,76,32,20,c1.val,"Color one")
	c2 = ColorPicker(EVENT_NOEVENT,44,76,32,20,c2.val,"Color two")
	c3 = ColorPicker(EVENT_NOEVENT,78,76,32,20,c3.val,"Color three")	
	name = "Color Options %t|cycle %x3|use color 3 %x2|use color 2 %x1|use color 1 %x0"
	matc = Menu(name,EVENT_NOEVENT,10,101,100,20,matc.val)
	glRasterPos2i(310,80)
	Text("BackdropCol")
	backcol = ColorPicker(EVENT_NOEVENT,385,76,25,20,backcol.val,"Backdrop Color")
	
	#data stuff
	glRasterPos2i(165,90)
	Text("^WARNING! buggy^", "small")
	scale = Number("ScaleDN:", EVENT_NOEVENT,140,101,140,20,scale.val, 0.1, 10.0, "Scale Factor")
	data = String("data:",EVENT_NOEVENT,15,51,390,20,data.val,399,"enter data in the format [1,2,3,4]")
	glRasterPos2i(5,57)
	Text("[", "large")
	glRasterPos2i(408,57)
	Text("]", "large")
	#command buttons

	PushButton("EXIT", EVENT_EXIT,10,10,50,20,"this really should be obvious")
	PushButton("Graph", EVENT_GRAPH,140,10,140,20,"Graph the data set")
	
	

def event(evt, val):
	if ((evt == QKEY or evt == ESCKEY) and not val): Exit()

def bevent(evt):
	if evt == EVENT_EXIT		: Exit()
	elif evt == EVENT_GRAPH:
		write(scale.val, c1.val, c2.val, c3.val, matc.val, backcol.val, shade.val, data.val, refl.val, wire.val)
		Blender.Redraw()
		Exit()

Register(draw, event, bevent)