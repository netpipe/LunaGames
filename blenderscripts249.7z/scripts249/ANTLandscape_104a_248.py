#!BPY
"""
Name: '_A.N.T.Landscape v.1.04a_248'
Blender: 248
Group: 'Wizards'
Tip: 'Create landscape mesh.'
"""

__author__  = 'Jimmy Hazevoet'
__url__     = ('http://wiki.blender.org/index.php/Scripts/Manual/Wizards/ANTLandscape','elysiun')
__version__ = '1.04a'
__bpydoc__  = """\
Readme:
v.1.04:
_ New G.U.I.
_ New noise types like: 
Double_Terrain, 
StatsByAlt_Terrain, 
slickRock, 
ditorted_heteroTerrain, 
vlNoise_turbulence, 
and many more.

New fractalized Effect functions.     
Effect types such as: gradient,
waves and bumps, dome, piramide, 
squares, grid, shattered rocks, 
lunar, and many more.
     
Bias types: Sin, Cos, Tri, Saw, 
and Default(no bias).
    
For example the 'Rings' effect 
with 'Sin Bias' makes 'Rings' 
and 'Default Bias' makes 'Dome'.
The Effect 'Mix factor' Slider gives control over how much of the Effect is vissible, 
-1.0=noise, 0.0=average, 1.0=effect
this slider controls also the 'Warp amount' if mix type 'Warp' is selected.

Image effect: mix image with noise
_ IPOCurve Filter: use Ipo curve to filter terrain height.
I know it's a bit strange to use animation curves for landscape modelling, (actualy i want a curves panel in my G.U.I. but i dont know how to do that)
the downside of this method is that you have this 'Empty' moving around in your scene, so put it on another layer and 'Pin' the Ipo block so that it stays visible.
Usage:
Add one 'Empty' Object to your scene, now add one Loc Key at Frame 1, go to Frame 101 (UpArrow ten times),
move the 'Empty' +100 units in X+ direction and add another Loc Key, open the Ipo Curve Editor Window, rename this IpoBlock if you want,
Copie the first curve to buffer and Paste it in the empty slots (from top to bottom), now you can edit the curves freely.
(use the 'Pin' option to keep the curves visible while other objects are selected)
Set the CurveLength and CurveHeight Button value's according to the length and height of the selected curve.
A curve filter is very versatile when it comes to 'height' filtering.

_ PreView in UV/Image Editor Window:
The preview image is now rendered as Blender.Image and will be saved to file directory as 'ANTview_size.tga'
you have to select 'ANTview_size.tga' in the UV/Image Editor Window
now it's posible to render and save a large HeightMap image (you can also create nice texture images when the VertCol gradient is enabled),
! If you Change the preview image Size a New Blender.Image object is created. (one for size 256, one for size 512 one for.....) !

_ VertexColours: use any image as colour gradient.
This function actualy uses one 'row' of pixels from a image to produce the color gradient,
Make one or more custom gradient images with the Gimp or any other graphics software, the gradients must go from left to right (left is bottom and right is top.
you only need one row of pixels so you can put 10 gradients in a 256*10 image.(higher resolutions like 512*n or 1024*n gives smoother result) 
Set Window DrawMode 'Textured' , and set the 'VCol Paint' option in the Materials panel !

_ Mesh Tiles: Create large scale terrains.

_ Vertices Selection: select flat areas.

_ Keyboard HotKeys:
SPACE = Update mesh.
R = Randomise.
V = Redraw preview.

_ and more...
"""

# --------------------------------------------------------------------------
# ANT Landscape Creater by Jimmy Haze
# --------------------------------------------------------------------------
# ***** BEGIN GPL LICENSE BLOCK *****
#
# Copyright (C) 2006 Jimmy Haze
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****
# --------------------------------------------------------------------------
#
##  Execute Script: Alt P
#

################################################################################################################
# Another Noise Tool 'Landscape' v.1.04  ( build and tested in Blender 2.41 )
# Jimmy Hazevoet April/May 2006
# license: Do whatever you want with it.
################################################################################################################

################################################################################################################
## BugFix: Sept./2006  v.1.04a
# _ Image Effect did not worked well with tiled mesh.
# Fixed (now use Freq. and Loc. buttons to scale and position image).
##
################################################################################################################

################################################################################################################

################################################################################################################


import Blender
from Blender import * 
from math import *
from Blender.Noise import * 
from Blender.Draw import *
from Blender.BGL import *
from Blender import Image
import string
import BPyMathutils
from BPyMathutils import genrand
scene = Scene.getCurrent()


###---------------------------------------------------------------------------
##--------------------------------------------------------------------------
# Customise: ---------------------------------------------------------------

# G.U.I.:
guitabs = [ Create( 0 ), Create( 1 ), Create( 0 ), Create( 0 ), Create( 0 ) ]  # G.U.I. Tabs
FullScreen = Create( 1 )            # FullScreen
size_x  = 320                       # gui x size 
size_y  = 280                       # gui y size 
lightgrey  = [ 0.76, 0.76, 0.76 ]   # gui col.
grey       = [ 0.6, 0.6, 0.6 ]      # panel col.
background = [ 0.7, 0.7, 0.7, 1.0 ] # background col.
black      = [ 0.0, 0.0, 0.0 ]      # text col.

# Names:
TerName     = Create( 'Terrain' )   # Terrain Name
previewname = Create( 'ANTview' )   # Preview / Heightmap Image Name

# Mesh Resolutions:
resolution = [ '16','32', '40', '64', '80', '100', '128', '160', '200', '256', '320', '400', '512', '640', '800', '960', '1024' ]

## Mesh Tiles: ##
#
# Tiles: Number of Positions is Number of Tiles:
# 3 tiles:
tiles_3 = [ ( 0 , 0 ), ( -1 , 0 ), ( +1 , 0 ) ]
# 3*3: 9 tiles:
tiles_9 = [ ( 0 , 0 ), ( -1 , 0 ), ( +1 , 0 ), ( -1 , -1 ), ( 0 , -1 ), ( +1 , -1 ), ( -1 , +1 ), ( 0 , +1 ), ( +1 , +1 ) ]
# 5*5: 25 tiles:
tiles_25 = [ ( 0 , 0 ), ( -2 , -2 ), ( -1 , -2 ), ( 0 , -2 ), ( +1 , -2 ) , ( +2 , -2 ), ( -2 , -1 ), ( -1 , -1 ), ( 0 , -1 ), ( +1 , -1 ), ( +2 , -1 ), ( -2 , 0 ), ( -1 , 0 ), ( +1 , 0 ) , ( +2 , 0 ), ( -2 , +1 ), ( -1 , +1 ), ( 0 , +1 ), ( +1 , +1 ), ( +2 , +1 ), ( -2 , +2 ), ( -1 , +2 ), ( 0 , +2 ) , ( +1 , +2 ), ( +2 , +2 ) ]

# list of tile positions to choose from:
tiles_positions = [ tiles_3, tiles_9, tiles_25 ]

# re-scale (for falloff and preview) set this according to the x number of tiles:
tile_rescale = [ 3 , 3 , 5 ]

#---------------------------------------------------------------------------
##--------------------------------------------------------------------------
###---------------------------------------------------------------------------

columns = 10  # gui columns
rows    = 13  # gui rows

effect_image  = 'Load and Select image.'
colgrad_image = 'Load and Select gradient image.'

ipoblockname = ''
thiscurve = []
selectedcurve = 0

phi = 3.14159265359

No_Evt   = 1
Btn_Evt  = 2
Upd_Evt  = 3
Rndm_Evt = 4
Load_Evt = 5
Sel_Evt  = 6
Grad_Sel_Evt = 61
Save_Evt = 7
Rend_Evt = 8
End_Evt  = 9
Scrn_Evt = 15
Im_Evt   = 16
gt0_Evt  = 10
gt1_Evt  = 11
gt2_Evt  = 12
gt3_Evt  = 13
gt4_Evt  = 14

noisetypemenu  = "Noise type: %t|multiFractal %x0|ridgedMFractal %x1|hybridMFractal %x2|heteroTerrain %x3|fBm %x4|turbulence %x5|Voronoi turb. %x6|vlNoise turb. %x7|noise %x8|cellNoise %x9| %l|Marble %x10|lava_multiFractal %x11|slopey_noise %x12|duo_multiFractal %x13|distorted_heteroTerrain %x14|slickRock %x15|terra_turbulence %x16|rocky_fBm %x17|StatsByAlt_Terrain %x18|Double_Terrain %x19"
noisebasismenu = "Basis %t|Blender Original%x0|Original Perlin%x1|Improved Perlin%x2|Voronoi_F1%x3|Voronoi_F2%x4|Voronoi_F3%x5|Voronoi_F4%x6|Voronoi_F2-F1%x7|Voronoi Crackle%x8|CellNoise%x9"
voronitypemenu = "Voronoi type %t|Distance %x0|Distance Squared %x1|Manhattan %x2|Chebychev %x3|Minkovsky 1/2 %x4|Minkovsky 4 %x5|Minkovsky %x6"
tBasismodemenu = "Terrain basis mode: %t|noise %x0|ridged noise %x1|vlNoise %x2|ridged vlNoise %x3"

effecttypemenu = ['Effect Type %t','No Effect %x0','Image %x1','Turbulence %x2','vlNoise %x3','Marble %x4','Gradient %x5','Waves and Bumps %x6','ZigZag %x7','Wavy %x8','Sine Bump %x9','Dots %x10','Rings / Dome %x11','Spiral %x12','Square / Piramide %x13','Blocks %x14','Grid %x15','Tech %x16','Crackle %x17','Sparse Cracks %x18','Shattered Rocks %x19','Lunar %x20','Cosine noise %x21','Spike noise %x22','Stone noise %x23','Flat Turb %x24','Flat Voroni %x25' ]
mixtypemenu = ['Mix Type %t','Effect only %x0','%l','Mix %x1','Add %x2','Subtract %x3','Multiply %x4','Difference %x5','Screen %x6','addmodulo %x7','Minimum %x8','Maximum %x9','%l','Warp Effect %x10','Warp Noise %x11']

biastypemenu  = "Bias %t|Sin bias %x0|Cos bias %x1|Tri bias %x2|Saw bias %x3|Default (no bias)%x4"
sharptypemenu = "Sharpen %t|Soft %x0|Sharp %x1|Sharper %x2"

filtermodemenu = "Filter Mode %t|No Filter %x0| %l|Default Filters %x1|IPOCurve Filter %x2"
filtertypemenu = "Filter Type %t|Default Terrace %x0|Sharper Terrace %x1|Rounded Terrace %x2|Posterise Mixed %x3|Posterise %x4|Layered Peaks %x5|Peaked %x6|Smooth-thing %x7|Sin bias %x8|Cos bias %x9|Tri bias %x10|Saw bias %x11"
falloftypemenu = "Edge Falloff %t|No Edge Falloff %x0| %l|Soft Falloff %x1|Default Falloff %x2|Hard Falloff %x3|Linear Falloff Y %x4|Linear Falloff X %x5|Diagonal Falloff + %x6|Diagonal Falloff - %x7|Square %x8|Round %x9"

randomtypemenu = "Random type: %t|setRandomSeed() : Blender.Noise %x0|Rand() : Blender.Mathutils %x1|genrand() : BPyMathutils MersenneTwister %x2"

##--------------------------------------------------
def Set_ReSet_Values():
	global Quality, Quad_Tri, Smooth, vSelRange, maketiles
	global iScale, Offset, Invert, NSize, Sx, Sy, Lx, Ly
	global NType, Basis, musgr, vlnoi, vlnoiTwo, voron, turbOne, turbTwo, marbleOne, marbleTwo, tBasismod
	global Effect_Ctrl, Min, Max, Falloff, Filter_Mode, Def_Filter_Ctrl, Ipo_Filter_Ctrl
	global RandMod, RSeed, rand_H, rand_S, rand_L
	global AutoUpd, PreView, ViewiScale, vcolours, vcolGradRow, gradScale
	
	AutoUpd  = Create( 0 )
	PreView = [ Create( 0 ), Create( 7 ), Create( 0 ) ]
	ViewiScale = Create( 1.0 )
	vcolours = Create( 0 )
	vcolGradRow = Create( 0 )
	gradScale = Create( 1.0 )
	## Mesh controls:
	Quality  = Create( 7 )
	Quad_Tri = Create( 0 )
	Smooth   = Create( 0 )
	vSelRange = Create( 0.0 )
	maketiles = [ Create( 0 ), Create( 0 ) ]
	## Coords controls:
	iScale = [ Create( 1.0 ), Create( 1.0 ), Create( 0.25) ]
	Offset = [ Create( 0.0 ), Create( 0.0), Create( 0.0) ]
	Invert = [ Create( 0 ), Create( 0 ), Create( 0 ) ]
	NSize = [ Create( 1.0 ), Create( 2.0 ) ]
	Sx = [ Create( 1.0 ), Create( 1.0 ) ]
	Sy = [ Create( 1.0 ), Create( 1.0 ) ]
	Lx = [ Create( 0.0 ), Create( 0.0 ) ]
	Ly = [ Create( 0.0 ), Create( 0.0 ) ]
	## Noise controls:
	NType = Create( 0 )
	Basis = [ Create( 0 ), Create( 0 ) ]
	musgr = [ Create( 1.0 ), Create( 2.0 ), Create( 8 ), Create( 1.0 ), Create( 1.0 ), Create( 0.5 ) ]
	vlnoi = [ Create( 1.0 ), Create( 0 ) ]
	vlnoiTwo = [ Create( 1.0 ), Create( 0 ) ]
	voron = [ Create( 0 ), Create( 2.5 ) ]
	turbOne = [ Create( 3 ), Create( 0 ), Create( 0.5 ), Create( 2.0 ) ]
	turbTwo = [ Create( 3 ), Create( 0 ), Create( 0.5 ), Create( 2.0 ) ]
	marbleOne = [ Create( 6 ), Create( 0 ), Create( 2.0 ), Create( 0 ), Create( 0 ), Create( 1.0 ) ]
	marbleTwo = [ Create( 6 ), Create( 0 ), Create( 2.0 ), Create( 0 ), Create( 0 ), Create( 1.0 ) ]
	tBasismod = Create(0)
	## Effect controls:
	Effect_Ctrl = [ Create( 0 ), Create( 2 ), Create( 0.0 ), Create( 0 ), Create( 0.0 )  , Create( 0 ), Create( 2.0 )  , Create( 0.5 ) ]
	## Filter controls:
	Min = Create( 0.0 )
	Max = Create( 1.0 )
	Falloff = [ Create( 0 ), Create( 1.0 ), Create( 1.0 ), Create( 0 ) , Create( 0 ) ]
	Filter_Mode = Create( 0 )
	Def_Filter_Ctrl = [ Create( 0 ), Create( 3.0 ) ]
	Ipo_Filter_Ctrl = [ Create( "ObIpo" ), Create( 0 ), Create( 100.0 ), Create( 100.0 ) ]
	## Randomise noise buttons:
	RandMod = Create( 1 )
	RSeed   = Create( 0 )
	rand_H  = Create( 0 )
	rand_S  = Create( 0 )
	rand_L  = Create( 1 )

##-------------------------

Set_ReSet_Values()

##-------------------------

###---------------------------------------------------------------------------
## Randomise:
##-------------------------

# Generate random numbers:
def randnum(low,high):
	global RandMod, RSeed
	if RandMod.val == 0:
		# Noise.random setRandomSeed
		s = setRandomSeed( RSeed.val )
		num = random()
		num = num*(high-low)
		num = num+low
	elif RandMod.val == 1:
		# Mathutils.Rand
		num = Mathutils.Rand( 0.0, 1.0 )
		num = num*(high-low)
		num = num+low
	else:
		# BPyMathutils  Mersenne Twister genrand
		num = genrand()
		num = num*(high-low)
		num = num+low
	return num

# Randomise noise: height, size and location:
def randomiseNoise():
	global rand_H, rand_S, rand_L, NSize, iScale, Offset, Invert, Lx, Ly, Sx, Sy
	if rand_H.val !=0:
		iScale[2] = Create( randnum( 0.1  , 1.0 ) )
		Offset[2] = Create( randnum(-0.25 , 0.25 ) )
		#Invert[2] = Create( randnum( 0 , 2 ) )		
	if rand_S.val !=0:
		NSize[0]  = Create( randnum( 0.2 , 3.0 ) )
		#Sx[0]     = Create( randnum( 0.75 , 1.25 ) )
		#Sy[0]     = Create( randnum( 0.75 , 1.25 ) )
	if rand_L.val !=0:
		Lx[0]     = Create( randnum( -1000 , 1000 ) )
		Ly[0]     = Create( randnum( -1000 , 1000 ) )


###----------------------------------------------------------------------------------------------------
## G.U.I.: text,backpanel,panel and frame
#--------------------------------------------------
def draw_Text( ( x, y ), text, color, size ):
	glColor3f( color[0],color[1],color[2] )
	glRasterPos2d(x,y)
	txtsize = 'small', 'normal', 'large'
	Text( text, txtsize[ size ] )
def draw_BackPanel( text, x, y, w, h, colors ):
	glColor3f( colors[0]*0.76, colors[1]*0.76, colors[2]*0.76 )
	glRecti( x, h, w, h+20 )
	glColor3f( colors[0], colors[1], colors[2] )
	glRecti( x, y, w, h )
	glColor3f( colors[0], colors[1], colors[2] )
	glRasterPos2d( x+10, h+5 )
	Text( text, 'small' )
def draw_Panel( x, y, w, h, colors ):
	glColor3f( colors[0], colors[1], colors[2] )
	glRecti( x,y, w,h )
def draw_Frame( text, x, y, w, h, color ):
   glColor3f( color[0], color[1], color[2] )
   glRasterPos2i(x+3,h-3)
   Text(text ,'small')
   stringwidth = GetStringWidth( text,'small' )
   glColor3f( color[0], color[1], color[2]  )
   glBegin(Blender.BGL.GL_LINE_STRIP)
   glVertex2i(x,h)
   glVertex2i(x,y)
   glVertex2i(w,y)
   glVertex2i(w,h)
   glVertex2i(x+stringwidth+10,h)
   glEnd()


###----------------------------------------------------------------------------------------------------
## Buttons:
#----------------------------------------------------------------------------------------------------

###-------------------------
## Mesh Buttons:
#
def MeshButtons( col, row, width, height ):
	global TerName, AutoUpd, Quality, Quad_Tri, Smooth, vSelRange, maketiles

	draw_Text( ( col[2], row[1] ), 'Make Duplicate: [ Shift D ] in 3D View.', black, 0 )
	TerName = String( "OB:", No_Evt,     col[2], row[3], width[5], height[2] ,TerName.val,20, "Object name. (New name generates new mesh)" )
	Quality  = Menu( 'Vertices:  Resolution  n*n %t|' + '|'.join( resolution ), No_Evt ,col[2], row[5], width[5], height[2], Quality.val, "Verts: Number of Vertices ( n*n )" )
	smoothmnu = "Faces: %t|Solid %x0|Smooth %x1"
	Smooth   = Menu( smoothmnu, No_Evt ,col[2], row[6], width[2], height[1], Smooth.val, "Faces: SetSmooth / SetSolid" )
	facemnu   = "Faces: %t|Quads %x0|Triangles %x1"
	Quad_Tri = Menu( facemnu,   No_Evt ,col[5], row[6], width[2], height[1], Quad_Tri.val, "Faces: Quads / Triangles" )
	vSelRange = Slider( "VertSel:", No_Evt, col[2], row[8], width[5], height[2], vSelRange.val,  0.0, 10.0, 0 , "Vertices Selection: Select flat areas (higher value selects more slopes)" )
	if maketiles[0].val !=0:
		maketiles[1] = Number("" , No_Evt, col[6], row[10], width[1], height[2], maketiles[1].val,   0, len(tiles_positions)-1 , "Tiles: Select Number of tiles" )
		maketiles[0] = Toggle( str(len(tiles_positions[maketiles[1].val])) + " Tiles",    No_Evt, col[2], row[10], width[3], height[2], maketiles[0].val, "Tiled Mesh: Generate Terrain Tiles (for making large scale terrain)")
	else:
		maketiles[0] = Toggle("Tiles", No_Evt, col[2], row[10], width[5], height[2], maketiles[0].val, "Tiled Mesh: Generate Terrain Tiles (for making large scale terrain)")

###-------------------------
## Noise Buttons:
#
def NoiseButtons( col, row, width, height ):
	global NSize, iScale, Offset, Invert, Lx, Ly, Sx, Sy
	global Ha, La, Oc, Of, Ga, Basis, NType, musgr, vlnoi, voron, turbOne, tBasismod 
	global Depth, Hard, Amp, Freq, vlBasis, Distort, VFunc, VExp, VDep, marbleOne
	global RandMod, RSeed, rand_H, rand_S, rand_L
	
	bth = height[1]/2+5
	iScale[0] = Number("iScale:", Btn_Evt, col[5], row[2]+bth, width[3], height[1], iScale[0].val,   -10.0, 10.0 , "Noise: Intensity Scale. ( To scale terrain height, use 'HeightScale' in the Height panel )" )
	Invert[0] = Toggle("Inv.",    Btn_Evt, col[9], row[2]+bth, width[0], height[1], Invert[0].val, "Noise: Invert")
	Offset[0] = Number("Offset:", Btn_Evt, col[5], row[3]+bth, width[4], height[1], Offset[0].val,   -10.0, 10.0 , "Noise: Offset " )
	NSize[0] = Number("Noise Size:",Btn_Evt, col[5], row[5], width[4], height[2], NSize[0].val, 0.001, 10.0 , "Noise Size" )
	Sx[0]    = Number("Size X:", Btn_Evt, col[5], row[6], width[4], height[1], Sx[0].val,    0.001, 10.0 , "Size X" )
	Sy[0]    = Number("Size Y:", Btn_Evt, col[5], row[7], width[4], height[1], Sy[0].val,    0.001, 10.0 , "Size Y" )
	Lx[0]    = Number("Loc X:",  Btn_Evt, col[5], row[9], width[4], height[1], Lx[0].val,  -1000.0, 1000.0 , "Loc X" )
	Ly[0]    = Number("Loc Y:",  Btn_Evt, col[5], row[10],width[4], height[1], Ly[0].val,  -1000.0, 1000.0 , "Loc Y" )

	NType = Menu( noisetypemenu,        Btn_Evt, col[0], row[2], width[4], height[2], NType.val, "Noise type" )
	if NType.val == 6:
		voron[0] = Menu( voronitypemenu,    Btn_Evt, col[0], row[3], width[4], height[1], voron[0].val, "Voronoi type" )
	else:
		Basis[0] = Menu( noisebasismenu,    Btn_Evt, col[0], row[3], width[4], height[1], Basis[0].val, "Noise Basis" )

	if NType.val in [0,1,2,3,4,11,12,13,14,15,17,18,19]:
		musgr[0] = Slider( "H: ",     Btn_Evt, col[0], row[5], width[4], height[1], musgr[0].val,  0.0, 3.0, 0 ,  "H" )
		musgr[1] = Slider( "Lacu: ",  Btn_Evt, col[0], row[6], width[4], height[1], musgr[1].val,  0.0, 6.0, 0 ,  "Lacunarity" )
		musgr[2] = Slider( "Octs: ",  Btn_Evt, col[0], row[4], width[4], height[1], musgr[2].val,    0, 12,  0 , "Octaves" )
	if NType.val in [1,2,3,13,14,15,18,19]:
		musgr[3] = Slider( "Offst: ", Btn_Evt, col[0], row[7], width[4], height[1], musgr[3].val,  0.0, 6.0, 0 ,  "Offset" )
	if NType.val in [1,2,13,15,18]:
		musgr[4] = Slider( "Gain: ",  Btn_Evt, col[0], row[8], width[4], height[1], musgr[4].val,  0.0, 6.0, 0 ,  "Gain" )
	if NType.val == 19:
		musgr[5] = Slider( "Thresh: ",  Btn_Evt, col[0], row[8], width[4], height[1], musgr[5].val,  0.001, 2.0, 0 ,  "Threshold" )
	if NType.val in [5,6,7,16]:
		turbOne[0] = Number(  "Depth:",   Btn_Evt, col[0], row[4], width[4], height[1], turbOne[0].val, 0, 12, "Octaves")
		turbOne[1] = Toggle("Hard noise", Btn_Evt, col[0], row[5], width[4], height[1], turbOne[1].val,        "Soft noise / Hard noise")
		turbOne[2] = Slider(    "Amp:",   Btn_Evt, col[0], row[6], width[4], height[1], turbOne[2].val, 0.0, 3.0, 0, "Ampscale ")
		turbOne[3] = Slider(   "Freq:",   Btn_Evt, col[0], row[7], width[4], height[1], turbOne[3].val, 0.0, 6.0, 0, "Freqscale")
	if NType.val in [18,19]:
		tBasismod = Menu( tBasismodemenu, Btn_Evt, col[0], row[9], width[4], height[1], tBasismod.val, "Terrain basis mode.")
	if NType.val == 6:
		if voron[0].val == 6:
			voron[1] = Slider( "Exp: ", Btn_Evt, col[0], row[8], width[4], height[1], voron[1].val, 0.0,10.0, 0, "Minkovsky exponent")
	if NType.val in [7,11,12,14]:
		vlnoi[0] = Slider( "Dist: ",   Btn_Evt, col[0], row[8], width[4], height[1], vlnoi[0].val,  0.0, 10.0, 0 , "Distort" )
	if NType.val == 7:
		vlnoi[1] = Menu(noisebasismenu,Btn_Evt, col[0], row[9], width[4], height[1], vlnoi[1].val, "Distortion Noise")
	if NType.val == 10:
		marbleOne[0] = Number(  "Depth: ", Btn_Evt, col[0], row[6], width[4], height[1], marbleOne[0].val, 0, 12, "Octaves")
		marbleOne[2] = Slider(  "Turb: ",  Btn_Evt, col[0], row[7], width[4], height[1], marbleOne[2].val,  0.0,20.0, 0, "Turbulence ")
		marbleOne[3] = Menu( biastypemenu, Btn_Evt ,col[0], row[4], width[4], height[1], marbleOne[3].val, "Bias")
		marbleOne[5] = Slider(  "ReScale: ",  Btn_Evt, col[0], row[8], width[4], height[1], marbleOne[5].val,  0.0,20.0, 0, "ReScale")
		if marbleOne[3].val != 4:
			marbleOne[4] = Menu(sharptypemenu, Btn_Evt ,col[0], row[5], width[4], height[1], marbleOne[4].val, "Sharpen")

	RandMod = Menu( randomtypemenu, No_Evt, col[0], row[10], width[1], height[1], RandMod.val, "Random Type" )
	rand_H = Toggle("H",No_Evt ,col[2], row[10], width[0], height[1], rand_H.val, "Randomise Terrain Height ( in Height panel )")
	rand_S = Toggle("S",No_Evt ,col[3], row[10], width[0], height[1], rand_S.val, "Randomise Noise Size")
	rand_L = Toggle("L",No_Evt ,col[4], row[10], width[0], height[1], rand_L.val, "Randomise Noise Location")

###-------------------------
## Effect Buttons:
#
def EffectButtons( col, row, width, height ):
	global Effect_Type, Effect_Ctrl, Blend_Effect
	global NSize, iScale, Offset, Invert, Lx, Ly, Sx, Sy
	global BasisTwo, turbTwo, marbleTwo, vlnoiTwo
	
	Effect_Ctrl[0] = Menu( '|'.join( effecttypemenu ), Btn_Evt, col[0], row[2], width[4], height[2], Effect_Ctrl[0].val, "Effect: Type" )
	if Effect_Ctrl[0].val != 0:
		Effect_Ctrl[1] = Menu( '|'.join( mixtypemenu ),    Btn_Evt, col[5], row[2], width[4], height[2], Effect_Ctrl[1].val, "Mix: Type" )
		Effect_Ctrl[2] = Slider("Mix: ", Btn_Evt, col[5], row[3], width[4], height[1], Effect_Ctrl[2].val, -1.0, 1.0, 0, "Mix factor / Warp amount" )
		iScale[1] = Number("iScale:", Btn_Evt, col[5], row[4], width[3], height[1], iScale[1].val,   -20.0, 20.0 , "Effect: Intensity Scale " )
		Invert[1] = Toggle("Inv.",    Btn_Evt, col[9], row[4], width[0], height[1], Invert[1].val, "Effect: Invert")
		Offset[1] = Number("Offset:", Btn_Evt, col[5], row[5], width[4], height[1], Offset[1].val,   -20.0, 20.0 , "Effect: Offset " )
		NSize[1] = Number("Frequency:",    Btn_Evt, col[5], row[6], width[4], height[1], NSize[1].val, 0.001, 100.0, "Effect Frequency ( Scale )" )
		Sx[1]    = Number("Freq X:",  Btn_Evt, col[5], row[7], width[4], height[1],  Sx[1].val,    -50.0, 50.0 , "Effect Frequency X ( ScaleX )" )
		Sy[1]    = Number("Freq Y:",  Btn_Evt, col[5], row[8], width[4], height[1],  Sy[1].val,    -50.0, 50.0 , "Effect Frequency Y ( ScaleY )" )
		Lx[1]    = Number("Loc X:",   Btn_Evt, col[5], row[9], width[4], height[1],  Lx[1].val, -1000.0, 1000.0 , "Effect Loc X" )
		Ly[1]    = Number("Loc Y:",   Btn_Evt, col[5], row[10], width[4], height[1], Ly[1].val, -1000.0, 1000.0 , "Effect Loc Y" )

		if Effect_Ctrl[0].val == 1:
			PushButton("Load Image",   Load_Evt, col[0], row[4], width[4], height[2] , "Load Image")
			PushButton("Select Image", Sel_Evt,  col[0], row[6], width[4], height[3] , "Select Image")
			draw_Text( ( col[0]+5, row[7] ), effect_image, black, 1 )
		
		if Effect_Ctrl[0].val in [2,3,4]:
				Basis[1] = Menu( noisebasismenu,   Btn_Evt, col[0], row[3], width[4], height[1], Basis[1].val, "Basis" )
		if Effect_Ctrl[0].val == 2:
				turbTwo[0] = Number(  "Depth:",   Btn_Evt, col[0], row[4], width[4], height[1], turbTwo[0].val, 1, 12, "Octaves")
				turbTwo[1] = Toggle("Hard noise", Btn_Evt, col[0], row[5], width[4], height[1], turbTwo[1].val,        "Hard noise")
				turbTwo[2] = Slider(    "Amp:",   Btn_Evt, col[0], row[6], width[4], height[1], turbTwo[2].val, 0.0, 3.0, 0, "Ampscale ")
				turbTwo[3] = Slider(   "Freq:",   Btn_Evt, col[0], row[7], width[4], height[1], turbTwo[3].val, 0.0, 6.0, 0, "Freqscale")
		if Effect_Ctrl[0].val == 3:
				vlnoiTwo[1] = Menu(noisebasismenu,Btn_Evt, col[0], row[4], width[4], height[1], vlnoiTwo[1].val, "Distortion Noise")
				vlnoiTwo[0] = Slider( "Dist: ",   Btn_Evt, col[0], row[5], width[4], height[1], vlnoiTwo[0].val,  0.0, 10.0, 0 , "Distort" )
		if Effect_Ctrl[0].val == 4:
				marbleTwo[0] = Number(  "Depth: ", Btn_Evt, col[0], row[6], width[4], height[1], marbleTwo[0].val, 1, 12, "Octaves")
				marbleTwo[2] = Slider(  "Turb: ",  Btn_Evt, col[0], row[7], width[4], height[1], marbleTwo[2].val,  0.0,20.0, 0, "Turbulence")
				marbleTwo[3] = Menu( biastypemenu, Btn_Evt ,col[0], row[4], width[4], height[1], marbleTwo[3].val, "Bias")
				marbleTwo[5] = Slider(  "ReScale: ",  Btn_Evt, col[0], row[8], width[4], height[1], marbleTwo[5].val,  0.0,20.0, 0, "ReScale")
				if marbleTwo[3].val != 4:
					marbleTwo[4] = Menu( sharptypemenu,Btn_Evt ,col[0], row[5], width[4], height[1], marbleTwo[4].val, "Sharpen")
		if Effect_Ctrl[0].val > 4:
				Effect_Ctrl[5] = Number("Depth:",  Btn_Evt, col[0], row[4], width[4], height[1], Effect_Ctrl[5].val,   0, 12   ,  "Fractalize Effect: Octaves" )
				Effect_Ctrl[4] = Number("Distort:",Btn_Evt, col[0], row[7], width[4], height[1], Effect_Ctrl[4].val, 0.0, 10.0 ,  "Distort Effect: Distortion amount" )
				Effect_Ctrl[6] = Slider("Freq:",   Btn_Evt, col[0], row[5], width[4], height[1], Effect_Ctrl[6].val, 0.0, 6.0, 0, "Fractalize Effect: Frequency" )
				Effect_Ctrl[7] = Slider("Amp:",    Btn_Evt, col[0], row[6], width[4], height[1], Effect_Ctrl[7].val, 0.0, 3.0, 0, "Fractalize Effect: Amplitude" )
				if Effect_Ctrl[0].val < 17:
					Effect_Ctrl[3] = Menu( biastypemenu, Btn_Evt ,col[0], row[3], width[4], height[1], Effect_Ctrl[3].val, "Effect bias")



###-------------------------
## Filter Buttons:
#
def FilterButtons( col, row, width, height ):
	global iScale, Offset, Invert, Min, Max, Falloff
	global Filter_Mode, Def_Filter_Ctrl, Ipo_Filter_Ctrl

	iScale[2] = Number("Height:", Btn_Evt, col[5], row[2], width[3], height[2], iScale[2].val,   -10.0, 10.0 , "Terrain Height:  Scale" )
	Invert[2] = Toggle("Inv.",    Btn_Evt, col[9], row[2], width[0], height[2], Invert[2].val, "Terrain Height:  Invert")
	Offset[2] = Number("Offset:", Btn_Evt, col[5], row[3], width[4], height[1], Offset[2].val,   -10.0, 10.0 , "Terrain Height:  Offset" )
	Falloff[0] = Menu( falloftypemenu, Btn_Evt ,col[5], row[5], width[4], height[2], Falloff[0].val, "Terrain Height:  Edge falloff")
	if Falloff[0].val !=0:
		Falloff[1] = Number("X:",   Btn_Evt, col[5], row[6], width[1], height[1], Falloff[1].val , 0.01, 10.0 , "Edge falloff:  X Size" )		
		Falloff[2] = Number("Y:",   Btn_Evt, col[8], row[6], width[1], height[1], Falloff[2].val , 0.01, 10.0 , "Edge falloff:  Y Size" )
		Falloff[4] = Toggle("Inv.", Btn_Evt, col[7], row[6], width[0], height[1], Falloff[4].val, "Edge falloff:  Invert")
		Falloff[3] = Toggle("Edge At Sealevel", Btn_Evt, col[5], row[7], width[4], height[1], Falloff[3].val, "Edge falloff:  Edge at Sealevel")
	Max = Number("Plateau:", Btn_Evt, col[5], row[8], width[4], height[1], Max.val, Min.val, 1.0 , "Terrain Height:  Clamp Max. ( Plateau )" )
	Min = Number("Sealevel:", Btn_Evt, col[5], row[9], width[4], height[1], Min.val, -1.0, Max.val , "Terrain Height:  Clamp Min. ( Sealevel )" )
	Filter_Mode = Menu( filtermodemenu, No_Evt ,col[0], row[2], width[4], height[2], Filter_Mode.val, "Filter:  Mode")
	if Filter_Mode.val ==1:
		Def_Filter_Ctrl[0] = Menu( filtertypemenu, Btn_Evt ,col[0], row[4], width[4], height[2], Def_Filter_Ctrl[0].val, "Filter:  Type")
		Def_Filter_Ctrl[1] = Number("Amount: ",    Btn_Evt, col[0], row[5], width[4], height[1], Def_Filter_Ctrl[1].val, 0.1, 25.0 , "Filter:  Amount" )
	elif Filter_Mode.val ==2:
		Ipo_Filter_Ctrl[0] = String("IP:",             No_Evt,  col[0], row[4], width[4], height[2], Ipo_Filter_Ctrl[0].val,20, "Ipo datablock name" )
		Ipo_Filter_Ctrl[1] = Number("Selected Curve:", No_Evt, col[0], row[6], width[4], height[3], Ipo_Filter_Ctrl[1].val, 0, 29, "Selected curve" )
		Ipo_Filter_Ctrl[2] = Number("Curve Length:", No_Evt, col[0], row[7], width[4], height[1], Ipo_Filter_Ctrl[2].val, 0.0, 1000.0, "X: Length (number of frames) of the selected curve." )
		Ipo_Filter_Ctrl[3] = Number("Curve Height:", No_Evt, col[0], row[8], width[4], height[1], Ipo_Filter_Ctrl[3].val, 0.0, 1000.0, "Y: Height (offset) of the selected curve." )

###-------------------------
## Option Buttons:
#
def OptionButtons( col, row, width, height ):
	global PreView, previewname, ViewiScale, vcolours, vcolGradRow, gradScale

	PreView[0] = Toggle("Preview Image", No_Evt, col[0], row[2], width[4], height[2], PreView[0].val, "Preview image: On/Off (See image in UV/Image Editor Window)")
	if PreView[0].val !=0:	
		previewname = String( "IM:", No_Evt,     col[0], row[3], width[2], height[1] ,previewname.val, 8, "Preview / HeightMap Image Name." )
		ViewiScale = Number("", No_Evt,      col[0], row[4], width[1], height[1], ViewiScale.val, 0.0, 10.0, "Preview image: intensity scale ( brightness )")
		PushButton( "Redraw",  Im_Evt, col[2], row[4], width[2], height[1] , "Preview: Generate/Update image ( KEY: V )")
		PreView[1] = Menu( 'Preview_size: %t|' + '|'.join( resolution ), No_Evt ,col[3], row[3], width[1], height[1], PreView[1].val, "Preview image size.(Every image size will generate its own image object)")
		draw_Text( ( col[5], row[1] ), 'Select the preview image', black, 0 )
		draw_Text( ( col[5], row[2] ), 'IM: ' + previewname.val + '_' + resolution[PreView[1].val-1] + '.tga', black, 0 )
		draw_Text( ( col[5], row[3] ), 'in UV/Image Editor Window.', black, 0 )
	
	draw_Frame( 'Vertex Colour:', col[1], row[10], col[9]-5, row[5], black )
	draw_Text( ( col[2], row[6] ), 'Selected: '+colgrad_image , black, 0 )
	PushButton(          "Load",                     Load_Evt,     col[2], row[7], width[2], height[1] , "VertCol: Load colour gradient image")
	PushButton(          "Select",                   Grad_Sel_Evt, col[5], row[7], width[2], height[1] , "VertCol: Select colour gradient image")
	vcolours    = Toggle("Enable 'VertCol' Gradient",No_Evt,      col[2], row[8], width[5], height[1], vcolours.val, "VertCol: Enable VertexColours gradient ( Set Window DrawMode 'Textured', and set Material 'VCol Paint' on! )")
	if vcolours.val !=0:
		vcolGradRow = Number("Select Row:",     Btn_Evt,      col[2], row[9], width[2], height[1], vcolGradRow.val, 0, 1024 , "VertCol: Select row of pixels")
		gradScale = Number("Scale:",            Btn_Evt,      col[5], row[9], width[2], height[1], gradScale.val, 0.01, 10.0, "VertCol: Scale gradient")


###---------------------------------------------------------------------------
###--------------------------------------------------------------------------
## Draw G.U.I. -------------------------------------------------------------
#--------------------------------------------------------------------------

def drawgui():
	global guitabs
	global FullScreen, AutoUpd, RandMod, RSeed

	glClearColor(background[0],background[1],background[2],background[3])
	glClear(GL_COLOR_BUFFER_BIT)
	scissorbox=Buffer(GL_FLOAT,4)
	glGetFloatv(GL_SCISSOR_BOX,scissorbox)
	scissbleft=int(scissorbox[0])
	scissbbase=int(scissorbox[1])
	scissbwidth=int(scissorbox[2])
	scissbheight=int(scissorbox[3])
	xstart = 5
	ystart = 5
	xgap = 5
	ygap = 5
	if FullScreen.val==1:
		guiwidth  = scissbwidth-10
		guiheight = scissbheight-25
		if guiwidth < size_x/2:
			guiwidth = size_x/2
		if guiheight < size_y/2:
			guiheight = size_y/2
	else:
		guiwidth = size_x
		guiheight = size_y
	col,row = [],[]
	xpart = ( ( guiwidth-xstart ) / columns )
	ypart = ( ( guiheight-ystart ) / rows )
	width = []
	for c in range( columns ):
		col.append( xgap + xpart * c + xstart )
		width.append( xpart*(c+1)-xgap )
	height = [ (ypart-ygap)/2 , ypart-ygap, (ypart*3-ygap)/2, ypart*2-ygap, (ypart*5-ygap)/2  ]
	for r in range( rows ):
		row.append( ygap + ypart * r + ystart )
	row.reverse()

	###-------------------------
	## Draw:
	draw_BackPanel( 'A.N.T. Landscape 1.04a', xstart, ystart, guiwidth, guiheight + ygap, lightgrey )
	FullScreen = Toggle("", Scrn_Evt, guiwidth-32, guiheight+ygap+3, 15, 15, FullScreen.val ,"FullScreen" )
	PushButton( "X",        End_Evt, guiwidth-16, guiheight+ygap+3, 15, 15, "Exit" )

	guitabs[0] = Toggle("Mesh",    gt0_Evt, col[0], row[0], width[1], height[1], guitabs[0].val ,"Mesh settings" )
	guitabs[1] = Toggle("Noise",   gt1_Evt, col[2], row[0], width[1], height[1], guitabs[1].val ,"Noise settings" )
	guitabs[2] = Toggle("Effect",  gt2_Evt, col[4], row[0], width[1], height[1], guitabs[2].val ,"Add Effect" )
	guitabs[3] = Toggle("Height",  gt3_Evt, col[6], row[0], width[1], height[1], guitabs[3].val ,"Height Filter" )
	guitabs[4] = Toggle("Options", gt4_Evt, col[8], row[0], width[1], height[1], guitabs[4].val ,"Options" )

	if  guitabs[0].val !=0:
		MeshButtons( col, row, width, height )
	elif  guitabs[1].val !=0:
		NoiseButtons( col, row, width, height )
	elif  guitabs[2].val !=0:
		EffectButtons( col, row, width, height )
	elif  guitabs[3].val !=0:
		FilterButtons( col, row, width, height )
	elif  guitabs[4].val !=0:	
		OptionButtons( col, row, width, height )
	else:
		funnycol = [ randnum(0.0,1.0), randnum(0.0,1.0), randnum(0.0,1.0) ]
		funnypos = int( randnum(1,11) )
		draw_Text( ( col[0]+10, row[ funnypos ] ), 'Another Noise Tool "Landscape"  v.1.04 May/2006', funnycol, 1 )
	
	AutoUpd = Toggle("Auto", No_Evt, col[3], row[12], width[1], height[2], AutoUpd.val ,"Automatic update" )
	PushButton("Generate", Upd_Evt, col[5], row[12], width[4], height[2] , "Generate / Update Mesh. ( KEY: SPACE )")
	if RandMod.val in [1,2]:
		PushButton("Randomise",    Rndm_Evt, col[0], row[12], width[2], height[2] , "Randomise Noise ( KEY: R )")
	else:
		RSeed	= Number("Seed: ",  Rndm_Evt, col[0], row[12], width[2], height[2], RSeed.val,  0, 255 , "Random Seed: If seed = 0, the current time will be used as seed." )


###---------------------------------------------------------------------------
###---------------------------------------------------------------------------
## Events:
def events(evt, val):
	global PreView
	
	if (evt == QKEY and not val):
		Exit()

	if (evt == SPACEKEY and not val):
		do_it()
	if (evt in [ RKEY ] and not val):
		if AutoUpd.val == 0:
			randomiseNoise()
			Draw()
		elif AutoUpd.val == 1:
			do_it_random()
	if PreView[0].val == 1:
		if (evt in [ VKEY, RKEY ] and not val):
			do_it_preview()

###---------------------------------------------------------------------------
## Button events:
def bevents(evt):
	global effect_image, colgrad_image, PreView
	global Filter_Mode, Ipo_Filter_Ctrl, iponame, thiscurve, selectedcurve

	if (evt == End_Evt ):
		name = "OK ?%t|Reset %x1|Quit %x2"
		result = Blender.Draw.PupMenu(name)
		if result==1:
			Set_ReSet_Values()
			Draw()
		if result==2:
			Exit()

	if (evt in [No_Evt, Scrn_Evt] ):
		Draw()
			
	if (evt == Upd_Evt ):
		do_it()

	if AutoUpd.val == 1:
		if (evt == Btn_Evt ):
			do_it()
		elif (evt == Rndm_Evt ):
			do_it_random()

	if AutoUpd.val == 0:
		if (evt == Rndm_Evt ):
			randomiseNoise()
			Draw()
		elif (evt == Btn_Evt ):
			Draw()

	if PreView[0].val != 0:
			if (evt in [ Im_Evt, Btn_Evt, Rndm_Evt ] ):
				do_it_preview()		

	if (evt == gt0_Evt ):
		if guitabs[0].val == 1:
			guitabs[1].val = ( 0 )
			guitabs[2].val = ( 0 )
			guitabs[3].val = ( 0 )
			guitabs[4].val = ( 0 )
		Draw()
	if (evt == gt1_Evt ):
		if guitabs[1].val == 1:
			guitabs[0].val = ( 0 )
			guitabs[2].val = ( 0 )
			guitabs[3].val = ( 0 )
			guitabs[4].val = ( 0 )
		Draw()
	if (evt == gt2_Evt ):
		if guitabs[2].val == 1:
			guitabs[0].val = ( 0 )
			guitabs[1].val = ( 0 )
			guitabs[3].val = ( 0 )
			guitabs[4].val = ( 0 )
		Draw()
	if (evt == gt3_Evt ):
		if guitabs[3].val == 1:
			guitabs[0].val = ( 0 )
			guitabs[1].val = ( 0 )
			guitabs[2].val = ( 0 )
			guitabs[4].val = ( 0 )
		Draw()
	if (evt == gt4_Evt ):
		if guitabs[4].val == 1:
			guitabs[0].val = ( 0 )
			guitabs[1].val = ( 0 )
			guitabs[2].val = ( 0 )
			guitabs[3].val = ( 0 )
		Draw()

	###---------------------------------------------------------
	## get IPOCurve to use as Filter:
	if Filter_Mode.val == 2:
		try:
			ipoblockname  = Ipo.Get( Ipo_Filter_Ctrl[0].val )
			thiscurve     = ipoblockname.getCurves()
			selectedcurve = thiscurve[ Ipo_Filter_Ctrl[1].val ]
		except:
			pass
	###---------------------------------------------------------
	## Effect and Gradient Image Load/Select:
	if (evt == Load_Evt ):
		Blender.Window.FileSelector ( load_image, 'LOAD IMAGE')
	if (evt == Sel_Evt ):
		try:
			effect_image = Image_Menu()
		except:
			pass
		Draw()
	if (evt == Grad_Sel_Evt ):
		try:
			colgrad_image = Image_Menu()
		except:
			pass
		Draw()	

###-------------------------------------------------------------------------------------
### Functions:
###-------------------------------------------------------------------------------------

## Load Image:
def load_image( ImageFileName ):
	Image.Load( ImageFileName )

## Select Image Menu:
def Image_Menu():
	try:
		names=[]
		imagelist = Image.Get()
		imagelist.reverse()
		for numbers, obnames in enumerate( imagelist ):
			n = obnames.getName()
			names.append( n )
		imlistText = string.join( [ '|' + str(names[key]) + '%x' + str(key)  for key in range(numbers+1) ], '' )
		image_menu = Blender.Draw.PupMenu( "Images: %t" + imlistText )
		if image_menu == -1:
			return ''
		return imagelist[ image_menu ].getName()
	except:
		return 'No image found!'



#*# Get Image Pixels:
def Image_Func( x,y ):
	try:
		pic  = Image.Get( effect_image )
	except:
		return 0.0
	w, h = pic.getSize()
	x, y = x,-y
	x = int(w * ((x + 1.0) % 2.0) / 2.0)
	y = int((h-1) - h * ((y + 1.0) % 2.0) / 2.0)	
	c = pic.getPixelF( x,y )
	return ( c[0] + c[1] + c[2] ) / 3.



## Pixel color gradient:
def pixlGrad( hght, pixelrow, gradScale ):
	gradimage = Image.Get( colgrad_image )
	imgsiz = gradimage.getSize()
	imgsizhold = imgsiz[0]-1
	pxl=[]
	imgsiz[0] = int( imgsiz[0] * gradScale )
	if pixelrow >= imgsiz[1]:
		pixelrow = 0
	for i in range( imgsiz[0]-1 ):
		hght = int( (imgsiz[0]-1) * hght )
		if hght < 0:
			hght = 0
		if hght > imgsizhold:
			hght = imgsizhold
		grad = gradimage.getPixelF( hght, imgsiz[1]-1-pixelrow )
		r,g,b = grad[0], grad[1], grad[2]
		pxl.append( (r,g,b) )
		return NMesh.Col(int(pxl[i][0]*255),int(pxl[i][1]*255),int(pxl[i][2]*255)) , (pxl[i][0],pxl[i][1],pxl[i][2])

##-------------------------------------------------------------------------------------

# Transpose noise coords:
def Trans((x,y,z), size, loc  ):
	x = ( x / size[1] / size[0] + loc[0] )
	y = ( y / size[2] / size[0] + loc[1] )
	z = 0.0
	return x,y,z

# Transpose effect coords:
def Trans_Effect((x,y,z), size, loc  ):
	x = ( x * size[1] * size[0] + loc[0] )
	y = ( y * size[2] * size[0] + loc[1] )
	z = 0.0
	return x,y,z

# Height scale:
def HeightScale( input, iscale, offset, invert ):
	if invert !=0:
		return (1.0-input) * iscale + offset
	else:
		return input * iscale + offset

# dist.
def Dist(x,y):
	return sqrt( (x*x)+(y*y) )

##-----------------------------------
# bias types:
def no_bias(a):
	return a
def sin_bias(a):
	return 0.5 + 0.5 * sin(a)
def cos_bias(a):
	return 0.5 + 0.5 * cos(a)
def tri_bias(a):
	b = 2 * phi
	a = 1 - 2 * abs(floor((a * (1/b))+0.5) - (a*(1/b)))
	return a
def saw_bias(a):
	b = 2 * phi
	n = int(a/b)
	a -= n * b
	if a < 0:
		a += b
	return a / b

# sharpen types:
def soft(a):
	return a
def sharp(a):
	return a**0.5
def sharper(a):
	return sharp(sharp(a))

Bias_Types  = [ sin_bias, cos_bias, tri_bias, saw_bias, no_bias ]
Sharp_Types = [ soft, sharp, sharper ]

##-----------------------------------
# Mix modes

def maximum( a, b ):
	if ( a > b ): b = a
	return b
def minimum( a, b ):
	if ( a < b ): b = a
	return b

def Mix_Modes( (i,j),(x,y,z) , a, b, mixfactor, mode ):
	a = a * ( 1.0 + mixfactor )
	b = b * ( 1.0 - mixfactor )
	if   mode == 0:  return  ( a )                     #0  a
	elif mode == 1:  return  ( a*(1.0-0.5) + b*0.5 )   #1  mix
	elif mode == 2:  return  ( a + b )                 #2  add
	elif mode == 3:  return  ( a - b )                 #3  sub.
	elif mode == 4:  return  ( a * b )                 #4  mult.
	elif mode == 5:  return  (abs( a - b ))            #5  abs diff.
	elif mode == 6:  return  1.0-((1.0-a)*(1.0-b)/1.0) #6  screen
	elif mode == 7:  return  ( a + b ) % 1.0           #7  addmodulo
	elif mode == 8:  return  minimum( a, b )           #8  min.
	elif mode == 9:  return  maximum( a, b )           #9  max.
	elif mode == 10:                                   #10 warp: effect
		noise =  mixfactor * Noise_Function(x,y,z)
		return    Effects( (i,j),(x+noise,y+noise,z) )
	elif mode == 11:                                   #11 warp: noise
		effect = mixfactor * Effects( (i,j),(x,y,z) )
		return   Noise_Function( x+effect, y+effect, z )
	else: return b	

###----------------------------------------------------------------------
# Effect functions:

# Effect_Basis_Function:
def Effect_Basis_Function((x,y), type, bias ):

	iscale = 1.0
	offset = 0.0
	## gradient:
	if type == 0:
		effect = offset + iscale * ( Bias_Types[ bias ]( x + y ) )
	## waves / bumps:
	if type == 1:
		effect = offset + iscale * 0.5 * ( Bias_Types[ bias ]( x*phi ) + Bias_Types[ bias ]( y*phi ) )
	## zigzag:
	if type == 2:
		effect = offset + iscale * Bias_Types[ bias ]( offset + iscale * sin( x*phi + sin( y*phi ) ) )
	## wavy:	
	if type == 3:
		effect = offset + iscale * ( Bias_Types[ bias ]( cos( x ) + sin( y ) + cos( x*2+y*2 ) - sin( -x*4+y*4) ) )
	## sine bump:	
	if type == 4:
		effect =   offset + iscale * 1-Bias_Types[ bias ](( sin( x*phi ) + sin( y*phi ) ))
	## dots:
	if type == 5:
		effect = offset + iscale * ( Bias_Types[ bias ](x*phi*2) * Bias_Types[ bias ](y*phi*2) )-0.5
	## rings / dome:
	if type == 6:
		effect = offset + iscale * ( Bias_Types[ bias ]( 1.0-(x*x+y*y) ) )
	## spiral:
	if type == 7:
		effect = offset + iscale * Bias_Types[ bias ](( x*sin( x*x+y*y ) + y*cos( x*x+y*y ) ))*0.5
	## square / piramide:
	if type == 8:
		effect = offset + iscale * Bias_Types[ bias ](1.0-sqrt( (x*x)**10 + (y*y)**10 )**0.1)
	## blocks:	
	if type == 9:
		effect = ( 0.5-max( Bias_Types[ bias ](x*phi) , Bias_Types[ bias ](y*phi) ))
		if effect > 0.0: effect = 1.0
		effect = offset + iscale * effect
	## grid:	
	if type == 10:
		effect = ( 0.025-min( Bias_Types[ bias ](x*phi) , Bias_Types[ bias ](y*phi) ))
		if effect > 0.0: effect = 1.0
		effect = offset + iscale * effect
	## tech:
	if type == 11:
		a = ( max( Bias_Types[ bias ](x*pi) , Bias_Types[ bias ](y*pi) ))
		b = ( max( Bias_Types[ bias ](x*pi*2+2) , Bias_Types[ bias ](y*pi*2+2) ))
		effect = ( min( Bias_Types[ bias ](a) , Bias_Types[ bias ](b) ))*3.0-2.0
		if effect > 0.5: effect = 1.0
		effect = offset + iscale * effect

	## crackle:	
	if type == 12:
		t = turbulence(( x, y, 0 ), 6, 0, 0 ) * 0.25
		effect = vlNoise(( x, y, t ), 0.25, 0, 8 )
		if effect > 0.5: effect = 0.5
		effect = offset + iscale * ( effect )
	## sparse cracks noise:
	if type == 13:
		effect = 2.5 * abs( noise((x*0.5,y*0.5, 0 ), 1 ) )-0.1
		if effect > 0.25: effect = 0.25
		effect = offset + iscale * ( effect * 2.5 )
	## shattered rock noise:
	if type == 14:
		effect = 0.5 + noise((x,y,0), 7 )
		if effect > 0.75: effect = 0.75
		effect = offset + iscale * effect
	## lunar noise:
	if type == 15:
		effect = 0.25 + 1.5 * voronoi(( x+2, y+2, 0 ), 1 )[0][0]
		if effect > 0.5: effect = 0.5
		effect = offset + iscale * ( effect * 2.0 )
	## cosine noise:
	if type == 16:
		effect = cos( 5*noise(( x, y, 0 ), 0 ) )
		effect = offset + iscale * ( effect*0.5 )
	## spikey noise:
	if type == 17:
		n = 0.5 + 0.5 * turbulence(( x*5, y*5, 0 ), 8, 0, 0 )
		effect = ( ( n*n )**5 )
		effect = offset + iscale * effect
	## stone noise:
	if type == 18:
		effect = offset + iscale *( noise((x*2,y*2, 0 ), 0 ) * 1.5 - 0.75)
	## Flat Turb:
	if type == 19:
		t = turbulence(( x, y, 0 ), 6, 0, 0 )
		effect = t*2.0
		if effect > 0.25: effect = 0.25
		effect = offset + iscale * ( effect )
	## Flat Voroni:
	if type == 20:
		t = 1-noise(( x, y, 0 ), 3 )
		effect = t*2-1.75
		if effect > 0.25: effect = 0.25
		effect = offset + iscale * ( effect )

	if effect < 0.0: effect = 0.0
	return effect

# fractalize Effect_Basis_Function: ------------------------------ 
def Effect_Function((x,y), type,bias, turb, depth,frequency,amplitude ):

	## turbulence:
	if turb != 0.0:
		t = turb * ( 0.5 + 0.5 * turbulence(( x, y, 0 ), 6, 0, 0 ))
		x = x + t
		y = y + t

	result = Effect_Basis_Function((x,y), type, bias )
	## fractalize:
	if depth != 0:
		i=0
		for i in range( depth ):
			i+=1
			x *= frequency
			y *= frequency
			amplitude = amplitude / i
			result += Effect_Basis_Function( (x,y), type, bias ) * amplitude

	return result


###--------------------------------------------------
## Effect Selector:
def Effects( (i,j),(x,y,z) ):
	global Effect_Type, Effect_Ctrl, twister_amount, iScale, Offset, Invert
	global Quality, NSize, Lx, Ly, Lz, Sx, Sy, Sz, marbleTwo, turbTwo, vlnoiTwo, Basis
		
	x,y,z = Trans_Effect((x,y,z),( NSize[1].val, Sx[1].val, Sy[1].val, 0 ),( Lx[1].val, Ly[1].val, 0 )  )

	basis = Basis[1].val
	if basis == 9: basis = 14

	if Effect_Ctrl[0].val == 1:
		try:
			effect  = Image_Func( x,y )
		except:
			effect =	0.0

	elif Effect_Ctrl[0].val == 2:
		effect = 0.5+0.5*turbulence(( x,y,z ),turbTwo[0].val, turbTwo[1].val, basis, turbTwo[2].val, turbTwo[3].val )
	elif Effect_Ctrl[0].val == 3:
		effect = 0.5+0.5*vlNoise(( x,y,z ),vlnoiTwo[0].val, vlnoiTwo[1].val, basis )
	elif Effect_Ctrl[0].val == 4:
		effect =	 0.5*marbleNoise((x,y,z), marbleTwo[0].val, basis, marbleTwo[2].val, marbleTwo[3].val, marbleTwo[4].val, marbleTwo[5].val )
	else:
		effect = Effect_Function((x,y), Effect_Ctrl[0].val-5,  Effect_Ctrl[3].val,  Effect_Ctrl[4].val,  Effect_Ctrl[5].val,  Effect_Ctrl[6].val, Effect_Ctrl[7].val )

	effect = HeightScale( effect, iScale[1].val , Offset[1].val, Invert[1].val )

	return  effect



###----------------------------------------------------------------------
# Noise:
##-----------------------------------

## voronoi_turbulence:
def voroTurbMode((x,y,z), voro, mode ):
	if mode == 0: # soft
		return voronoi(( x,y,z ),voro[0], voro[1] )[0][0]
	if mode == 1: # hard
		return ( abs( 0.5-voronoi(( x,y,z ),voro[0], voro[1] )[0][0] ) )+0.5
def voronoi_turbulence((x,y,z), voro, tur ):
	result = voroTurbMode((x,y,z), voro, tur[1] )
	depth  = tur[0]
	amp    = tur[2]
	freq   = tur[3]
	i=0
	for i in range( depth ):
		i+=1
		result += voroTurbMode( ( x*(freq*i), y*(freq*i), z ), voro, tur[1] )* ( amp*0.5/i )
	return (result*4.0-2.0)

## DistortedNoise / vlNoise_turbulence:
def vlnTurbMode((x,y,z), vlno, basis, mode ):
	if mode == 0: # soft
		return vlNoise(( x,y,z ),vlno[0], vlno[1], basis )
	if mode == 1: # hard
		return ( abs( -vlNoise(( x,y,z ),vlno[0], vlno[1], basis ) ) )
def vlNoise_turbulence((x,y,z), vlno, tur, basis ):
	result = vlnTurbMode((x,y,z), vlno, basis, tur[1] )
	depth  = tur[0]
	amp    = tur[2]
	freq   = tur[3]
	i=0
	for i in range( depth ):
		i+=1
		result += vlnTurbMode( ( x*(freq*i), y*(freq*i), z ), vlno, basis, tur[1] ) * ( amp*0.5/i )
	return result*2.0+0.5

## marbleNoise:
def marbleNoise( (x,y,z), depth, basis, turb, bias, sharpnes, rescale ):
	m = ( x * rescale + y * rescale + z ) * 5
	height = m + turb * turbulence( ( x ,y ,z ), depth, 0, basis, 0.5, 2.0 )
	height = Bias_Types[ bias ]( height )
	if bias != 4:
		height = Sharp_Types[ sharpnes ]( height )
	return height*2.0

## lava_multiFractal:
def lava_multiFractal( ( x,y,z ),Ha, La, Oc, distort, Basis ):
	m  = multiFractal( ( x,y,z ), Ha, La, Oc, Basis)
	d = m * distort
	m2 = 0.5 * multiFractal( ( x+d,y+d,d*0.5 ), Ha, La, Oc, Basis)
	return (m * m2)**0.5

## slopey_noise:
def slopey_noise((x,y,z), H, lacunarity, octaves, distort, basis ):
	turb = fBm((x,y,z), H, lacunarity, octaves, 2 ) * 0.5
	map = 0.5 + noise( ( x+turb, y+turb, z ), basis )
	result = map + turb * distort
	return result

## duo_multiFractal:
def double_multiFractal((x,y,z), H, lacunarity, octaves, offset, gain, basis ):
	n1 = multiFractal( (x*1.5+1,y*1.5+1,z), 1.0, 1.0, 1.0, basis ) * offset
	n2 = multiFractal( (x-1,y-1,z), H, lacunarity, octaves, basis ) * gain
	result = ( n1*n1 + n2*n2 )*0.5
	return result

## distorted_heteroTerrain:
def distorted_heteroTerrain((x,y,z), H, lacunarity, octaves, offset, distort, basis ):
	h1 = ( heteroTerrain((x,y,z), 1.0, 2.0, 1.0, 1.0, basis ) * 0.5 )
	h2 = ( heteroTerrain(( x, y, h1*distort ), H, lacunarity, octaves, offset, basis ) * 0.25 )
	result = ( h1*h1 + h2*h2 )
	return  result

## SlickRock:
def SlickRock((x,y,z), H, lacunarity, octaves, offset, gain, basis ):
	n = multiFractal( (x,y,z), 1.0, 2.0, 1.0, basis )
	r = ridgedMFractal((x,y,n*0.5), H, lacunarity, octaves, offset, gain, basis )*0.5
	return n+(n*r)

## terra_turbulence:
def terra_turbulence((x,y,z), depth, hard, basis, amp, freq ):
	t2 = turbulence( ( x, y, z ), depth,  hard , basis, amp, freq )
	return (t2*t2*t2)+0.5

## rocky_fBm:
def rocky_fBm((x,y,z), H, lacunarity, octaves, basis ):
	turb = fBm((x,y,z), H, lacunarity, octaves, 2 ) * 0.25
	coords = ( x+turb, y+turb, z )
	map = noise( coords, 7 )
	result = map + fBm( coords, H, lacunarity, octaves, basis ) + 1.0
	return result

####---------------------------------------.
### StatsByAlt, double terrain  basis mode:
def TerrainBasisMode((x,y,z), basis, mode ):
	if mode == 0: # noise
		return noise((x,y,z),basis)
	if mode == 1: # noise ridged
		return ( 1.0-abs( noise((x,y,z),basis) ) )-0.5
	if mode == 2: # vlNoise
		return vlNoise((x,y,z), 1.0, 0, basis )
	else:         # vlNoise ridged
		return ( 1.0-abs( vlNoise((x,y,z), 1.0, 0, basis ) ) )-0.5

#### StatsByAlt terrain:
def StatsByAltTerrain((x,y,z), exp, lacu, octs, offset, amp, basis, mode ):
	result = 0.5 * (offset + TerrainBasisMode((x,y,z), basis, mode ) )
	octs = int( octs )
	i = 0
	for i in range( 1, octs ):
		i += 1
		result += result * amp * 0.5 * (offset + TerrainBasisMode((x,y,z), basis, mode ) )
		x *= lacu
		y *= lacu
		amp /= ( exp * 0.5 ) * i		
	return result

##### double terrain:
def doubleTerrain((x,y,z), exp, lacu, octs, offset, threshold, basis, mode ):
	result = amp = freq = 1.0
	octs = int( octs )
	i = 1
	signal = result = 0.5 * (offset + TerrainBasisMode((x,y,z), basis, mode ) )
	for i in range( i, octs ):
		i -= 1
		x = x * lacu
		y = y * lacu
		freq *= lacu
		amp = pow( freq, -exp )
		if i < 1.0: amp *= i
		weight = signal / threshold
		if weight > 1.0: weight = 1.0
		if weight < 0.0: weigth = 0.0
		signal = weight * 0.5 * ( offset + TerrainBasisMode((x,y,z), basis, mode ) )
		result += amp * signal
	return result * 2.0

##------------------------------------------------------------
# Noise Functions:
def Noise_Function(x,y,z):
	global Basis, NType, musgr, vlnoi, voron, turbOne, marbleOne, tBasismod
	global vlBasis, Distort, VFunc, VExp, VDep
	global iScale, Offset, Invert, NSize, Lx, Ly, Sx, Sy
	
	x,y,z = Trans((x,y,z),( NSize[0].val, Sx[0].val, Sy[0].val, 0 ),( Lx[0].val, Ly[0].val, 0 )  )

	basis = Basis[0].val
	if basis == 9: basis = 14
	vbasis = vlnoi[0].val
	if vbasis == 9: vbasis = 14
	
	if   NType.val == 0:	z = multiFractal((   x,y,z ),musgr[0].val, musgr[1].val, musgr[2].val, basis )
	elif NType.val == 1:	z = ridgedMFractal(( x,y,z ),musgr[0].val, musgr[1].val, musgr[2].val, musgr[3].val, musgr[4].val, basis )
	elif NType.val == 2:	z = hybridMFractal(( x,y,z ),musgr[0].val, musgr[1].val, musgr[2].val, musgr[3].val, musgr[4].val, basis )
	elif NType.val == 3:	z = heteroTerrain((  x,y,z ),musgr[0].val, musgr[1].val, musgr[2].val, musgr[3].val, basis )*0.5
	elif NType.val == 4:	z = fBm((            x,y,z ),musgr[0].val, musgr[1].val, musgr[2].val, basis )+0.5
	elif NType.val == 5:	z = turbulence((     x,y,z ),turbOne[0].val, turbOne[1].val, basis, turbOne[2].val, turbOne[3].val )*0.5+0.5
	elif NType.val == 6:	z = voronoi_turbulence((x,y,z),(voron[0].val,voron[1].val),(turbOne[0].val,turbOne[1].val,turbOne[2].val,turbOne[3].val) )*0.5+0.5
	elif NType.val == 7:	z = vlNoise_turbulence((x,y,z),(vlnoi[0].val,vlnoi[1].val), (turbOne[0].val,turbOne[1].val,turbOne[2].val,turbOne[3].val), basis )*0.5+0.5
	elif NType.val == 8:	z = noise((          x,y,z ),basis )+0.5
	elif NType.val == 9:	z = cellNoise((      x,y,z ))+0.5
	elif NType.val == 10: z = marbleNoise((         x,y,z), marbleOne[0].val, basis, marbleOne[2].val, marbleOne[3].val, marbleOne[4].val, marbleOne[5].val )
	elif NType.val == 11: z = lava_multiFractal((  x,y,z ), musgr[0].val, musgr[1].val, musgr[2].val, vlnoi[0].val, basis )
	elif NType.val == 12: z = slopey_noise((         x,y,z), musgr[0].val, musgr[1].val, musgr[2].val, vlnoi[0].val, basis )+0.5
	elif NType.val == 13: z = double_multiFractal(( x,y,z), musgr[0].val, musgr[1].val, musgr[2].val, musgr[3].val, musgr[4].val, basis )
	elif NType.val == 14: z = distorted_heteroTerrain((x,y,z), musgr[0].val, musgr[1].val, musgr[2].val, musgr[3].val, vlnoi[0].val, basis )
	elif NType.val == 15: z = SlickRock((           x,y,z), musgr[0].val, musgr[1].val, musgr[2].val, musgr[3].val, musgr[4].val, basis )
	elif NType.val == 16: z = terra_turbulence((  x,y,z), turbOne[0].val, turbOne[1].val, basis, turbOne[2].val, turbOne[3].val )
	elif NType.val == 17: z = rocky_fBm((           x,y,z ),musgr[0].val, musgr[1].val, musgr[2].val, basis )
	elif NType.val == 18: z = StatsByAltTerrain(   (x,y,z), musgr[0].val, musgr[1].val, musgr[2].val, musgr[3].val, musgr[4].val*0.5, basis, tBasismod.val )
	elif NType.val == 19: z = doubleTerrain(       (x,y,z), musgr[0].val, musgr[1].val, musgr[2].val, musgr[3].val, musgr[5].val, basis, tBasismod.val )
	else:	z = 0.0
	return HeightScale( z, iScale[0].val , Offset[0].val, Invert[0].val )


##----------------------------------------------------------------------
##-----------------------------------
# Filter functions:

# Filters: terrace / posterise / peaked / bias:
def Def_Filter((x,y,z), input, numb, type ):
	if   type == 0:
		s = ( sin( input*numb*phi ) * ( 0.1/numb*phi ) )
		return ( input * (1.0-0.5) + s*0.5 ) * 2.0
	elif type == 1:
		s = -abs( sin( input*(numb*0.5)*phi ) * ( 0.1/(numb*0.5)*phi ) )
		return ( input * (1.0-0.5) + s*0.5 ) * 2.0
	elif type == 2:
		s = abs( sin( input*(numb*0.5)*phi ) * ( 0.1/(numb*0.5)*phi ) )
		return ( input * (1.0-0.5) + s*0.5 ) * 2.0
	elif type == 3:
		numb = numb*0.5
		s = ( int( input*numb ) * 1.0/numb )
		return ( input * (1.0-0.5) + s*0.5 ) * 2.0
	elif type == 4:
		numb = numb*0.5
		s = ( int( input*numb ) * 1.0/numb )
		return ( s ) * 2.0
	elif type == 5:
		s = ( sin( input*(2*numb)*phi ) * ( 0.1/(2*numb)*phi ) )
		l = ( input * (1.0-0.5) + s*0.5 ) * 2.0
		p = ( ( l*numb*0.25 ) * ( l*numb*0.25 ) )**2
		return ( l * (1.0-0.5) + p*0.5 ) * 2.0
	elif type == 6:
		return ( input*numb*0.25 )**4
	elif type == 7:
		return 2.0-exp( 1.0-(input*numb/3.0) )
	elif type == 8:
		return sin_bias( input*numb )*2.0
	elif type == 9:
		return cos_bias( input*numb )*2.0
	elif type == 10:
		return tri_bias( input*numb )*2.0
	else:
		return saw_bias( input*numb )*2.0

# Filter: Clamp height
def Clamp_Max( height, max ):
   if ( height > max ): height = max
   return height
def Clamp_Min( height, min ):
   if ( height < min ): height = min
   return height

# Filter: Edge falloff
def EdgeFalloff( (x,y,z), height, type ):
	global Falloff, maketiles
	
	x = x / Falloff[1].val
	y = y / Falloff[2].val
	if maketiles[0].val !=0:
		x = x / tile_rescale[ maketiles[1].val ]
		y = y / tile_rescale[ maketiles[1].val ]
	if Falloff[3].val != 0:
		sealevel = Min.val*2.0/iScale[2].val
	else:
		sealevel = 0.0
	falltypes = ( 0, sqrt(x*x+y*y), sqrt((x*x)**2+(y*y)**2), sqrt((x*x)**10+(y*y)**10), sqrt(y*y), sqrt(x*x), abs(x-y), abs(x+y), ((x*x)**10+(y*y)**10)**0.1, ((x*x)+(y*y)) )
	dist = falltypes[ type ]
	if Falloff[4].val != 0:
		dist = 1.0 - dist
	radius = 1.0
	height = height - sealevel
	if( dist < radius ):
		dist = dist / radius
		dist = ( (dist) * (dist) * ( 3-2*(dist) ) )
		height = ( height - height * dist ) + sealevel
	else:
		height = sealevel
	if Falloff[3].val != 0:
		height = Clamp_Min( height, sealevel )
	else:
		height = Clamp_Min( height, Min.val )
	
	return  height


#####-------------------------------------------------------------------------------------#####
####-------------------------------------------------------------------------------------####
### Combine Functions: (get noise, Add effect, filter height and return result)         ###
##-------------------------------------------------------------------------------------##

def Combine_Functions( (i,j),(x,y,z) ):
	global Quality, Effect_Ctrl, Blend_Effect, Filter_Mode, Def_Filter_Ctrl, Ipo_Filter_Ctrl
	global iScale, Offset, Invert, Min, Max, Falloff

	# get noise height:
	height = Noise_Function(x,y,0.0)
	
	# mix noise with effect:
	if Effect_Ctrl[0].val !=0:
		height = Mix_Modes( (i,j),(x,y,z) , Effects( (i,j),(x,y,z) ), height, Effect_Ctrl[2].val, Effect_Ctrl[1].val )

	# edge fallof:
	if Falloff[0].val !=0:
		height = EdgeFalloff( (x,y,z), height, Falloff[0].val )

	# height filter 
	if Filter_Mode.val !=0:
		# height Def_Filter (Terrace/peaked/bias):
		if Filter_Mode.val ==1:
			if Def_Filter_Ctrl[ 0 ].val != 12:
				height = Def_Filter((x,y,z), height, Def_Filter_Ctrl[ 1 ].val, Def_Filter_Ctrl[ 0 ].val )
			
		## 'IPOCurve' height filter:
		elif Filter_Mode.val ==2:
			try:
				height = selectedcurve.evaluate( 1 + ( height*Ipo_Filter_Ctrl[2].val/2 ) )*2.0/Ipo_Filter_Ctrl[3].val
			except:
				height = height
		
	# height scale:	
	height = HeightScale( height, 0.5*iScale[2].val , Offset[2].val, Invert[2].val )
	
	# clamp height min. max.:
	if Falloff[0].val !=1:
		height = Clamp_Min( height, Min.val )
	height = Clamp_Max( height, Max.val )
	
	# return height:
	return height


#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
# Make preview image:

#----------------------
# resize pixels #----------------------
def resizepixels( (i,j),(x,y), res ):
	global Quality, maketiles
	size = int( resolution[ Quality.val-1 ] )
	i = int( i * ( 1.0 * size / 1.0 ) / res )
	j = int( j * ( 1.0 * size / 1.0 ) / res )
	if maketiles[0].val !=0:
		x = x * tile_rescale[ maketiles[1].val ]
		y = y * tile_rescale[ maketiles[1].val ]
	return Combine_Functions( (i,j),(x,y,0.0) )

#----------------------
# render image #----------------------
def heightMap():
	global PreView, previewname, ViewiScale, vcolours, vcolGradRow, gradScale

	imsize = resolution[ PreView[1].val-1 ]
	iname = previewname.val + '_' + imsize + '.tga'
	res = int( imsize )
	##------------------------------
	try:
		pic = Image.Get( iname )
	except:
		pic = Image.New( iname, res, res ,24 )
	#------------------------------
	for i in range( 0, res ):
		for j in range( 0, res ):
			x = i - (res) / 2.0
			y = j - (res) / 2.0
			x = (x*2.0) / (res)
			y = (y*2.0) / (res)
			#
			height = resizepixels( (i,j),(x,y), res )
			height *= ViewiScale.val
			##
			if vcolours.val == 1:
				try:
					r,g,b = pixlGrad( height, vcolGradRow.val, gradScale.val )[1]
				except:
					r,g,b = height, height, height
			else:
				r,g,b = height, height, height

			###
			if r > 1.0: r = 1.0
			if g > 1.0: g = 1.0
			if b > 1.0: b = 1.0
			if r < 0.0: r = 0.0
			if g < 0.0: g = 0.0
			if b < 0.0: b = 0.0
			####
			pic.setPixelF( i, j, ( r, g, b, 1.0 ) )
	
	# get dir. to save to:
	filepath = Blender.Get( 'filename' )
	dirpath = Blender.sys.dirname( filepath )
	# Set name and save image:
	pic.setFilename( dirpath+'/'+iname )
	pic.save()
	#-------------------------------------------------------

#------------------------------------------------------------------------
## Make Mesh -----------------------------------------------------------
###--------------------------------------------------------------------

#------------------------------------------------------------------------
# VertSelect: select flat areas:
def Flat_Vert_Select(me, res, slope_range ):
	for y in range( 1, res[1]-1 ):
		for x in range( 1, res[0]-1 ):
			a = x + y * res[0]
			try:
				s = max(abs(me.verts[a].co.z - me.verts[a + res[0] + 1].co.z), abs(me.verts[a + res[0]].co.z - me.verts[a + 1].co.z))
				if ( s < (slope_range / res[0]) ):
					me.verts[a].sel = 1
			except: pass

#------------------------------------------------------------------------
def Make_Mesh( tiles ): 
	global TerName, Quality, Quad_Tri, Smooth, maketiles, vSelRange, vcolours, vcolGradRow, gradScale

	n = int( resolution[ Quality.val-1 ] )

	try:
		o = Object.Get( TerName.val + '_' + str( tiles) )
		me = o.getData()
		UPDATE = 1	
	except:
		o = Object.New('Mesh', TerName.val + '_' + str( tiles) )
		scene.link(o)
		me = NMesh.GetRaw()
		UPDATE = 0

	me.verts=[]
	me.faces=[]
	COL=[]
	# Vertices -----------------------------------
	for i in range( 0, n ):
		for j in range( 0, n ):
			# Tile size and position:
			x = i - (n-1) / 2.0 
			x = x * 2.0 / (n-1) + ( tiles_positions[maketiles[1].val][ tiles ][0] * 2 )
			y = j - (n-1) / 2.0
			y = y * 2.0 / (n-1) + ( tiles_positions[maketiles[1].val][ tiles ][1] * 2 )
			z = 0.0
			# height:
			height = Combine_Functions( (i,j),(x,y,z) )
			v = NMesh.Vert( x, y, height )
			me.verts.append(v)

			# VertCol -----------------------------------
			if vcolours.val == 1:
				try:
					COL.append( pixlGrad( height, vcolGradRow.val, gradScale.val )[0] )
				except:
					pass

	## Vertices: Select Flat Areas --------------------------------------
	if vSelRange.val !=0.0:
		Flat_Vert_Select(me, [n,n], vSelRange.val )

	##--------------------------------------
	me.hasVertexColours( vcolours.val )

	## Faces --------------------------------------
	if Quad_Tri.val == 1:
		## make triangles
		for i in range(n-1):
			for j in range(n-1):
				f = NMesh.Face()
				f.v.append(me.verts[n*i+j])
				f.v.append(me.verts[n*(i+1)+j])
				f.v.append(me.verts[n*i+(j+1)])
				if vcolours.val !=0:
					f.col.append(COL[n*i+j])
					f.col.append(COL[n*(i+1)+j])
					f.col.append(COL[n*i+(j+1)])
				f.smooth = Smooth.val
				me.faces.append(f)
				f = NMesh.Face()
				f.v.append(me.verts[n*i+(j+1)])
				f.v.append(me.verts[n*(i+1)+j])
				f.v.append(me.verts[n*(i+1)+(j+1)])
				if vcolours.val !=0:
					f.col.append(COL[n*i+(j+1)])
					f.col.append(COL[n*(i+1)+j])
					f.col.append(COL[n*(i+1)+(j+1)])
				f.smooth = Smooth.val
				me.faces.append(f)
	else:
		## make quads
		for i in range(n-1):
			for j in range(n-1):
				f= NMesh.Face()
				f.v.append(me.verts[i*n+j])
				f.v.append(me.verts[(i+1)*n+j])
				f.v.append(me.verts[(i+1)*n+j+1])
				f.v.append(me.verts[i*n+j+1])
				if vcolours.val !=0:
					f.col.append(COL[i*n+j])
					f.col.append(COL[(i+1)*n+j])
					f.col.append(COL[(i+1)*n+j+1])
					f.col.append(COL[i*n+j+1])
				f.smooth = Smooth.val
				me.faces.append(f)
	##
	if UPDATE ==1:
		me.update(1)
	else :
		o.link(me)
	#o.select(1)
	o.layers = Window.ViewLayers()
	o.makeDisplayList()


###----------------------------------------------------------------------------------------------------
## Do_it:
#--------------------------------------
def do_it():
	global maketiles
	in_editmode = Window.EditMode()
	if in_editmode: Window.EditMode(0)
	Blender.Window.WaitCursor(1)
	if maketiles[0].val !=0:
		for mt in range( len(tiles_positions[maketiles[1].val]) ):
			Make_Mesh( mt )
	else:
		Make_Mesh( 0 )
	Blender.Window.WaitCursor(0)
	if in_editmode: Window.EditMode(1)
	#Redraw()
#--------------------------------------
def do_it_random():
	global maketiles
	in_editmode = Window.EditMode()
	if in_editmode: Window.EditMode(0)
	Blender.Window.WaitCursor(1)
	randomiseNoise()
	if maketiles[0].val !=0:
		for mt in range( len(tiles_positions[ maketiles[1].val ]) ):
			Make_Mesh( mt )
	else:
		Make_Mesh( 0 )
	Blender.Window.WaitCursor(0)
	if in_editmode: Window.EditMode(1)
	#Redraw()
#--------------------------------------
def do_it_preview():
	heightMap()
	Window.RedrawAll()

##----------------------------------------------------------------------------------------------------
# Register:

Register( drawgui, events, bevents )

###----------------------------------------------------------------------------------------------------