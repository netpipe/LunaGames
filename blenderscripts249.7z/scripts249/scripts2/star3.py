#!BPY
"""
Name: 'Star'
Blender: 244
Group: 'AddMesh'
"""
import BPyAddMesh
import Blender
from math import *
def add_mymesh(PREF_NUMBER,PREF_SIZE1,PREF_SIZE2,PREF_SEL,PREF_DEPTH):

	verts = []
	faces = []
	
	y=1	
	x=0
	
	a=360/PREF_NUMBER
	b=radians(a)
	
	verts.append([0.0,0,0.0])
		
		
	while y<=PREF_NUMBER:
		
		
		verts.append([PREF_SIZE1*sin(x),PREF_SIZE1*cos(x),0])
		verts.append([PREF_SIZE2*sin(x+b/2),PREF_SIZE2*cos(x+b/2),0])
	
				
		x=x+b
		y=y+1	
	
	
	y=0
	while y<=PREF_NUMBER*2-2:	
		
		faces.append([y,y+1])
		y=y+1
	
	faces.append([0,y])
	verts.pop(0)
	
	
	if PREF_SEL !=0:
		y=0
		verts.append([0,0,PREF_DEPTH])
		verts.append([0,0,-PREF_DEPTH])
		while y<=PREF_NUMBER*2-2:
			faces.append([(PREF_NUMBER*2),y,y+1])
			faces.append([(PREF_NUMBER*2)+1,y+1,y])
			y=y+1
		faces.append([(PREF_NUMBER*2+1),0,(PREF_NUMBER*2-1)])
		faces.append([0,(PREF_NUMBER*2),(PREF_NUMBER*2-1)])
	
		
	return verts, faces
	
def main():
	
	numberInput = Blender.Draw.Create(5)
	size1Input = Blender.Draw.Create(1.0)
	size2Input = Blender.Draw.Create(2.0)
	depth_mode = Blender.Draw.Create(1)
	depthInput = Blender.Draw.Create(0.5)
		
	block = []
	
	
	block.append(("points: ", numberInput, 2, 40, "number of points"))
	block.append(("size1: ", size1Input,0.1,100,"inner size"))
	block.append(("size2: ", size2Input,0.1,100,"outer size"))
	block.append(("depth",depth_mode,"adds depth and faces"))
	block.append(("depth:", depthInput, 0.1, 100, "depth"))
	
	
	if not Blender.Draw.PupBlock("Create",block):
		return
	
	verts, faces = add_mymesh(numberInput.val,size1Input.val,size2Input.val,depth_mode.val,depthInput.val)
	
	BPyAddMesh.add_mesh_simple('Star', verts, [], faces)

main()