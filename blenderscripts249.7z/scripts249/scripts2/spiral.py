#!BPY
"""
Name: 'Spiral'
Blender: 244
Group: 'AddMesh'
"""
#made by facundo couzo thanks to who wrote the tutorial "How to add customs objects to Blender"


import BPyAddMesh
import Blender
from math import *
def add_mymesh(PREF_NUMBER,PREF_PRES):

	verts = []
	faces = []
	
	y=1	
	x=0
	
	verts.append([0,0,0])

		
	while y<=PREF_NUMBER:
		
		
		verts.append([x*cos(x),x*sin(x),0])
	
		
		faces.append([y-1,y])
		
		x=x+(1/PREF_PRES)
		y=y+1	
		
	
	return verts, faces
	
def main():
	
	
	numberInput = Blender.Draw.Create(500.0)
	presInput = Blender.Draw.Create(10.0)
	

		
	block = []
	
	
	block.append(("number: ", numberInput, 1, 10000, "number of verts"))
	block.append(("precision: ", presInput,1,100,"distance between points"))
	
	 
	if not Blender.Draw.PupBlock("Create",block):
		return
	
	verts, faces = add_mymesh(numberInput.val,presInput.val)
	
	BPyAddMesh.add_mesh_simple('Function', verts, [], faces)

main()
