import os
import random
import math
import Blender
import string
from math import *
from random import *
from Blender import Window
from Blender.BGL import *
from Blender.Draw import *
from Blender import NMesh

separator = os.sep

 # Change defaults here user
BldName     = "c:" + separator + "test.bbf"
DefBBLIn    = "c:" + separator + "list.bbl"
DefOutFile  = "c:" + separator + "test.bbf"
DefInFile   = "c:" + separator + "test.bbf"
DefBBLOut   = "c:" + separator + "list.bbl"

 # Global Variables
Next = 0
First  = 0
Second = 1
Third  = 2
Fourth = 3
Size = 100
FileList = []

 # Initiate FileList
for i in range(0, 100):
   FileList.append("----")

 # Function to get the actual vertice location
def GetLoc(VertCo, ObMat):
   x, y, z = VertCo
   tx = x * ObMat[0][0] + y * ObMat[1][0] + z * ObMat[2][0]
   ty = x * ObMat[0][1] + y * ObMat[1][1] + z * ObMat[2][1]
   tz = x * ObMat[0][2] + y * ObMat[1][2] + z * ObMat[2][2]
   return tx, ty, tz

 # Function to apply Size and Rotation
def ApplySizeRot(Obj):
   Msh = Obj.getData()
   for vert in Msh.verts:
      thisVert = GetLoc(vert.co, Obj.getMatrix())
      vert.co[0] = thisVert[0]
      vert.co[1] = thisVert[1]
      vert.co[2] = thisVert[2]
      Obj.SizeX = 1.0
      Obj.SizeY = 1.0
      Obj.SizeZ = 1.0
      Obj.RotX = 0
      Obj.RotY = 0
      Obj.RotZ = 0
   Msh.update()

 # Function to get the maximum width of an object
def GetMax(Obj):
   ApplySizeRot(Obj)
   Farthest = 0 
   for v in Obj.getData().verts:
      if abs(v[1]) > Farthest:
         Farthest = v[1]
      if abs(v[0]) > Farthest:
         Farthest = v[0]
   return Farthest

 # Function to scale building correctly
def ScaleTo(Obj, TargetS):
   Max = GetMax(Obj)
   i = 0.0
   ObjMsh = Obj.getData()
   ObjMat = Obj.getMatrix()
   s = float(len(ObjMsh.verts))
   for vertice in ObjMsh.verts:
      i += 1.0
      Window.DrawProgressBar(i/s, "Scaling")
      Mult = float((TargetS/2)/Max)
      vertice.co[0] = vertice.co[0] * Mult
      vertice.co[1] = vertice.co[1] * Mult
      vertice.co[2] = vertice.co[2] * Mult
   ObjMsh.update()


 # Building class
class Building:

    # Attributes
   Name = 'Building'
   PosX = 0.0
   PosY = 0.0
   PosZ = 0.0
   RtX = 0.0
   RtY = 0.0
   RtZ = 0.0
   
    # Functions
   def SetName(Self, N):
      self.Name = N

   def SetObjName(self, O):
      self.ObjName = O

   def SetLength(self, L):
      self.Length = L

   def SetWidth(self, W):
      self.Width = W

   def SetPosition(self, X, Y , Z):
      self.PosX = X
      self.PosY = Y
      self.PosZ = Z
      Blender.Object.Get(self.Name).setLocation(X, Y, Z)
 

   def SetRot(self, RX, RY , RZ):
      self.RtX = RX
      self.RtY = RY
      self.RtZ = RZ
      RX = RX/(180.0/pi)
      RY = RY/(180.0/pi)
      RZ = RZ/(180.0/pi)
      Blender.Object.Get(self.Name).setEuler(RX, RY, RZ)

   def SetSize(self, X, Y , Z):
      Blender.Object.Get(self.Name).SizeX = X
      Blender.Object.Get(self.Name).SizeY = Y
      Blender.Object.Get(self.Name).SizeZ = Z


   def Save(self, ON, FN, Sz):
      print "Saving building: " + self.Name
      BuildingObj = Blender.Object.Get(ON)
      ScaleTo(BuildingObj, Sz)
      BuildingMesh = BuildingObj.getData()

       # Get the mesh in the correct format
      Lowest = 10000
      for vert in BuildingMesh.verts:
         if vert.loc[2] < Lowest:
            Lowest = vert.loc[2]

      Lowest = abs(Lowest)
      for vert in BuildingMesh.verts:
         vert.loc[2] += Lowest

      OutFile = open(FN, "w")
      OutFile.write(self.Name + '\n')  
      for Vert in BuildingMesh.verts:
         OutFile.write('V\n')
         OutFile.write(str(Vert.co[0]) + " " +
                       str(Vert.co[1]) + " " +
                       str(Vert.co[2]) + '\n') 


      for Face in BuildingMesh.faces:
         OutFile.write('F\n')
         for Vert in Face:
            OutFile.write(str(Vert.index) + " ")
         OutFile.write('\n')

      if BuildingMesh.hasFaceUV():
         for Face in BuildingMesh.faces:
            if Face.image:
               OutFile.write("TN\n" + Face.image.filename + "\n")
               OutFile.write('U\n')
            i = 0
            for Vert in Face:
               OutFile.write(str(Face.uv[i][0]) + " ")
               OutFile.write(str(Face.uv[i][1]) + " ")
               i += 1
            OutFile.write('\n')
 
      OutFile.write('E')
      OutFile.close()
      print "Done saving: " + self.Name    

   def Load(self, FN):
      try:
         InFile = open(FN, "r")
      except:
         print ".bbf file does not exist"
         return

      Lines = 0
      print "Loading building: " + self.Name
      BuildingObj = Blender.Object.New("Mesh")
      BuildingMesh = NMesh.GetRaw()
      
      self.Name = str(InFile.readline())
      FV = str(InFile.readline())
      FV = FV.replace('\n', '') 
      i = 0  
      LastIStr = "NONE"
      while FV <> 'E' and Lines < 10000:
        
         Lines += 1
         if FV == 'V':
            CurVertStr = str(InFile.readline())
            CurVertStr = CurVertStr.replace('\n', '') 
            CurVert = string.split(CurVertStr, ' ')
            CurVert[0] = float(CurVert[0])
            CurVert[1] = float(CurVert[1])
            CurVert[2] = float(CurVert[2])
            BuildingMesh.verts.append(NMesh.Vert(CurVert[0],
                                      CurVert[1],
                                      CurVert[2]))

         
         if FV == 'F':
            NewFace = NMesh.Face()    
            CurIndStr = str(InFile.readline()) 
            CurIndStr = CurIndStr.replace('\n', '') 
            CurInd = string.split(CurIndStr, ' ')
            for Ind in CurInd:
               if Ind <> '':
                  Ind = int(Ind)
                  NewFace.v.append(BuildingMesh.verts[Ind])
              
            BuildingMesh.faces.append(NewFace)

          # New UV part
         if FV == 'TN':
            CurIStr = str(InFile.readline()) 
            CurIStr = CurIStr.replace('\n', '') 
            if CurIStr <> LastIStr:
               try:
                  im = Blender.Image.Load(CurIStr)
                  LastIStr = CurIStr
               except:
                  print "Texture not found: " + CurIStr 
                  
         if FV == 'U':
            CurFace = BuildingMesh.faces[i]
            CurFace.image = im  
            CurUVStr = str(InFile.readline()) 
            CurUVStr = CurUVStr.replace('\n', '') 
            UV = string.split(CurUVStr,' ')
 
            if len(BuildingMesh.faces[i].v) == 3:
               UVs = (float(UV[0]), float(UV[1]))
               CurFace.uv.append(UVs)   
               UVs = (float(UV[2]), float(UV[3]))
               CurFace.uv.append(UVs)   
               UVs = (float(UV[4]), float(UV[5]))
               CurFace.uv.append(UVs)   
            if len(BuildingMesh.faces[i].v) == 4:
               UVs = (float(UV[0]), float(UV[1]))
               CurFace.uv.append(UVs)   
               UVs = (float(UV[2]), float(UV[3]))
               CurFace.uv.append(UVs)   
               UVs = (float(UV[4]), float(UV[5]))
               CurFace.uv.append(UVs)   
               UVs = (float(UV[6]), float(UV[7]))
               CurFace.uv.append(UVs)   
            i += 1
                            
        
         FV = str(InFile.readline())
         FV = FV.replace('\n', '') 

      BuildingObj.setName(self.Name)
      BuildingObj.link(BuildingMesh)
      #BuildingObj.setMode(260)
      Blender.Scene.getCurrent().link(BuildingObj)
      InFile.close()
      self.Name = BuildingObj.getName()
      print "Done loading: " + self.Name
      Blender.Redraw() 

 # FN = Filename
 # L = Length
 # W = Width
 # V = Variable size
 # M = Maximum size
def CreateBlock(FN, L, W, V, M):
   try:
      InFile = open(FN, "r")
   except:
      print "ERROR:.bbl file does not exist"
      return
 
   FNs = []
   ObNameLst = []

   NrOfTypes = 0
   Mode = str(InFile.readline())
   Mode = Mode.replace('\n', '') 

   Count = 0
   while Mode <> 'E' and Count < 10000:
      Count += 1
      CurFN = str(InFile.readline())
      CurFN = CurFN.replace('\n', '')
      FNs.append(CurFN)
      Mode = str(InFile.readline())
      Mode = Mode.replace('\n', '') 
      NrOfTypes += 1

   if len(Blender.Object.GetSelected()) > 0:
      if Blender.Object.GetSelected()[0].getType() == "Mesh":
         print "Generating Buildings On Selected Object"
         for vert in Blender.Object.GetSelected()[0].getData().verts:
            vert = GetLoc(vert, Blender.Object.GetSelected()[0].getMatrix())
            r = int(random() * 270 / 90) * 90
            r2 = random() * V
            Bld = Building()
            Bld.Load(FNs[int(random() * NrOfTypes)])
            ol = Blender.Object.getSelected()[0].loc
            Bld.SetPosition(vert[0] + ol[0], vert[1] + ol[1], vert[2] + ol[2])
            Bld.SetRot(0, 0, r)
            Bld.SetSize(M - r2, M - r2, M - r2)
            ObNameLst.append(Bld.Name)        
      else:
         for i in range(0, L):
            for j in range(0, W):
               r = int(random() * 270 / 90) * 90
               r2 = random() * V
               Bld = Building()
               Bld.Load(FNs[int(random() * NrOfTypes)])
               Bld.SetPosition(i - L/2, j - W/2, 0)
               Bld.SetRot(0, 0, r)
               Bld.SetSize(M - r2, M - r2, M - r2)
               ObNameLst.append(Bld.Name)
   else:
      for i in range(0, L):
         for j in range(0, W):
            r = int(random() * 270 / 90) * 90
            r2 = random() * V
            Bld = Building()
            Bld.Load(FNs[int(random() * NrOfTypes)])
            Bld.SetPosition(i - L/2, j - W/2, 0)
            Bld.SetRot(0, 0, r)
            Bld.SetSize(M - r2, M - r2, M - r2)
            ObNameLst.append(Bld.Name)

   InFile.close()

def OutFileCB(FN):
   OutFile.val = FN

def InFileCB(FN):
   InFile.val = FN

def BBLInCB(FN):
   BBLIn.val = FN

def BBLSave(FN):
   global FileList
   BBLOut.val = FN
   OutFile = open(FN, "w")
   for FName in FileList:
      if FName <> "----":
         OutFile.write("FN\n")
         OutFile.write(FName + "\n")
   OutFile.write("E")

def BBLLoad(FN):
   global FileList, Next
   for i in range(0, 100):
      FileList[i] = "----"
   i = 0
   InFile = open(FN, "r")
   Mode = str(InFile.readline())
   Mode = Mode.replace('\n', '') 
   Count = 0
   while Mode <> 'E' and Count < 10000:
      CurFN = str(InFile.readline())
      CurFN = CurFN.replace('\n', '')
      Mode = str(InFile.readline())
      Mode = Mode.replace('\n', '') 
      FileList[i] = CurFN 
      i += 1
   Next = i 
   Register(GUI, Event, BEvent)


def AddBldCB(FN):
   global Next, Size
   BldName = FN
   FileList[Next] = BldName 
   Next += 1
   Register(GUI, Event, BEvent)
   

def RemFiles():
   print "Not yet implementes"
   
 # ------ GUI ------

 # Draw a group box
def GroupBox(x,y, w, h, r, g, b):
   glColor3f(0.0, 0.0, 0.0)
   glRecti(x, y, w, h)
   glColor3f(r, g, b)
   glRecti(x + 1, y + 1, w - 1, h - 1)
      
 # Events
PExit       = 1
PCreate     = 2
TBlock_Gen  = 3
TBBL_Gen    = 4
TSave_Bld   = 5
PSave       = 6
POutSelect  = 7
PBBLSelIn   = 8
PLoad       = 9
PInSelect   = 10
PBBLCreate  = 11
PBBLSave    = 12
PAddBld     = 13
PRemBld     = 14
TF1T        = 15
TF2T        = 16
TF3T        = 17
TF4T        = 18
PDown       = 19
PUp         = 20
PBBLLoad    = 21
PClearBBL   = 22
PHome       = 23
PCopyUp     = 24
PCopyDown   = 25
Slide       = 100

Nothing =1000

 # Controls
Block_Gen = Create(0)
BBL_Gen   = Create(0)
Bld_Save  = Create(0)
Length    = Create(6)
Width     = Create(6)
InFile    = Create(DefInFile)
OutFile   = Create(DefOutFile)	
BBLIn     = Create(DefBBLIn)
BBLOut    = Create(DefBBLOut)
BldMenStr = "List of Buildings %t"
BldMenu   = Create(0)
TF1       = Create(0)
TF2       = Create(0)
TF3       = Create(0)
TF4       = Create(0)
TF5       = Create(0)
SizeVar   = Create(0.1)
SizeMax   = Create(0.9)

def GUI():
   global Block_Gen, BBL_Gen, Bld_Save, Slide, Length, Width, Last
   global OutFile, BBLIn, BBLOut, InFile, BldMenu, TF1, TF2, TF3, TF4
   global First, Second, Third, Fourth, SizeVar, SizeMax
 
   glClearColor(0.8, 0.8, 0.8, 1.0)
   glClear(GL_COLOR_BUFFER_BIT)

    # Tabs
   Block_Gen = Toggle("Generate Block", TBlock_Gen, 25, 230, 100, 20, Block_Gen.val, "Generate City Blocks")
   BBL_Gen = Toggle("Generate .BBL", TBBL_Gen, 135, 230, 100, 20, BBL_Gen.val, "Generate .BBL files")
   Bld_Save = Toggle("Building", TSave_Bld, 245, 230, 100, 20, Bld_Save.val, "Manage .BBF files")
   
   GroupBox(11, 265, 147, 291, 0.9, 0.9, 0.9)
   GroupBox(13, 267, 145, 289, 0.7, 0.7, 0.7)
   glColor3f(0.0, 0.0, 0.0)
   glRasterPos2i(23, 274)
   Text("City Block Generator")
   glRasterPos2i(163, 274)
   Text("by Johan Badenhorst")
   Button("Exit", PExit, 300, 5, 50, 20)

   if Block_Gen.val == 1:
       # Groupbox
      GroupBox(15, 50, 345, 220, 0.85, 0.85, 0.85)

       # Block dimensions 
      glColor3f(0.0, 0.0, 0.0)
      glRasterPos2i(150, 204)
      Text("Dimensions")
      Length = Slider("Length: ", Slide, 20, 175, 150, 20, Length.val, 2, 10, 0)      
      Width = Slider("Width: ",  Slide, 190, 175, 150, 20, Width.val, 2, 10, 0)  

       # Input BBL file 
      glColor3f(0.0, 0.0, 0.0)
      glRasterPos2i(160, 154)
      Text("BBL file")    
      BBLIn = String("Filename: ", Nothing, 20, 125, 250, 20, BBLIn.val, 100)
      Button("Select", PBBLSelIn, 280, 125, 60, 20) 

       # Size
      glColor3f(0.0, 0.0, 0.0)
      glRasterPos2i(168, 104)
      Text("Size")    
      SizeVar = Slider("Var: ", Slide, 20, 75, 150, 20, SizeVar.val, 0.0, 0.4, 0,"Building Size variance")
      SizeMax = Slider("Max: ", Slide, 190, 75, 150, 20, SizeMax.val, 0.6, 1.0, 0,"Maximum size")

       # Create button
      Button("Create", PCreate, 150, 20, 70, 25)

   elif BBL_Gen.val == 1:

       #Groupbox
      GroupBox(15, 50, 345, 220, 0.85, 0.85, 0.85)

       # Building list
      Button("Up", PUp, 125, 195, 80, 20, "Scroll Up") 
      Button("Down", PDown, 125, 58, 80, 20, "Scroll Down") 
     
       # List Management buttons
      Button("Home", PHome, 25, 195, 80, 20, "Go to start of list") 
      Button("Add", PAddBld, 225, 195, 80, 20, "Add BBF to list") 
      Button("Remove", PRemBld, 225, 58, 80, 20, "Remove selected BBFs") 
      Button("Clear", PClearBBL, 25, 58, 80, 20, "Clear list of all files")

      GroupBox(25, 85, 305, 185, 0.75, 0.75, 0.75)  

      glColor3f(0.0, 0.0, 0.0)
      TF1 = Toggle(" ", TF1T, 315, 164, 20, 20, TF1.val, "Select")
      glRasterPos2i(30, 166)
      Text(str(First + 1) + ". " + FileList[First])         

      TF2 = Toggle(" ", TF2T, 315, 140, 20, 20, TF2.val, "Select")
      glRasterPos2i(30, 142)
      Text(str(Second + 1) + ". " + FileList[Second])   

      TF3 = Toggle(" ", TF3T, 315, 115, 20, 20, TF3.val, "Select")
      glRasterPos2i(30, 117)
      Text(str(Third + 1) + ". " + FileList[Third])   

      TF4 = Toggle(" ", TF4T, 315,  89, 20, 20, TF4.val, "Select")
      glRasterPos2i(30, 91)
      Text(str(Fourth + 1) + ". " + FileList[Fourth])   

       # Buttons to Save and Load BBL file
      Button("Load", PBBLLoad, 110, 20, 70, 25)
      Button("Save", PBBLSave, 190, 20, 70, 25)


   elif Bld_Save.val == 1:
       # Group box
      GroupBox(15, 50, 345, 220, 0.85, 0.85, 0.85)

       # Output building file name
      glColor3f(0.0, 0.0, 0.0)
      glRasterPos2i(150, 204)
      Text("Output file")
      OutFile = String("Filename: ", Nothing, 20, 175, 250, 20, OutFile.val, 100)
      Button("Select", POutSelect, 280, 175, 60, 20) 

       # Input building file name      
      glColor3f(0.0, 0.0, 0.0)
      glRasterPos2i(150, 154)
      Text("Input file")
      InFile = String("Filename: ", Nothing, 20, 125, 250, 20, InFile.val, 100)
      Button("Select", PInSelect, 280, 125, 60, 20)

       # Up and down copy buttons
      Button("/\\", PCopyUp, 20, 150, 30, 20, "Copy input file to top")
      Button("\\/", PCopyDown, 60, 150, 30, 20, "Copy output file to bottom")


       # Load and save buttond
      Button("Load", PLoad, 110, 20, 70, 25)
      Button("Save", PSave, 190, 20, 70, 25)

   else:
       # Group box
      GroupBox(15, 50, 345, 220, 0.7, 0.7, 0.7)
      GroupBox(20, 55, 340, 215, 0.85, 0.85, 0.85)
       # Welcome text
      glColor3f(0.0, 0.0, 0.0)
      glRasterPos2i(30, 174)
      Text("Welcome to City Block Generator. Click on the tabs")
      glRasterPos2i(30, 154)
      Text("to select the mode you require.")   
      glRasterPos2i(30, 134)
      Text("Blend On!")   
      glRasterPos2i(300, 90)
      Text("Ezual")  

def Event(evt, val):
   if not val:
      if evt == QKEY:
         Exit()

def BEvent(evt):
   global Block_Gen, BBL_Gen, Bld_Save, Last, Next
   global First, Second, Third, Fourth

   if evt == PBBLSelIn:
      try:
         Window.FileSelector(BBLInCB,"Select BBL In")
      except:
         print "ERROR" 
      return

   if evt == PCreate:
      CreateBlock(BBLIn.val, Length.val , Width.val, SizeVar.val, SizeMax.val)

   if evt == PBBLSave:
      Window.FileSelector(BBLSave,"Select BBL Out")

   if evt == PBBLLoad:
      Window.FileSelector(BBLLoad,"Select BBL Out")

   if evt == PHome:
      First = 0
      Second = 1
      Third  = 2
      Fourth = 3
      Register(GUI, Event, BEvent)

   if evt == PAddBld:
      Window.FileSelector(AddBldCB,"Select BBF file")   

   if evt == PClearBBL:
      for i in range(0, 100):
         FileList[i] = "----"
      Next = 0
      First = 0
      Second = 1
      Third  = 2
      Fourth = 3
      Register(GUI, Event, BEvent)
     
   if evt == PRemBld:
      if TF1.val <> 0:
         if FileList[First] <> "----":
            FileList[First] = "----"
            Next -= 1

      if TF2.val <> 0:
         if FileList[Second] <> "----":
            FileList[Second] = "----"
            Next -= 1

      if TF3.val <> 0:
         if FileList[Third] <> "----":
            FileList[Third] = "----"
            Next -= 1

      if TF4.val <> 0:
         if FileList[Fourth] <> "----":
            FileList[Fourth] = "----"
            Next -= 1

       # Sorting algorithm
      for h in range(0, 4):
         for i in range(0, 100):
            if i < 99:
               if FileList[i] == "----" and FileList[i+1] <> "----":
                     Temp = FileList[i]
                     FileList[i] = FileList[i + 1]
                     FileList[i + 1] = Temp 
      Register(GUI, Event, BEvent)

                      
 
    # Up and down buttons for scrollong
   if evt == PUp:
      if First > 0:
         First -= 1
      else:
         First = Size -1
 
      if Second > 0:
         Second -= 1
      else:
         Second = Size -1

      if Third > 0:
         Third -= 1
      else:
         Third = Size -1

      if Fourth > 0:
         Fourth -= 1
      else:
         Fourth = Size -1
      Register(GUI, Event, BEvent)
         
   if evt == PDown:
      if First < Size - 1:
         First += 1
      else:
         First = 0
      if Second < Size - 1:
         Second += 1
      else:
         Second = 0
      if Third < Size - 1:
         Third += 1
      else:
         Third = 0
      if Fourth < Size - 1:
         Fourth += 1
      else:
         Fourth = 0
      Register(GUI, Event, BEvent)

   if evt == POutSelect:
      Window.FileSelector(OutFileCB,"Select Output File")

   if evt == PInSelect:
      Window.FileSelector(InFileCB,"Select Output File")

   if evt == PCopyUp:
      OutFile.val = InFile.val      
      Register(GUI, Event, BEvent)

   if evt == PCopyDown:
      InFile.val = OutFile.val
      Register(GUI, Event, BEvent)

   if evt == PSave:
      try:
         Bld = Building()
         Bld.Save(Blender.Object.GetSelected()[0].getName(), OutFile.val, 0.8)
         del Bld
      except:
         print "No object selected"

   if evt == PLoad:
      Bld = Building()
      Bld.Load(InFile.val)
      del Bld

   if evt == PExit:
      Exit() 

   if evt == Slide:
      Register(GUI, Event, BEvent)

    # Manage active tab
   if evt == TBlock_Gen:
      if Block_Gen.val == 1:
         BBL_Gen.val = 0
         Bld_Save.val = 0
      Register(GUI, Event, BEvent)

   if evt == TBBL_Gen:
      if BBL_Gen.val == 1:
         Block_Gen.val = 0
         Bld_Save.val = 0
      Register(GUI, Event, BEvent)

   if evt == TSave_Bld:
      if Bld_Save.val == 1:
         BBL_Gen.val = 0
         Block_Gen.val = 0
      Register(GUI, Event, BEvent)
      
Register(GUI, Event, BEvent)

Blender.Redraw()  