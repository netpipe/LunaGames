#!BPY

"""
Name: 'Projection Merge'
Blender: 247
Group: 'Mesh'
Tooltip: 'Project two edges and merge them where they intersect.'
"""

__author__ = "FourMadMen.com (FourMadMen)"
__url__ = ["Script's homepage, http://www.fourmadmen.com/blender/scripts/4mm_projection_merge.html", "blender", "blenderartists"]
__version__ = "1.0 2008/09/30"

__bpydoc__ = """\
This script will compute the intersection of two edges and merge them at the
point of intersection.

Usage:<br>
  From edit mode (works in object mode too however), select two edges and run this script.
  Script link is under Script -> Mesh -> Projection Merge
"""

# --------------------------------------------------------------------------
# $Id: 4mm_projection_merge.py,v 1.0 2008/09/30 01:00:00
# --------------------------------------------------------------------------
#
# --------------------------------------------------------------------------
# Projection Merge v1.0
# by FourMadMen, 2008
# This script is protected by the GPL: Gnu Public Licence
# GPL - http://www.gnu.org/copyleft/gpl.html
# --------------------------------------------------------------------------
# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****
# --------------------------------------------------------------------------

#Press Alt-P to run

import Blender
from Blender import Window, Draw, Object, Mathutils, Mesh

EPSILON = 0.00001

def message(msg):
	Draw.PupMenu(msg)
#end message

def process(me):
	selected = [edge for edge in me.edges if edge.sel==1]
	
	if len(selected)==2:
		e1 = selected[0]
		e2 = selected[1]
		
		rc = Mathutils.LineIntersect(e1.v1.co, e1.v2.co, e2.v1.co, e2.v2.co)
		print "rc", rc
		
		if rc==None:
			message("Edges do not intersect")
		else:
			dx = abs(rc[0][0] - rc[1][0])
			dy = abs(rc[0][1] - rc[1][1])
			dz = abs(rc[0][2] - rc[1][2])
			
			if dx<EPSILON and dy<EPSILON and dz<EPSILON:
				v = Mesh.MVert(rc[0])
				print v
				
				#For edge 1 get vertex closest to v
				dist1 = ((v.co[0]-e1.v1.co[0])**2 + (v.co[1]-e1.v1.co[1])**2 + (v.co[2]-e1.v1.co[2])**2) ** 0.5
				dist2 = ((v.co[0]-e1.v2.co[0])**2 + (v.co[1]-e1.v2.co[1])**2 + (v.co[2]-e1.v2.co[2])**2) ** 0.5
				
				if dist1<dist2:
					e1.v1.co = v.co
				else:
					e1.v2.co = v.co
				#end if
				
				#For edge 2 get vertex closest to v
				dist1 = ((v.co[0]-e2.v1.co[0])**2 + (v.co[1]-e2.v1.co[1])**2 + (v.co[2]-e2.v1.co[2])**2) ** 0.5
				dist2 = ((v.co[0]-e2.v2.co[0])**2 + (v.co[1]-e2.v2.co[1])**2 + (v.co[2]-e2.v2.co[2])**2) ** 0.5
				
				if dist1<dist2:
					e2.v1.co = v.co
				else:
					e2.v2.co = v.co
				#end if
				
				me.remDoubles(0.0)
				message("1 vertex removed")
			else:
				message("Edges do not intersect")
			#end if
		#end if
	else:
		message('Must select exactly two edges')
	#end if
	
#end process

mesh = None
if len(Object.GetSelected()) > 0:
	object = Object.GetSelected()[0]
	
	if object.getType() == 'Mesh':
		mesh = Object.GetSelected()[0].getData(mesh=1)
	else:
		message('Selected object is not a Mesh')
	#end if
else:
	message('No object selected.')			
#end if

if mesh != None:
	is_editmode = Window.EditMode()
	if is_editmode:	Window.EditMode(0)
	
	process(mesh)
	
	if is_editmode:	Window.EditMode(1)
#end if
