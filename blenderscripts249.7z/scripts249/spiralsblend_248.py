#!BPY

"""
Name: '_Spiral Creator_248'
Blender: 248
Group: 'Misc'
Tooltip: 'Create spirals & Gears'
"""
__author__ = "Henry Florence"
__url__ = ("http://wiki.blender.org/index.php/Scripts/Manual/Misc/Spiral_Creator")
__version__ = "1.0"
__bpydoc__ = """\
spiralsblend.py. 

This script creates spirals & gears.

"""

# -------------------------------------------------------------------------- 
# spiralsblend_248.py
# Spiral Creator v0.6
# copyright 2005 Henry Florence
# -------------------------------------------------------------------------- 
# ***** BEGIN GPL LICENSE BLOCK ***** 
# 
# This program is free software; you can redistribute it and/or 
# modify it under the terms of the GNU General Public License 
# as published by the Free Software Foundation; either version 2 
# of the License, or (at your option) any later version. 
# 
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
# GNU General Public License for more details. 
# 
# You should have received a copy of the GNU General Public License 
# along with this program; if not, write to the Free Software Foundation, 
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. 
# 
# ***** END GPL LICENCE BLOCK ***** 
# -------------------------------------------------------------------------- 



from math import *
import Blender
from Blender import NMesh, Window, Object
#print "initialising spiralsblender..."

def cog(teeth = 5, hole = 1.15, hub = 2.0, radius = 3.0, ttaper = 0.8, depth = 0.75, ctaper = 1.12, subsurf = 0, smooth = 1):

	is_editmode = Window.EditMode()
	if(is_editmode): Window.EditMode(0, "Create Cog")
	
	me = NMesh.GetRaw()
	
	#loop to create inner and outer vertex rings
	ringsize 	= [hole, hole * ctaper, hub, hub * ctaper]
	ringheight 	= [depth, 0, depth, 0]
	
	for ring in range(0, len(ringsize)):
		for n in range(1, teeth * 2 + 1):
			
			#polygon thereom or something!
			ang	= 2 * pi / (teeth * 2) * n
			
			#polar coordinates
			x 	= ringsize[ring] * cos(ang)
			y		= ringsize[ring] * sin(ang)
			v 	= NMesh.Vert(x, y, ringheight[ring])
				
			me.verts.append(v)
		
	
	#Outer rings of verts for teeth
	
	#some trig
	ang			= 2 * pi / teeth
	toothsize 	= sin(ang / 4 ) * hub * ttaper * 2
	a			= toothsize	/ 2
	b			= radius * cos(ang / 4)
	r			= sqrt(a ** 2 + b ** 2)
	theta		= atan(a / b) 
	
	#create outer vertices 
	set1 = [-theta, theta]
	set2 = [depth, 0] 
	set3 = [1, ctaper]
	
	for n2 in range(0, len(set2)):	
		for n in range(0, teeth):
			for offset in set1: 
				#vertex teeth outer edges
				x		= r * cos(ang * n + ang / 4 + offset) * set3[n2]
				y		= r * sin(ang * n + ang / 4 + offset) * set3[n2]
				v		= NMesh.Vert(x, y, set2[n2])
		
				me.verts.append(v)	
	
	#loop to create face rings
	set1 = [0, teeth * 6, teeth * 4, teeth * 2] #, teeth * 4 - 1]
	set2 = [teeth * 2, teeth * 4, 0, teeth * 6] #, teeth * 8]
	gaps = [1, 2, 1, 1] #, 2]
	
	for ring in range(0, len(set1)):
		for n in range(0, teeth * 2, gaps[ring]):
			#print "----"
			#print "verts:"
			
			f = NMesh.Face()
			f.v.append(me.verts[set1[ring] + n])
			#print str(set1[ring] + n)
		
			#if circle => last face uses first vertices
			if(n == teeth * 2 - 1):
				#print str(set1[ring])
				f.v.append(me.verts[set1[ring]])
				#print str(set2[ring])
				f.v.append(me.verts[set2[ring]])
			else:
				#print str(set1[ring] + n + 1)
				f.v.append(me.verts[set1[ring] + n + 1])
				#print str(set2[ring] + n + 1)
				f.v.append(me.verts[set2[ring] + n + 1])
			
			#print str(set2[ring] + n)
			f.v.append(me.verts[set2[ring] + n])
			print "face normal: " + str(f.no)		
			
			me.faces.append(f)
		
	#Skin teeth
	set1a = [teeth * 6 - 1] + 	[n for n in range(teeth * 4, teeth * 6 - 1)]
	set1b = [n for n in range(teeth * 8, teeth * 10)]
	set2a = [n for n in range(teeth * 10, teeth * 12)]
	set2b = [teeth * 8 - 1] + 	[n for n in range(teeth * 6, teeth * 8 - 1)]
	
	set3a = []
	set3b = []
	
	for n in range(0, teeth):	
		set3a.append(teeth * 4 + n * 2 - 1)
		set3a.append(teeth * 8 + n * 2)
		set3a.append(teeth * 8 + n * 2)
		set3a.append(teeth * 8 + n * 2 + 1)
		set3a.append(teeth * 8 + n * 2 + 1)
		set3a.append(teeth * 4 + n * 2)
	
	set3a[0] = teeth * 6 - 1
	
	for n in range(0, teeth):
		set3b.append(teeth * 6 + n * 2 - 1)
		set3b.append(teeth * 10 + n * 2)
		set3b.append(teeth * 10 + n * 2)
		set3b.append(teeth * 10 + n * 2 + 1)
		set3b.append(teeth * 10 + n * 2 + 1)
		set3b.append(teeth * 6 + n * 2)
	
	set3b[0] = teeth * 8 - 1
	
	list1 = [set1a, set2a, set3a]
	list2 = [set1b, set2b, set3b]
	
	#print "again, again, again!"
	#print "set1: " + str(set1)
	#print "set2: " + str(set2)
	#print "list1: " + str(list1) + ", len(list1) = " + str(len(list1))
	#print "list2: " + str(list2) + ", len(list2) = " + str(len(list2))
	
	
	for n1 in range(0, len(list1)):
		for n2 in range(0, len(list1[n1]), 2):
			f = NMesh.Face()
		
			#print "n1 = " + str(n1) + ", n2 = " + str(n2)
			#print "----"
			#print "verts"
			f.v.append(me.verts[list1[n1][n2]])
			#print str(list1[n1][n2])
			f.v.append(me.verts[list2[n1][n2]])
			#print str(list2[n1][n2])
			f.v.append(me.verts[list2[n1][n2+1]])
			#print str(list2[n1][n2+1])
			f.v.append(me.verts[list1[n1][n2+1]])
			#print str(list1[n1][n2+1])
	
			me.faces.append(f)
	
	#Subsurf
	#if(subsurf):
	#	me.setMode(SUBSURF)
	#	me.setSubDivLevels([1, 1])
	
	#Smooth
	if(smooth):	
		for n in me.faces:
			n.smooth = 1
	
	NMesh.PutRaw(me, "cog",1)
	Blender.Redraw()
			
	Window.EditMode(is_editmode)
	
	#enter/exit(or exit/enter, ;-) editmode to update!?!
	Window.EditMode(not is_editmode)
	Window.EditMode(is_editmode)
	
	return me
		
def logspiral(a = 1, b = 8 ** -3, totalvert=60, res=20):
	   
	#print "logspiral"
	me = NMesh.GetRaw()
   
	#Plot the points on the spiral
	for t1 in range(1, totalvert):
		t = t1*res
		x = a * e ** (t * b) * cos(t/180.*pi)
		y = a * e ** (t * b) * sin(t/180.*pi)
		v = NMesh.Vert(x, y, 0.0)
		me.verts.append(v)
		v = NMesh.Vert(x, y, -0.5)
		me.verts.append(v)
  
	#Connect them together
	for t in range(0, totalvert * 2 - 4, 2):
		f=NMesh.Face()
		f.v.append(me.verts[t])	
		f.v.append(me.verts[t+1])
		f.v.append(me.verts[t+3])
		f.v.append(me.verts[t+2])
		me.faces.append(f)
	
	NMesh.PutRaw(me, "spiral",1)
	Blender.Redraw()
	
	return me	
		
def fermatspiral (a = .3, totalvert = 60, res = 20):
   
	me = NMesh.GetRaw()

	#Plot the points on the spiral
	for t1 in range(1, totalvert):
		t = t1*res
		x = sqrt(a ** 2 * t) * cos(t/180.*pi)
		y = sqrt(a ** 2 * t) * sin(t/180.*pi)
		v = NMesh.Vert(x, y, 0.0)
		me.verts.append(v)
		v = NMesh.Vert(x, y, -0.5)
		me.verts.append(v)

	#Connect them together
	for t in range(0, totalvert * 2 - 4, 2):
		f=NMesh.Face()
		f.v.append(me.verts[t])
		f.v.append(me.verts[t+1])
		f.v.append(me.verts[t+3])
		f.v.append(me.verts[t+2])
		me.faces.append(f)
	
	NMesh.PutRaw(me, "fermatspiral",1)
	Blender.Redraw()
	return me	

def archspiral(a = .15 , b = 1.7, totalvert = 60, res = 20):
    
 	me = NMesh.GetRaw()
   
	#Plot the points on the spiral
	for t1 in range(1, totalvert):
		t = t1*res
		x = a * t ** (1 / b) * cos(t/180.*pi)
		y = a * t ** (1 / b) * sin(t/180.*pi)
		v = NMesh.Vert(x, y, 0.0)
		me.verts.append(v)
		v = NMesh.Vert(x, y, -0.5)
		me.verts.append(v)
  
	#Connect them together
	for t in range(0, totalvert * 2 - 4, 2):
		f=NMesh.Face()
		f.v.append(me.verts[t])
		f.v.append(me.verts[t+1])
		f.v.append(me.verts[t+3])
		f.v.append(me.verts[t+2])
		me.faces.append(f)
	
	NMesh.PutRaw(me, "archspiral",1)
	Blender.Redraw()
	return me	

####################### gui ######################
from Blender import BGL
from Blender import Draw
#from Blender import Registry

#Interface events
EVENTHASH = {
    'NOEVENT': 1,
    'REDRAW': 2,
    'EXIT': 3,
    'DO': 4,
    'SAVE': 5,
    'LOAD': 6,
	}

STATEHASH = {
	'LOG'		: Draw.Create(1),	'LOG_EV'	: 100,
	'ARCH'		: Draw.Create(0),	'ARCH_EV'	: 101,
	'FERMAT'	: Draw.Create(0),	'FERMAT_EV'	: 102,
	'COG'		: Draw.Create(0),	'COG_EV'	: 103
	}

LOGHASH = {
	'a'			: Draw.Create(1.0),
	'b'			: Draw.Create(2 * 10 ** -3),
	'totalvert'	: Draw.Create(60),
	'res'		: Draw.Create(20)
	}

ARCHHASH = {
	'a'			: Draw.Create(.15),
	'b'			: Draw.Create(1.7),
	'totalvert'	: Draw.Create(60),
	'res'		: Draw.Create(20)
	}

FERMATHASH = {
	'a'			: Draw.Create(.3),
	'totalvert'	: Draw.Create(60),
	'res'		: Draw.Create(20)
	}

COGHASH = {
	'teeth'		: Draw.Create(5),
	'hole'		: Draw.Create(1.15),
	'hub'		: Draw.Create(2.0),
	'radius'	: Draw.Create(3.0),
	'ttaper'	: Draw.Create(0.8),
	'depth'		: Draw.Create(0.75),
	'ctaper'	: Draw.Create(1.12),
	'subsurf'	: Draw.Create(0),
	'smooth'	: Draw.Create(1)
	}


#print "going all gui.."
	
def update_registry():
	d = {}
	d['STATEHASH'] 	= STATEHASH
	d['LOGHASH'] 		= LOGHASH
	d['ARCHHASH']		= ARCHHASH
	d['FERMATHASH']	= FERMATHASH
	d['COGHASH']		= COGHASH
	
	#Blender.Registry.SetKey('Spiralsblend', d, True)
	
#def get_registry():
	
	#rdict = Registry.GetKey('Spiralsblend', True)
	
	#if rdict:
	#	try:
	#		STATEHASH 	= rdict['STATEHASH']
	#		LOGHASH			= rdict['LOGHASH']
	#		ARCHHASH		= rdict['ARCHHASH']
	#		FERMATHASH	= rdict['FERMATHASH']
	#		COGHASH			= rdict['COGHASH']
	#	except: update_Registry()
	
def colorbox(x,y,xright,bottom):
	BGL.glColor3f(0.75, 0.75, 0.75)
	BGL.glRecti(x + 1, y + 1, xright - 1, bottom - 1)

def gui():
	global STATEHASH
	global LOGHASH, ARCHHASH,FERMATHASH
	
	#Color boxes
	colorbox(8,220,312,40)
	BGL.glColor3f(0.0,0.0,0.0)
	BGL.glRasterPos2d(12, 210)
	Draw.Text("Parameters:")
	
	#Toggle buttons
	STATEHASH['LOG'] = Draw.Toggle(
        "Log",STATEHASH['LOG_EV'],10,240,75,20,STATEHASH['LOG'].val,
        "Nature's own logarithmic Spiral")
	STATEHASH['ARCH'] = Draw.Toggle(
        "Arch",STATEHASH['ARCH_EV'],85,240,75,20,STATEHASH['ARCH'].val,
        "Archimesean Spiral")
	STATEHASH['FERMAT'] = Draw.Toggle(
				"Fermat",STATEHASH['FERMAT_EV'],160,240,75,20,STATEHASH['FERMAT'].val,
				"Special kind of Archimedean Spiral")
	STATEHASH['COG'] = Draw.Toggle(
				"Cog",STATEHASH['COG_EV'],235,240,75,20,STATEHASH['COG'].val,
				"Simple cartoon cogs")

	#State dependent gubbins
	if(STATEHASH['LOG'].val == 1):
		LOGHASH['a'] = Draw.Slider(
			"Size: ", EVENTHASH['NOEVENT'], 20, 184, 278, 18,
			LOGHASH['a'].val, 0.5, 20.0 , 0,
			"Size")
		LOGHASH['b'] = Draw.Slider(
            "Rate: ", EVENTHASH['NOEVENT'], 20, 164, 278, 18,
            LOGHASH['b'].val, 1 * 10 ** -4, 1 * 10 ** -2, 0,
            "Spiral tightness")
		LOGHASH['totalvert'] = Draw.Slider(
            "No of Verts: ", EVENTHASH['NOEVENT'], 20, 144, 278, 18,
            LOGHASH['totalvert'].val, 10, 400 , 0,
            "Total Number of verts")
		LOGHASH['res'] = Draw.Slider(
            "Resolution: ", EVENTHASH['NOEVENT'], 20, 124, 278, 18,
            LOGHASH['res'].val, 1, 100, 0,
            "Spacing between vertices")
	elif(STATEHASH['ARCH'].val == 1):
		ARCHHASH['a'] = Draw.Slider(
            "Size: ", EVENTHASH['NOEVENT'], 20, 184, 278, 18,
            ARCHHASH['a'].val, 0.01, 0.3, 0,
            "Size")
		ARCHHASH['b'] = Draw.Slider(
            "Rate: ", EVENTHASH['NOEVENT'], 20, 164, 278, 18,
            ARCHHASH['b'].val, 1, 5, 0,
            "Spiral tightness")
		ARCHHASH['totalvert'] = Draw.Slider(
            "No of Verts: ", EVENTHASH['NOEVENT'], 20, 144, 278, 18,
            ARCHHASH['totalvert'].val, 10, 400 , 0,
            "Total Number of verts")
		ARCHHASH['res'] = Draw.Slider(
            "Resolution: ", EVENTHASH['NOEVENT'], 20, 124, 278, 18,
            ARCHHASH['res'].val, 1, 100, 0,
            "Spacing between vertices")
	elif(STATEHASH['FERMAT'].val == 1):
		FERMATHASH['a'] = Draw.Slider(
            "Size: ", EVENTHASH['NOEVENT'], 20, 184, 278, 18,
            FERMATHASH['a'].val, 0.1, 1, 0,
            "Size")
		FERMATHASH['totalvert'] = Draw.Slider(
            "No of Verts: ", EVENTHASH['NOEVENT'], 20, 144, 278, 18,
            FERMATHASH['totalvert'].val, 10, 400 , 0,
            "Total Number of verts")
		FERMATHASH['res'] = Draw.Slider(
            "Resolution: ", EVENTHASH['NOEVENT'], 20, 124, 278, 18,
            FERMATHASH['res'].val, 1, 100, 0,
            "Spacing between vertices")
	elif(STATEHASH['COG'].val==1):
		COGHASH['teeth'] = Draw.Slider(
            "No of teeth: ", EVENTHASH['NOEVENT'], 20, 184, 278, 18,
            COGHASH['teeth'].val, 3, 21, 0,
            "No of teeth")
		COGHASH['hole'] = Draw.Slider(
            "Hole: ", EVENTHASH['NOEVENT'], 20, 164, 278, 18,
            COGHASH['hole'].val, 0.1, 10.0, 0,
            "Size of hole in centre")
		COGHASH['hub'] = Draw.Slider(
            "Hub: ", EVENTHASH['NOEVENT'], 20, 144, 278, 18,
		COGHASH['hub'].val, 0.2, 11.0, 0,
            "Radius of hub")
		COGHASH['radius'] = Draw.Slider(
            "Outside radius: ", EVENTHASH['NOEVENT'], 20, 124, 278, 18,
            COGHASH['radius'].val, 0.3, 12, 0,
            "Total Radius")
		COGHASH['ttaper'] = Draw.Slider(
            "Tooth taper: ", EVENTHASH['NOEVENT'], 20, 104, 278, 18,
            COGHASH['ttaper'].val, 0, 2, 0,
            "Tooth taper")
		COGHASH['depth'] = Draw.Slider(
            "Depth: ", EVENTHASH['NOEVENT'], 20, 84, 278, 18,
            COGHASH['depth'].val, 0.1, 10, 0,
            "Thickness of cog")
		COGHASH['ctaper'] = Draw.Slider(
            "Cog Taper: ", EVENTHASH['NOEVENT'], 20, 64, 278, 18,
            COGHASH['ctaper'].val, 0, 2, 0,
            "Cog Taper")
		COGHASH['subsurf'] = Draw.Toggle(
						"SubSurf", EVENTHASH['NOEVENT'],20,44,75,20,COGHASH['subsurf'].val,
						"Catmull/Clark Surface subdivision")
		COGHASH['smooth'] = Draw.Toggle(
						"Smooth", EVENTHASH['NOEVENT'],95,44,75,20,COGHASH['smooth'].val,
						"Super smooth")
	
	Draw.Button("Create", EVENTHASH['DO'], 8, 9, 304, 19)
	
def event(evt, val):
	if (evt == Draw.ESCKEY and not val): 
		update_registry()
		Draw.Exit()
		
def bevent(evt):
	
	#Toggle buttons that change each other!
	if (evt == STATEHASH['LOG_EV']):
		STATEHASH['LOG'].val 	= 1
		STATEHASH['ARCH'].val 	= 0
		STATEHASH['FERMAT'].val = 0
		STATEHASH['COG'].val 	= 0
	elif (evt == STATEHASH['ARCH_EV']):
		STATEHASH['LOG'].val 	= 0
		STATEHASH['ARCH'].val 	= 1
		STATEHASH['FERMAT'].val = 0
		STATEHASH['COG'].val 	= 0
	elif (evt == STATEHASH['FERMAT_EV']):
		STATEHASH['LOG'].val 	= 0
		STATEHASH['ARCH'].val 	= 0
		STATEHASH['FERMAT'].val = 1
		STATEHASH['COG'].val 	= 0
	elif (evt == STATEHASH['COG_EV']):
		STATEHASH['LOG'].val 	= 0
		STATEHASH['ARCH'].val 	= 0
		STATEHASH['FERMAT'].val = 0
		STATEHASH['COG'].val 	= 1
		
	Draw.Redraw()
	
	
	#Time to draw a spiral?
	if(evt == EVENTHASH['DO']):
		if(STATEHASH['FERMAT'].val):
			me = fermatspiral(FERMATHASH['a'].val, FERMATHASH['totalvert'].val, FERMATHASH['res'].val)
		elif(STATEHASH['ARCH'].val):
			me = archspiral(ARCHHASH['a'].val, ARCHHASH['b'].val, ARCHHASH['totalvert'].val, ARCHHASH['res'].val)
		elif(STATEHASH['COG'].val):
			me = cog(COGHASH['teeth'].val, COGHASH['hole'].val, COGHASH['hub'].val, COGHASH['radius'].val, COGHASH['ttaper'].val, COGHASH['depth'].val, COGHASH['ctaper'].val, COGHASH['subsurf'].val, COGHASH['smooth'].val)
		else:
			me = logspiral(LOGHASH['a'].val, LOGHASH['b'].val, LOGHASH['totalvert'].val, LOGHASH['res'].val)
			

#get_registry()
Draw.Register(gui, event, bevent)


#fermatspiral(.3)