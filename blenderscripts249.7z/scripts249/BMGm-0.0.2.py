#!BPY

"""
Name: 'Blender Mechanical Gears'
Blender: 235
Group: 'Mesh'
Tooltip: 'Make involute-type gears'
"""

#############################################################
#                                                           #
# Blender Mechanical Gears                                  #
#                                                           #
# (C) November 2004 Stefano <S68> Selleri                   #
# Released under the Blender Artistic Licence (BAL)         #
# See www.blender.org                                       #
#                                                           #
# This Script has been developed under the inspiration of   #
# Blender 1.72 script "Grinder" By Jonathan Merritt         #
# developed in 1999. This original script was quite out of  #
# date but still usefull! Thanks Jonathan!                  #
#############################################################
# History                                                   #
# V: 0.0.0 - 03-11-04 - The script starts to take shape, an #
#                       history is now deserved :)          #
#            13-11-04 - Spur and Helical gears do work.     #
#                       Now it is time to have Conical      #
# V: 0.0.1 - 20-11-04 - Bugfixing                           #
#                       Adding Rack                         #
# V: 0.0.2 - 23-11-04 - General Interface re-organization   #
#                       Some sort of warnings...            #
#############################################################

import Blender
from Blender import *
from math import *

#############################################################
# GLOBALS                                                   #
#############################################################
VERSION         ='0.0.2'

#############################################################
# INTERFACE EVENTS                                          #
#############################################################
EVENTHASH = {
    'NOEVENT': 1,
    'REDRAW': 2,
    'EXIT': 3,
    'DO': 4,
    'SAVE': 5,
    'LOAD': 6,

    }

DLG_OK = 500

#############################################################
# GLOBALS                                                   #
#############################################################
STATEHASH = {
    'CYL' : Draw.Create(1), 'CYL_EV' : 100,
    'CON' : Draw.Create(0), 'CON_EV' : 101,
    'WOR' : Draw.Create(0), 'WOR_EV' : 102,
    
    'NOP' : Draw.Create(0), 'NOP_EV' : 110,
    'PIN' : Draw.Create(1), 'PIN_EV' : 111,
    'RAC' : Draw.Create(0), 'RAC_EV' : 112,
    'CRO' : Draw.Create(0), 'CRO_EV' : 113

    }

TOOTHHASH = {
    'PitchRadius' : Draw.Create(5.0),
    'TeethN'      : Draw.Create(20),
    'PressureAng' : Draw.Create(20.0),
    'Addendum'    : Draw.Create(0.4),
    'Dedendum'    : Draw.Create(0.4),
    'Fillet'      : Draw.Create(0.1),
    'Bevel'       : Draw.Create(0.05),
    'Resolution'  : Draw.Create(2),
    'Thickness'   : Draw.Create(1.0),
    'LongRes'     : Draw.Create(2),
    'HelicalAng'  : Draw.Create(0.0),
    'Width'       : Draw.Create(1.0),
    'Alpha'       : Draw.Create(90.0)
    }

PINIONHASH = {
    'TeethN'      : Draw.Create(12),
    }

    
ErrorMessage=''

#############################################################
# ERRORDIALOG                                               #
#############################################################
def ErrorDialog():
    global ErrorMessage

    global DLG_OK
    
    BGL.glClearColor(0.5, 0.5, 0.5, 0.0)
    BGL.glClear(BGL.GL_COLOR_BUFFER_BIT)
    BGL.glColor3f(0, 0, 0) 			# Black
    BGL.glRectf(2, 100, 482, 320)
    BGL.glColor3f(0.6, 0.1, 0.1) 		# Dark Red
    BGL.glRectf(4, 282, 480, 318)
    BGL.glRectf(4, 102, 480, 262)

    #############################################################
    # Common Header                                             #
    #############################################################

    BGL.glColor3f(1., 1., 0.6)
    BGL.glRasterPos2d(10, 305)
    Draw.Text("Blender Mechanical Gears v. "+VERSION)
    BGL.glRasterPos2d(10, 289)
    Draw.Text("(C) November 2004 Stefano Selleri <a.k.a. S68>")
    BGL.glColor3f(1.0, 1.0, 0.4)
    w = Draw.GetStringWidth('ERROR','normal')
    BGL.glRasterPos2d(240-w/2, 269)
    Draw.Text("ERROR")
    Draw.Button("OK", DLG_OK, 407, 287, 70, 24)

    EM = ErrorMessage
    i = 0
    BGL.glColor3f(1., 1., 0.6)
    while (EM != ''):
        s = EM[0:64]
        EM = EM[64:]
        try:
            cr = re.search(r'\n',s).start()
        except:
            cr = -1

        if( cr >- 1 ):
            EM = s[cr+1:]+EM
            s = s[0:cr]
        
        BGL.glRasterPos2d(10, 249-i*15)
        Draw.Text(s)
        i = i + 1
        
####################################################################
#CREATES THE BASE INVOLUTE PROFILE
####################################################################
def ToothOutline():
    global TOOTHGEO
    
    ####################################################################
    #Basic Math computations: Radii
    #
    R = {
        'Bottom'  : TOOTHGEO['PitchRadius'] - TOOTHGEO['Dedendum'] - TOOTHGEO['Fillet'],
        'Ded'     : TOOTHGEO['PitchRadius'] - TOOTHGEO['Dedendum'],
        'Base'    : TOOTHGEO['PitchRadius'] * cos(TOOTHGEO['PressureAng']*pi/180.0),
        'Bevel'   : TOOTHGEO['PitchRadius'] + TOOTHGEO['Addendum'] - TOOTHGEO['Bevel'],
        'Add'     : TOOTHGEO['PitchRadius'] + TOOTHGEO['Addendum']
    }

    ####################################################################
    #Basic Math computations: Angles
    #
    DiametralPitch = TOOTHGEO['TeethN']/(2*TOOTHGEO['PitchRadius'])
    ToothThickness = 1.5708/DiametralPitch
    CircularPitch  = pi / DiametralPitch

    U1 = sqrt((1-cos(TOOTHGEO['PressureAng']*pi/180.0))/
                   cos(TOOTHGEO['PressureAng']*pi/180.0))
    U2 = sqrt(R['Bevel']*R['Bevel']/(R['Ded']*R['Ded'])-1)

    ThetaA1 = atan((sin(U1)-U1*cos(U1))/(cos(U1)+U1*sin(U1)))
    ThetaA2 = atan((sin(U2)-U2*cos(U2))/(cos(U2)+U2*sin(U2)))
    ThetaA3 = ThetaA1 + ToothThickness/(TOOTHGEO['PitchRadius']*2.0)
    
    A = {
        'Theta0' : CircularPitch/(TOOTHGEO['PitchRadius']*2.0),
        'Theta1' : ThetaA3 + TOOTHGEO['Fillet']/R['Ded'],
        'Theta2' : ThetaA3,
        'Theta3' : ThetaA3 - ThetaA2,
        'Theta4' : ThetaA3 - ThetaA2 - TOOTHGEO['Bevel']/R['Add']
    }
    
    ####################################################################
    # Profiling
    #
    N = TOOTHGEO['Resolution']
    points  = []
    normals = []   
    # Top half bottom of tooth
    for i in range(2*N):
        th = (A['Theta1'] - A['Theta0'])*i/(2*N-1) + A['Theta0']              
        points.append ([R['Bottom']*cos(th),
                        R['Bottom']*sin(th)])
        normals.append([-cos(th),
                        -sin(th)])
        
    # Bottom Fillet
    xc = R['Ded']*cos(A['Theta1'])
    yc = R['Ded']*sin(A['Theta1'])
    Aw = pi/2.0 + A['Theta2'] - A['Theta1']
    for i in range(N):
        th = (Aw)*(i+1)/(N) + pi + A['Theta1']
        points.append ([xc + TOOTHGEO['Fillet']*cos(th),
                        yc + TOOTHGEO['Fillet']*sin(th)])
        normals.append([cos(th),
                        sin(th)])

    # Straight part
    for i in range(N):
        r = (R['Base']-R['Ded'])*(i+1)/(N) + R['Ded']              
        points.append ([r*cos(A['Theta2']),
                        r*sin(A['Theta2'])])
        normals.append([cos(A['Theta2']-pi/2.0),
                        sin(A['Theta2']-pi/2.0)])
    
    # Tooth Involute
    for i in range(3*N):
        r = (R['Bevel'] - R['Base'])*(i+1)/(3*N) + R['Base']
        u = sqrt(r*r/(R['Base']*R['Base'])-1)
        xp = R['Base']*(cos(u)+u*sin(u))
        yp = - R['Base']*(sin(u)-u*cos(u))
        points.append ([xp*cos(A['Theta2'])-yp*sin(A['Theta2']),
                        +xp*sin(A['Theta2'])+yp*cos(A['Theta2'])])
        normals.append([-sin(u),
                        -cos(u)])
        
    # Tooth Bevel
    auxth = -u 
    auxth = auxth + ThetaA3 + pi/2.0
    m     = tan(auxth)
    P0    = points[len(points)-1]
    rA    = TOOTHGEO['Bevel']/(1-cos(auxth-A['Theta4']))
    xc    = P0[0] - rA*cos(auxth)
    yc    = P0[1] - rA*sin(auxth)
    for i in range(N):
        th = (A['Theta4'] - auxth)*(i+1)/(N) + auxth              
        points.append ([xc + rA*cos(th),
                        yc +rA*sin(th)])
        normals.append([-cos(th),
                        -sin(th)])

    # Tooth Top
    P0    = points[len(points)-1]
    A['Theta4'] = atan (P0[1]/P0[0])
    Ra = sqrt(P0[0]*P0[0]+P0[1]*P0[1])
    for i in range(N):
        th = (-A['Theta4'])*(i+1)/(N) + A['Theta4']              
        points.append ([Ra*cos(th),
                        Ra*sin(th)])
        normals.append([-cos(th),
                        -sin(th)])

    # Mirrors this!
    N = len(points)
    for i in range(N-1):
        P = points[N-2-i]
        points.append([P[0],-P[1]])
        V = normals[N-2-i]
        normals.append([V[0],-V[1]])

    return points,normals

####################################################################
#CREATES THE BASE RACK PROFILE
####################################################################
def RackOutline():
    global TOOTHGEO

    ####################################################################
    #Basic Math computations: QUotes
    #
    X = {
        'Bottom'  :  - TOOTHGEO['Dedendum'] - TOOTHGEO['Fillet'],
        'Ded'     :  - TOOTHGEO['Dedendum'],
        'Bevel'   : TOOTHGEO['Addendum'] - TOOTHGEO['Bevel'],
        'Add'     : TOOTHGEO['Addendum']
    }

    ####################################################################
    #Basic Math computations: Angles
    #
    DiametralPitch = TOOTHGEO['TeethN']/(2*TOOTHGEO['PitchRadius'])
    ToothThickness = 1.5708/DiametralPitch
    CircularPitch  = pi / DiametralPitch

    Pa = TOOTHGEO['PressureAng']*pi/180.0
    
    yA1 = ToothThickness/2.0
    yA2 = (-X['Ded']+TOOTHGEO['Fillet']*sin(Pa))*tan(Pa)
    yA3 = TOOTHGEO['Fillet']*cos(Pa)

    A = {
        'y0' : CircularPitch/2.0,
        'y1' : yA1+yA2+yA3,
        'y2' : yA1+yA2,
        'y3' : yA1 -(X['Add']-TOOTHGEO['Bevel'])*tan(Pa),
        'y4' : yA1 -(X['Add']-TOOTHGEO['Bevel'])*tan(Pa)
                - cos(Pa)/(1-sin(Pa))*TOOTHGEO['Bevel']
    }

    ####################################################################
    # Profiling
    #
    N = TOOTHGEO['Resolution']
    points  = []
    normals = []   
    # Top half bottom of tooth
    for i in range(2*N):
        y = (A['y1'] - A['y0'])*i/(2*N-1) + A['y0']              
        points.append ([X['Bottom'],
                        y])
        normals.append([-1.0,
                        -0.0])
        
    # Bottom Fillet
    xc = X['Ded']
    yc = A['y1']
    Aw = pi/2.0 - Pa
    for i in range(N):
        th = (Aw)*(i+1)/(N) + pi
        points.append ([xc + TOOTHGEO['Fillet']*cos(th),
                        yc + TOOTHGEO['Fillet']*sin(th)])
        normals.append([cos(th),
                        sin(th)])

    # Straight part
    Xded = X['Ded'] - TOOTHGEO['Fillet']*sin(Pa)
    for i in range(4*N):
        x = (X['Bevel']-Xded)*(i+1)/(4*N) + Xded              
        points.append ([x,
                        yA1-tan(Pa)*x])
        normals.append([-sin(Pa),
                        -cos(Pa)])
    
    # Tooth Bevel
    rA    = TOOTHGEO['Bevel']/(1-sin(Pa))
    xc    =  X['Add'] - rA
    yc    =  A['y4']
    for i in range(N):
        th = (-pi/2.0+Pa)*(i+1)/(N) + pi/2.0-Pa
        points.append ([xc + rA*cos(th),
                        yc + rA*sin(th)])
        normals.append([-cos(th),
                        -sin(th)])

    # Tooth Top
    for i in range(N):
        y = -A['y4']*(i+1)/(N) + A['y4']
        points.append ([X['Add'],
                        y])
        normals.append([-1.0,
                        0.0])

    # Mirrors this!
    N = len(points)
    for i in range(N-1):
        P = points[N-2-i]
        points.append([P[0],-P[1]])
        V = normals[N-2-i]
        normals.append([V[0],-V[1]])

    return points,normals

####################################################################
#CREATES THE BASE CROWN INVOLUTE 
####################################################################
def CrownOutline():
    global TOOTHGEO

    ####################################################################
    #Basic Math computations: Radii
    #
    R = {
        'Bottom'  : TOOTHGEO['PitchRadius'] * cos(TOOTHGEO['PressureAng']*pi/180.0) ,
        'Base'    : TOOTHGEO['PitchRadius'] * cos(TOOTHGEO['PressureAng']*pi/180.0) + TOOTHGEO['Fillet'],
        'Ded'     : TOOTHGEO['PitchRadius'] + TOOTHGEO['Dedendum']
    }

    ####################################################################
    #Basic Math computations: Angles
    #
    DiametralPitch = TOOTHGEO['TeethN']/(2*TOOTHGEO['PitchRadius'])
    ToothThickness = 1.5708/DiametralPitch
    CircularPitch  = pi / DiametralPitch

    U1 = sqrt((1-cos(TOOTHGEO['PressureAng']*pi/180.0))/
                   cos(TOOTHGEO['PressureAng']*pi/180.0))
    U2 = sqrt(R['Ded']*R['Ded']/(R['Base']*R['Base'])-1)

    ThetaA1 = atan((sin(U1)-U1*cos(U1))/(cos(U1)+U1*sin(U1)))
    ThetaA2 = atan((sin(U2)-U2*cos(U2))/(cos(U2)+U2*sin(U2)))
    ThetaA3 = ThetaA1 + ToothThickness/(TOOTHGEO['PitchRadius']*2.0)
    
    A = {
        'Theta0' : CircularPitch/(TOOTHGEO['PitchRadius']*2.0),
        'Theta1' : (ThetaA3 + TOOTHGEO['Fillet']/R['Base']),
        'Theta2' : ThetaA3,
        'Theta3' : ThetaA3 - ThetaA2,
        'Theta4' : ThetaA3 - ThetaA2 - TOOTHGEO['Bevel']/R['Ded']
    }

    M = A['Theta0'] 
    A['Theta0'] = 0
    A['Theta1'] = A['Theta1']-M
    A['Theta2'] = A['Theta2']-M
    A['Theta3'] = A['Theta3']-M
    A['Theta4'] = A['Theta4']-M
    
    ####################################################################
    # Profiling
    #
    N = TOOTHGEO['Resolution']
    apoints  = []
    anormals = []   

    # Top half top of tooth
    for i in range(2*N):
        th = (A['Theta1'] - A['Theta0'])*i/(2*N-1) + A['Theta0']              
        apoints.append ([R['Bottom']*cos(th),
                        R['Bottom']*sin(th)])
        anormals.append([cos(th),
                        sin(th)])
        
    # Bottom Bevel
    xc = R['Base']*cos(A['Theta1'])
    yc = R['Base']*sin(A['Theta1'])
    Aw = pi/2.0 + A['Theta2'] - A['Theta1']
    for i in range(N):
        th = (Aw)*(i+1)/(N) + pi + A['Theta1']
        apoints.append ([xc + TOOTHGEO['Fillet']*cos(th),
                        yc + TOOTHGEO['Fillet']*sin(th)])
        anormals.append([-cos(th),
                        -sin(th)])

    # Tooth Involute
    for i in range(4*N):
        r = (R['Ded'] - R['Base'])*(i+1)/(4*N) + R['Base']
        u = sqrt(r*r/(R['Base']*R['Base'])-1)
        xp = R['Base']*(cos(u)+u*sin(u))
        yp = - R['Base']*(sin(u)-u*cos(u))
        apoints.append ([xp*cos(A['Theta2'])-yp*sin(A['Theta2']),
                        +xp*sin(A['Theta2'])+yp*cos(A['Theta2'])])
        anormals.append([sin(u),
                        cos(u)])
        
    # Tooth Bevel
    auxth = -u 
    auxth = auxth + ThetaA3 + pi/2.0
    m     = tan(auxth)
    P0    = apoints[len(apoints)-1]
    rA    = TOOTHGEO['Bevel']/(1-cos(auxth-A['Theta4']))
    xc    = P0[0] - rA*cos(auxth)
    yc    = P0[1] - rA*sin(auxth)
    for i in range(N):
        th = (A['Theta4'] - auxth)*(i+1)/(N) + auxth              
        apoints.append ([xc + rA*cos(th),
                        yc +rA*sin(th)])
        anormals.append([cos(th),
                        sin(th)])

    # Tooth Top
    P0    = apoints[len(apoints)-1]
    A['Theta4'] = atan (P0[1]/P0[0])
    Ra = sqrt(P0[0]*P0[0]+P0[1]*P0[1])
    for i in range(N):
        th = (-M - A['Theta4'])*(i+1)/(N) + A['Theta4']
        apoints.append ([Ra*cos(th),
                        Ra*sin(th)])
        anormals.append([cos(th),
                        sin(th)])
    points = []
    normals = []
    N = len(apoints)
    for i in range(N):
        points.append(apoints[N-1-i])
        normals.append(anormals[N-1-i])
        
    # Mirrors this!
    N = len(points)
    for i in range(N-1):
        P = points[N-2-i]
        points.append([P[0],-P[1]])
        V = normals[N-2-i]
        normals.append([V[0],-V[1]])

    return points,normals



####################################################################
#CREATES THE BASE PROFILE
####################################################################
def TheTooth(Mesh,Rack,Crown):
    global TOOTHGEO

    if (Rack==0 and Crown==0):
      (Vert,Norm) = ToothOutline()
    else:
        if (Rack==1):
            (Vert,Norm) = RackOutline()
        else:
            (Vert,Norm) = CrownOutline()
        

    b     = TOOTHGEO['Bevel']
    Thick = TOOTHGEO['Thickness']/2.0
    Psi   = TOOTHGEO['HelicalAng']*pi/180.0
    
    ####################################################################
    #First Vertices
    if (Rack==0):
        for i in range(TOOTHGEO['Resolution']+1):
            chi = (i/(1.0*TOOTHGEO['Resolution']))*pi/2.0
            z = Thick-b*(1-cos(chi))
            sq = z*tan(Psi);
            Phi = sq/TOOTHGEO['PitchRadius']

            for j in range(len(Vert)):
                p = Vert[j]
                m = Norm[j]

                x = p[0]+b*(1-sin(chi))*m[0]
                y = p[1]+b*(1-sin(chi))*m[1]
                Mesh.verts.append(
                    NMesh.Vert(x*cos(Phi)+y*sin(Phi),
                               -x*sin(Phi)+y*cos(Phi),
                               z)
                    )

        for i in range(TOOTHGEO['LongRes']):
            z = Thick - b - (TOOTHGEO['Thickness']-2.0*b)*(i+1)/TOOTHGEO['LongRes'];
            sq = z*tan(Psi);
            Phi = sq/TOOTHGEO['PitchRadius']

            for j in range(len(Vert)):
                p = Vert[j]

                x = p[0]
                y = p[1]
            
                Mesh.verts.append(
                    NMesh.Vert(x*cos(Phi)+y*sin(Phi),
                               -x*sin(Phi)+y*cos(Phi),
                               z)
                    )
        

        for i in range(TOOTHGEO['Resolution']):
            chi = (1.0-(i+1)/(1.0*TOOTHGEO['Resolution']))*pi/2.0
            z = -Thick+b*(1-cos(chi))
            sq = z*tan(Psi);
            Phi = sq/TOOTHGEO['PitchRadius']

            for j in range(len(Vert)):
                p = Vert[j]
                m = Norm[j]
                
                x = p[0]+b*(1-sin(chi))*m[0]
                y = p[1]+b*(1-sin(chi))*m[1]
                Mesh.verts.append(
                    NMesh.Vert(x*cos(Phi)+y*sin(Phi),
                               -x*sin(Phi)+y*cos(Phi),
                               z)
                    )
    else:
        for i in range(TOOTHGEO['Resolution']+1):
            chi = (i/(1.0*TOOTHGEO['Resolution']))*pi/2.0
            z = Thick-b*(1-cos(chi))
            sq = z*tan(Psi);

            for j in range(len(Vert)):
                p = Vert[j]
                m = Norm[j]

                x = p[0]+b*(1-sin(chi))*m[0]
                y = p[1]+b*(1-sin(chi))*m[1]
                Mesh.verts.append(
                    NMesh.Vert(x,
                               y - sq,
                               z)
                    )

        for i in range(TOOTHGEO['LongRes']):
            z = Thick - b - (TOOTHGEO['Thickness']-2.0*b)*(i+1)/TOOTHGEO['LongRes'];
            sq = z*tan(Psi);
            
            for j in range(len(Vert)):
                p = Vert[j]

                x = p[0]
                y = p[1]
            
                Mesh.verts.append(
                    NMesh.Vert(x,
                               y - sq,
                               z)
                    )
        

        for i in range(TOOTHGEO['Resolution']):
            chi = (1.0-(i+1)/(1.0*TOOTHGEO['Resolution']))*pi/2.0
            z = -Thick+b*(1-cos(chi))
            sq = z*tan(Psi);

            for j in range(len(Vert)):
                p = Vert[j]
                m = Norm[j]
                
                x = p[0]+b*(1-sin(chi))*m[0]
                y = p[1]+b*(1-sin(chi))*m[1]
                Mesh.verts.append(
                    NMesh.Vert(x,
                               y - sq,
                               z)
                    )
        
    ####################################################################
    #Then Faces
    NV = len(Vert)
    NL  = 2*TOOTHGEO['Resolution']+TOOTHGEO['LongRes']
    FVC  = len(Mesh.verts)
    
    for i in range(NL):
        for j in range(NV-1):
            nf = NMesh.Face()
	    nf.v.append(Mesh.verts[i*(NV)+j])
	    nf.v.append(Mesh.verts[i*(NV)+j+1])
	    nf.v.append(Mesh.verts[(i+1)*(NV)+j+1])
	    nf.v.append(Mesh.verts[(i+1)*(NV)+j])
	    Mesh.faces.append(nf)

    ####################################################################
    #Add Width
    #
    # TOP
    if (Rack==0):
        p0  = Mesh.verts[0]
        p1  = Mesh.verts[NV-1]
        th0 = atan(p0[1]/p0[0]);
        th1 = atan(p1[1]/p1[0]);
        R   = sqrt(p0[0]*p0[0]+p0[1]*p0[1])
        N   = 2*TOOTHGEO['Resolution']
        Wid = TOOTHGEO['Width']
        if (Crown==1):
            Wid = - Wid

        for i in range(N):
            th = (th1-th0)*i/(N-1)+th0
            Mesh.verts.append(
                NMesh.Vert((R-Wid)*cos(th),
                           (R-Wid)*sin(th),
                           TOOTHGEO['Thickness']/2.0)
                )
        Mesh.verts.append(
            NMesh.Vert(R*cos((th1+th0)/2.0),
                       R*sin((th1+th0)/2.0),
                       TOOTHGEO['Thickness']/2.0)
            )
    else:
        p0  = Mesh.verts[0]
        p1  = Mesh.verts[NV-1]
        y0  = p0[1]
        y1  = p1[1]
        x0  = p0[0]
        N   = 2*TOOTHGEO['Resolution']
        print "WARNING: Extrude Dup Offset = ",y1-y0
        Wid = TOOTHGEO['Width']
        for i in range(N):
            y = (y1-y0)*i/(N-1)+y0
            Mesh.verts.append(
                NMesh.Vert((x0-Wid),
                           y,
                           TOOTHGEO['Thickness']/2.0)
                )
        Mesh.verts.append(
            NMesh.Vert(x0,
                       (y1+y0)/2.0,
                       TOOTHGEO['Thickness']/2.0)
            )
                 
    for i in range(N-1):
        nf = NMesh.Face()
        nf.v.append(Mesh.verts[i])
	nf.v.append(Mesh.verts[i+1])
	nf.v.append(Mesh.verts[FVC])
	Mesh.faces.append(nf)

    for i in range(N/2-1):
        nf = NMesh.Face()
        nf.v.append(Mesh.verts[i+N-1])
	nf.v.append(Mesh.verts[i+N])
	nf.v.append(Mesh.verts[FVC+i+1])
	nf.v.append(Mesh.verts[FVC+i])
	Mesh.faces.append(nf)

    nf = NMesh.Face()
    nf.v.append(Mesh.verts[FVC+N/2-1])
    nf.v.append(Mesh.verts[FVC+N])
    nf.v.append(Mesh.verts[N+N/2-1])
    nf.v.append(Mesh.verts[N+N/2-2])
    Mesh.faces.append(nf)
       
    nf = NMesh.Face()
    nf.v.append(Mesh.verts[FVC+N/2-1])
    nf.v.append(Mesh.verts[FVC+N])
    nf.v.append(Mesh.verts[FVC+N/2])
    Mesh.faces.append(nf)

    for i in range(6*N):
        nf = NMesh.Face()
        nf.v.append(Mesh.verts[N+N/2+i-1])
        nf.v.append(Mesh.verts[N+N/2+i])
        nf.v.append(Mesh.verts[FVC+N])
        Mesh.faces.append(nf)

    nf = NMesh.Face()
    nf.v.append(Mesh.verts[FVC+N/2])
    nf.v.append(Mesh.verts[FVC+N])
    nf.v.append(Mesh.verts[NV-N-N/2])
    nf.v.append(Mesh.verts[NV-N-N/2+1])
    Mesh.faces.append(nf)

    for i in range(N/2-1):
        nf = NMesh.Face()
        nf.v.append(Mesh.verts[NV-N-N/2+i+1])
        nf.v.append(Mesh.verts[NV-N-N/2+i+2])
        nf.v.append(Mesh.verts[FVC+N/2+i+1])
        nf.v.append(Mesh.verts[FVC+N/2+i])
        Mesh.faces.append(nf)

    for i in range(N-1):
        nf = NMesh.Face()
        nf.v.append(Mesh.verts[NV-i-2])
        nf.v.append(Mesh.verts[NV-i-1])
        nf.v.append(Mesh.verts[FVC+N-1])
        Mesh.faces.append(nf)

    #
    # BOTTOM
    F1  = NL*NV
    FVC = len(Mesh.verts)
    if(Rack==0):
        tha = th1
        th1 = -th0
        th0 = -tha
        Wid = TOOTHGEO['Width']
        if (Crown==1):
            Wid = - Wid
        for i in range(N):
            th = ((th1-th0)*i/(N-1)+th0)
            Mesh.verts.append(
                NMesh.Vert((R-Wid)*cos(th),
                           (R-Wid)*sin(th),
                           -TOOTHGEO['Thickness']/2.0)
                )
        Mesh.verts.append(
            NMesh.Vert(R*cos((th1+th0)/2.0),
                       R*sin((th1+th0)/2.0),
                       -TOOTHGEO['Thickness']/2.0)
            )
    else:
        ya = y1
        y1 = - y0
        y0 = -ya
        Wid = TOOTHGEO['Width']
        for i in range(N):
            y = (y1-y0)*i/(N-1)+y0
            Mesh.verts.append(
                NMesh.Vert((x0-Wid),
                           y,
                           -TOOTHGEO['Thickness']/2.0)
                )
        Mesh.verts.append(
            NMesh.Vert(x0,
                       (y1+y0)/2.0,
                       -TOOTHGEO['Thickness']/2.0)
            )
        
    for i in range(N-1):
        nf = NMesh.Face()
        nf.v.append(Mesh.verts[F1+i])
	nf.v.append(Mesh.verts[F1+i+1])
	nf.v.append(Mesh.verts[FVC])
	Mesh.faces.append(nf)

    for i in range(N/2-1):
        nf = NMesh.Face()
        nf.v.append(Mesh.verts[F1+i+N-1])
	nf.v.append(Mesh.verts[F1+i+N])
	nf.v.append(Mesh.verts[FVC+i+1])
	nf.v.append(Mesh.verts[FVC+i])
	Mesh.faces.append(nf)

    nf = NMesh.Face()
    nf.v.append(Mesh.verts[FVC+N/2-1])
    nf.v.append(Mesh.verts[FVC+N])
    nf.v.append(Mesh.verts[F1+N+N/2-1])
    nf.v.append(Mesh.verts[F1+N+N/2-2])
    Mesh.faces.append(nf)
       
    nf = NMesh.Face()
    nf.v.append(Mesh.verts[FVC+N/2-1])
    nf.v.append(Mesh.verts[FVC+N])
    nf.v.append(Mesh.verts[FVC+N/2])
    Mesh.faces.append(nf)

    for i in range(6*N):
        nf = NMesh.Face()
        nf.v.append(Mesh.verts[F1+N+N/2+i-1])
        nf.v.append(Mesh.verts[F1+N+N/2+i])
        nf.v.append(Mesh.verts[FVC+N])
        Mesh.faces.append(nf)

    nf = NMesh.Face()
    nf.v.append(Mesh.verts[FVC+N/2])
    nf.v.append(Mesh.verts[FVC+N])
    nf.v.append(Mesh.verts[F1+NV-N-N/2])
    nf.v.append(Mesh.verts[F1+NV-N-N/2+1])
    Mesh.faces.append(nf)

    for i in range(N/2-1):
        nf = NMesh.Face()
        nf.v.append(Mesh.verts[F1+NV-N-N/2+i+1])
        nf.v.append(Mesh.verts[F1+NV-N-N/2+i+2])
        nf.v.append(Mesh.verts[FVC+N/2+i+1])
        nf.v.append(Mesh.verts[FVC+N/2+i])
        Mesh.faces.append(nf)

    for i in range(N-1):
        nf = NMesh.Face()
        nf.v.append(Mesh.verts[F1+NV-i-2])
        nf.v.append(Mesh.verts[F1+NV-i-1])
        nf.v.append(Mesh.verts[FVC+N-1])
        Mesh.faces.append(nf)

####################################################################
# Deform base profile to cone
####################################################################
def ConifyTooth(Mesh,Alpha):
    global TOOTHGEO

    R  = TOOTHGEO['PitchRadius']
    Zo = TOOTHGEO['Thickness']/2.0
    h  = R/tan(Alpha)
    print R,h,Alpha,Alpha*180/pi
    for v in Mesh.verts:
        x = v.co[0]
        y = v.co[1]
        z = v.co[2]+Zo

        r   = sqrt(x*x+y*y)
        phi = atan(y/x)

        Rr = R + (r-R)*cos(Alpha)
        Rz = (r-R)*sin(Alpha)
        
        Mod = sqrt(Rr*Rr+(Rz-h)*(Rz-h))

        rc = Rr - z * Rr/Mod
        zc = Rz + z * (h-Rz)/Mod

        v.co[0] = rc*cos(phi)
        v.co[1] = rc*sin(phi)
        v.co[2] = zc
        
####################################################################
#Do The TOOTH
####################################################################
def DoTheTooth():
    global ErrorMessage
    global TOOTHGEO, TOOTHHASH, PINIONHASH

    TOOTHGEO = {
            'PitchRadius' : TOOTHHASH['PitchRadius'].val,
            'TeethN'      : TOOTHHASH['TeethN'].val,
            'PressureAng' : TOOTHHASH['PressureAng'].val,
            'Addendum'    : TOOTHHASH['Addendum'].val,
            'Dedendum'    : TOOTHHASH['Dedendum'].val,
            'Fillet'      : TOOTHHASH['Fillet'].val,
            'Bevel'       : TOOTHHASH['Bevel'].val,
            'Resolution'  : TOOTHHASH['Resolution'].val,
            'Thickness'   : TOOTHHASH['Thickness'].val,
            'LongRes'     : TOOTHHASH['LongRes'].val,
            'HelicalAng'  : TOOTHHASH['HelicalAng'].val,
            'Width'       : TOOTHHASH['Width'].val
    }

    ####################################################################
    #Main Gear
    #
    scene = Scene.getCurrent()
    MeshG = NMesh.GetRaw()
    MeshG.name = 'Gear'
    TheTooth(MeshG,0,0)

    
    if ( STATEHASH['CON'].val==1 ):
        if (STATEHASH['PIN'].val==0):
            AlphaG = TOOTHHASH['Alpha'].val*pi/360.0
        else:
            Alpha = TOOTHHASH['Alpha'].val*pi/180.0
            Rg = TOOTHGEO['PitchRadius']
            Rp = TOOTHGEO['PitchRadius']*PINIONHASH['TeethN'].val/TOOTHHASH['TeethN'].val
            Psi = sqrt(Rg*Rg+Rp*Rp+2*Rg*Rp*cos(Alpha))
            AlphaP = atan(Rp*sin(Alpha)/(Rg+Rp*cos(Alpha)))
            AlphaG = Alpha-AlphaP

        ConifyTooth(MeshG,AlphaG)

    ObjectG = Object.New('Mesh')
    ObjectG.link(MeshG)
    scene.link(ObjectG)
    MeshG.update()

    ####################################################################
    #Pinion
    #
    if ( STATEHASH['NOP'].val==0 ):
        GearPitch = TOOTHGEO['PitchRadius']
        GearN = TOOTHGEO['TeethN']
        GearPsi = TOOTHGEO['HelicalAng']
        TOOTHGEO['PitchRadius'] = GearPitch * PINIONHASH['TeethN'].val/GearN
        TOOTHGEO['HelicalAng'] = - GearPsi 
        TOOTHGEO['TeethN'] = PINIONHASH['TeethN'].val

        if (STATEHASH['CRO'].val==1 and TOOTHGEO['TeethN'] < GearN):
            ErrorMessage = 'A Crown should have MORE theeth than its Gear'
            
        MeshP = NMesh.GetRaw()
        MeshP.name = 'Pinion'
        TheTooth(MeshP,STATEHASH['RAC'].val,STATEHASH['CRO'].val)
                 
        if ( STATEHASH['CON'].val==1 ):
            ConifyTooth(MeshP,AlphaP)

        ObjectP = Object.New('Mesh')
        scene.link(ObjectP)
        ObjectP.link(MeshP)
        MeshP.update()

        if (STATEHASH['PIN'].val==1):
            ObjectP.setLocation(TOOTHHASH['PitchRadius'].val+TOOTHGEO['PitchRadius'],0.0,0.0)
            ObjectP.setEuler(0.0,0.0,pi-pi/(PINIONHASH['TeethN'].val))
        elif (STATEHASH['RAC'].val==1):
            ObjectP.setLocation(TOOTHHASH['PitchRadius'].val,0.0,0.0)
            ObjectP.setEuler(0.0,0.0,pi)
        elif (STATEHASH['CRO'].val==1):
            ObjectP.setLocation(TOOTHHASH['PitchRadius'].val-TOOTHGEO['PitchRadius'],0.0,0.0)
            ObjectP.setEuler(0.0,0.0,pi/(PINIONHASH['TeethN'].val))

    
#############################################################
# MAIN WINDOW                                               #
#############################################################
def MainWindow():        
    global EVENTHASH,STATEHASH
    global TOOTHHASH
    
    #############################################################
    # Backgrounds                                               #
    #############################################################

    BGL.glClearColor(0.5, 0.5, 0.5, 0.0)
    BGL.glClear(BGL.GL_COLOR_BUFFER_BIT)
    BGL.glColor3f(0, 0, 0) 			# Black
    BGL.glRectf(2, 2, 482, 520)
    BGL.glColor3f(0.48, 0.4, 0.57) 		# Light Purple
    BGL.glRectf(4, 479, 480, 510)
    BGL.glRectf(4, 34, 480, 450)
    BGL.glColor3f(0.3, 0.27, 0.35) 		# Dark purple
    BGL.glRectf(4, 451,480, 478)
    BGL.glRectf(4, 4, 480, 33)

    #############################################################
    # Common Header                                             #
    #############################################################

    BGL.glColor3f(0.9, 0.8, 1)
    BGL.glRasterPos2d(10, 500)
    Draw.Text("Blender Mechanical Gears v. "+VERSION)
    BGL.glRasterPos2d(10, 484)
    Draw.Text("(C) Nov 2004 Stefano Selleri <a.k.a. S68>")
#    Draw.Button("Save", EVENTHASH['SAVE'], 267, 482, 70, 24,
#        	"Save currents settings to a file")
#    Draw.Button("Load", EVENTHASH['LOAD'], 337, 482, 70, 24,
#                "Loads Previously saved Settings form a file")
    Draw.Button("Exit", EVENTHASH['EXIT'], 407, 482, 70, 24)
 
    STATEHASH['CYL'] = Draw.Toggle(
        "Cylindrical",STATEHASH['CYL_EV'],10,454,100,20,STATEHASH['CYL'].val,
        "Cylindrical (Spur or Helical) Gear")
    STATEHASH['CON'] = Draw.Toggle(
        "Conical",STATEHASH['CON_EV'],110,454,100,20,STATEHASH['CON'].val,
        "Conical (Straight or Spiral) Gear")
    STATEHASH['WOR'] = Draw.Toggle(
        "Worm",STATEHASH['WOR_EV'],210,454,100,20,STATEHASH['WOR'].val,
        "Worm (screw) Gear")

        
    Draw.Button("GENERATE", EVENTHASH['DO'], 7, 7, 470, 24)
    BGL.glColor3f(0.9, 0.9, 0.9)

    #############################################################
    # Screen                                                    #
    #############################################################
    BGL.glRasterPos2d(10, 425)
    Draw.Text("Main Gear Parameters:")
    TOOTHHASH['PitchRadius'] = Draw.Slider(
            "Pitch Rad.: ", EVENTHASH['NOEVENT'], 20, 400, 210, 18,
            TOOTHHASH['PitchRadius'].val, 0.5, 20.0 , 0,
            "Pitch Radius")
    TOOTHHASH['TeethN'] = Draw.Slider(
            "Teeth No.: ", EVENTHASH['NOEVENT'], 240, 400, 210, 18,
            TOOTHHASH['TeethN'].val, 8, 100 , 0,
            "Number of teeth")
    TOOTHHASH['PressureAng'] = Draw.Slider(
            "Press. Ang.: ", EVENTHASH['NOEVENT'], 20, 380, 210, 18,
            TOOTHHASH['PressureAng'].val, 1.0, 45.0 , 0,
            "Pressure Angle")
    TOOTHHASH['HelicalAng'] = Draw.Slider(
            "Heli. Ang.: ", EVENTHASH['NOEVENT'], 240, 380, 210, 18,
            TOOTHHASH['HelicalAng'].val, -45.0, 45.0, 0,
            "Angle of the tooth in an Helical (Spiral) gear tooth") 
    TOOTHHASH['Addendum'] = Draw.Slider(
            "Addendum: ", EVENTHASH['NOEVENT'], 20, 360, 210, 18,
            TOOTHHASH['Addendum'].val, 0.01, 5.0 , 0,
            "Addendum")
    TOOTHHASH['Dedendum'] = Draw.Slider(
            "Dedendum: ", EVENTHASH['NOEVENT'], 240, 360, 210, 18,
            TOOTHHASH['Dedendum'].val, 0.01, 5.0 , 0,
            "Dedendum")

    BGL.glRasterPos2d(10, 345)
    Draw.Text("Bevelling:")    
    TOOTHHASH['Fillet'] = Draw.Slider(
            "Fillet: ", EVENTHASH['NOEVENT'], 20, 320, 210, 18,
            TOOTHHASH['Fillet'].val, 0.01, 1.0 , 0,
            "Addendum")
    TOOTHHASH['Bevel'] = Draw.Slider(
            "Bevel: ", EVENTHASH['NOEVENT'], 240, 320, 210, 18,
            TOOTHHASH['Bevel'].val, 0.01, 1.0 , 0,
            "Addendum")    

    BGL.glRasterPos2d(10, 305)
    Draw.Text("Mesh parameters:")    
    TOOTHHASH['Resolution'] = Draw.Slider(
            "Resolution: ", EVENTHASH['NOEVENT'], 20, 280, 210, 18,
            TOOTHHASH['Resolution'].val, 1, 5, 0,
            "Resolution of the tooth profile")
    TOOTHHASH['LongRes'] = Draw.Slider(
            "Long. Res.: ", EVENTHASH['NOEVENT'], 240, 280, 210, 18,
            TOOTHHASH['LongRes'].val, 1, 25, 0,
            "Resolution along the tooth extrusion")
    TOOTHHASH['Thickness'] = Draw.Slider(
            "Thickness: ", EVENTHASH['NOEVENT'], 20, 260, 210, 18,
            TOOTHHASH['Thickness'].val, 1, 5, 0,
            "Thickness of the tooth extrusion")
    TOOTHHASH['Width'] = Draw.Slider(
            "Width: ", EVENTHASH['NOEVENT'], 240, 260, 210, 18,
            TOOTHHASH['Width'].val, 0.01, 25.0, 0,
            "Concentrical inner extrusion from Inner tooth")

        
    #############################################################
    # STAUS-Dependent items                                     #
    #############################################################
    if (STATEHASH['CON'].val==1):
        BGL.glRasterPos2d(10, 245)
        Draw.Text("Conical Gear Characteristic Parameters:")
        if (STATEHASH['PIN'].val==1):
            TOOTHHASH['Alpha'] = Draw.Slider(
                    "Axis Ang.: ", EVENTHASH['NOEVENT'], 20, 220, 210, 18,
                    TOOTHHASH['Alpha'].val, 10.0, 170.0, 0,
                    "Angle Between Gear and Pinion axes")
        else:
            TOOTHHASH['Alpha'] = Draw.Slider(
                    "Cone Ang.: ", EVENTHASH['NOEVENT'], 20, 220, 210, 18,
                    TOOTHHASH['Alpha'].val, 10.0, 170.0, 0,
                    "Full Angle at vertex cone")

            
    #############################################################
    # PINION                                                    #
    #############################################################
    BGL.glRasterPos2d(10, 205)
    Draw.Text("Pinion:")

    if (STATEHASH['CYL'].val==1):
        STATEHASH['RAC'] = Draw.Toggle(
            "Rack",STATEHASH['RAC_EV'],210,180,100,20,STATEHASH['RAC'].val,
            "Make a Rack meshing this gear")
        STATEHASH['CRO'] = Draw.Toggle(
            "Crown",STATEHASH['CRO_EV'],310,180,100,20,STATEHASH['CRO'].val,
            "Cylindrical (Spur or Helical) Gear")
    else:
        if (STATEHASH['NOP']==0):
            STATEHASH['CYL'].val=1
            STATEHASH['CRO'].val=1
            STATEHASH['PIN'].val=1
        
    STATEHASH['NOP'] = Draw.Toggle(
        "No Pinion",STATEHASH['NOP_EV'],10,180,100,20,STATEHASH['NOP'].val,
        "Make a single gear")
    STATEHASH['PIN'] = Draw.Toggle(
        "Pinion",STATEHASH['PIN_EV'],110,180,100,20,STATEHASH['PIN'].val,
        "Make also a pinion meshing this Gear")

    if (STATEHASH['PIN'].val==1 or STATEHASH['CRO'].val==1):
        PINIONHASH['TeethN'] = Draw.Slider(
                    "Teeth No.: ", EVENTHASH['NOEVENT'], 20, 160, 210, 18,
                    PINIONHASH['TeethN'].val, 8, 100, 0,
                    "Teeths in the pinion")
                        
    else:
        if (STATEHASH['CON'].val==1):
            BGL.glRasterPos2d(10, 110)
            Draw.Text("WARNING: The math to compute two matching conical")
            BGL.glRasterPos2d(10, 90)
            Draw.Text("         gears is quite complex, you are strongly")
            BGL.glRasterPos2d(10, 70)
            Draw.Text("         advised to use the 'PINION' option.")
                

#############################################################
# Graphics                                                  #
#############################################################
def draw():
    global ErrorMessage
    if (ErrorMessage==''):
        MainWindow()
    else:
        ErrorDialog()

#############################################################
# Event Handler                                             #
#############################################################
def event(evt, val): 
	if (evt== Draw.QKEY and not val):
		Draw.Exit()

def bevent(evt):
    global ErrorMessage, DLG_OK
    global TOOTHHASH, TOOTHGEO
    global EVENTHASH, STATEHASH
    
    if   (evt == EVENTHASH['EXIT']):
        # EXIT
        Draw.Exit()
        # 2 = NOOP
    elif (evt == EVENTHASH['DO']):
        DoTheTooth()
	Draw.Redraw()
	
    elif (evt == EVENTHASH['SAVE']):
	Window.FileSelector (BAGSave, 'SAVE FILE:')        
    elif (evt == EVENTHASH['LOAD']):
	Window.FileSelector (BAGLoad, 'LOAD FILE:')        
        
    elif (evt == STATEHASH['CYL_EV']):
	STATEHASH['CYL'].val     = 1
	STATEHASH['CON'].val     = 0
	STATEHASH['WOR'].val     = 0
	Draw.Redraw()
    elif (evt == STATEHASH['CON_EV']):
	STATEHASH['CYL'].val     = 0
	STATEHASH['CON'].val     = 1
	STATEHASH['WOR'].val     = 0
	Draw.Redraw()
    elif (evt == STATEHASH['WOR_EV']):
	STATEHASH['CYL'].val     = 0
	STATEHASH['CON'].val     = 0
	STATEHASH['WOR'].val     = 1
	Draw.Redraw()
	
    elif (evt == STATEHASH['NOP_EV']):
	STATEHASH['NOP'].val     = 1
	STATEHASH['PIN'].val     = 0
	STATEHASH['RAC'].val     = 0
	STATEHASH['CRO'].val     = 0
	Draw.Redraw()
    elif (evt == STATEHASH['PIN_EV']):
	STATEHASH['NOP'].val     = 0
	STATEHASH['PIN'].val     = 1
	STATEHASH['RAC'].val     = 0
	STATEHASH['CRO'].val     = 0
	Draw.Redraw()
    elif (evt == STATEHASH['RAC_EV']):
	STATEHASH['NOP'].val     = 0
	STATEHASH['PIN'].val     = 0
	STATEHASH['RAC'].val     = 1
	STATEHASH['CRO'].val     = 0
	Draw.Redraw()
    elif (evt == STATEHASH['CRO_EV']):
	STATEHASH['NOP'].val     = 0
	STATEHASH['PIN'].val     = 0
	STATEHASH['RAC'].val     = 0
	STATEHASH['CRO'].val     = 1
	Draw.Redraw()
        
    elif (evt == DLG_OK):
        print '-'+ErrorMessage+'-'
        ErrorMessage=''
        print '-'+ErrorMessage+'-'
        Draw.Redraw()
        
#############################################################
# Registering all functions                                 #
#############################################################

Draw.Register(draw, event, bevent)
