#!BPY

""" Registration info for Blender menus: <- these words are ignored
Name: '_Knot_248'
Blender: 248
Group: 'Misc'
Tip: 'Select a curve object run to make pattern, edit varables in Text Editor'
"""

__author__ = "Public Domain)"
__url__ = ("")
__version__ = "1.0"
__bpydoc__ = """\
Knot.py. 

Select a curve object run to make pattern, edit varables in Text Editor.

"""

# -------------------------------------------------------------------------- 
# Knot v0.1
# Public Domain
# -------------------------------------------------------------------------- 
# ***** BEGIN GPL LICENSE BLOCK ***** 
# 
# This program is free software; you can redistribute it and/or 
# modify it under the terms of the GNU General Public License 
# as published by the Free Software Foundation; either version 2 
# of the License, or (at your option) any later version. 
# 
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
# GNU General Public License for more details. 
# 
# You should have received a copy of the GNU General Public License 
# along with this program; if not, write to the Free Software Foundation, 
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. 
# 
# ***** END GPL LICENCE BLOCK ***** 
# -------------------------------------------------------------------------- 
import Blender 
from Blender import Object 
from math import pi 
scene=Blender.Scene.getCurrent() 
OBJ=Blender.Object.GetSelected()[0].name 
division=8 
for n in range(1,division): 
 Op=Blender.Object.New('Curve') 
 Op.shareFrom(Object.Get(OBJ)) 
 Op.RotZ=n*pi/(division/2) 
 scene.link(Op) 
Blender.Window.RedrawAll()
 
