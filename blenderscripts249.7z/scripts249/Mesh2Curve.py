#!BPY

""" Registration info for Blender menus: <- these words are ignored
Name: 'Mesh2Curve'
Blender: 240
Group: 'Mesh'
Tip: 'Transform mesh to curve'
"""

__author__ = '3R - R3gis'
__version__ = '1.4'
__url__ = ["Script's site , http://blenderfrance.free.fr/python/","Author's site , http://cybercreator.free.fr", "French Blender support forum, http://www.zoo-logique.org/3D.Blender/newsportal/thread.php?group=3D.Blender"]
__email__=["3R, r3gis@free.fr"]


__bpydoc__ = """\
This script transform a mesh in curve

Select yours meshs and launch the script.
The mesh must be a linear (no faces and a point linked to 1 or 2 points)

Script will create the same number of curves objects that you have independent lines in your(s) mesh(s)

Note :
Don't forget to make a Remove Double before launching the script if you are not sure of your mesh

"""


# $$
#
# --------------------------------------------------------------------------
# ***** BEGIN GPL LICENSE BLOCK *****
#
# Copyright (C) 2004-2005: Regis Montoya
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****
# --------------------------------------------------------------------------
#################################
#  Script pour convertir un 		#
#	    		 mesh en path				  #
#################################
# by 3R - 18/12/2005
# pour tout probleme :
#	r3gis@free.fr
#
#	ou sur le newsgroup:
# http://zoo-logique.org/3D.Blender/
#
#You can visit www.cybercreator.sup.fr
#####################################
#-------------Utilisation-----------#
#																		#
#Selectionner le mesh a transformer #
#Le mesh doit etre une ligne brisee	#
#Lancer avec Alt+P									#
#####################################



import Blender, math
from Blender import NMesh,Curve
print("-----BEGINNING of Mesh2Curve Script's processing-----")


version=Blender.Get('version')
editmode=Blender.Window.EditMode()

#Fonction dans le cas 2D pour trouver le Plan le Plus Probable de Projection
def PPPP(LV,ListeBout):
	global mesh
	if ListeBout==[]:
		bout2=[LV[0],LV[1]]
	else:
		bout2=[ListeBout[0],ListeBout[1]]
	
	#Initialisation
	debut=0
	fini=0
	ind=bout2[0]
	VecteurDePPP=[0,0,0]
	pts=[]
	pt0=mesh.verts[bout2[0]].co
	pts.append(pt0)
	while fini==0:
		try:
			u=LV.index(ind)
			if u%2==0:
				LV.pop(u)
				ind=LV.pop(u)
			else:
				LV.pop(u)
				ind=LV.pop(u-1)
			if debut==0:
				pt1=mesh.verts[ind].co
				pts.append(pt1)
			else:
				pt2=mesh.verts[ind].co
				pts.append(pt2)
				x=[pt0[0]-pt1[0],pt0[1]-pt1[1],pt0[2]-pt1[2]]
				y=[pt2[0]-pt1[0],pt2[1]-pt1[1],pt2[2]-pt1[2]]
				xvy=[x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0]]
				if ((VecteurDePPP[0]+xvy[0])**2+(VecteurDePPP[1]+xvy[1])**2+(VecteurDePPP[2]+xvy[2])**2) >= ((VecteurDePPP[0]-xvy[0])**2+(VecteurDePPP[1]-xvy[1])**2+(VecteurDePPP[2]-xvy[2])**2):
					VecteurDePPP=[VecteurDePPP[0]+xvy[0],VecteurDePPP[1]+xvy[1],VecteurDePPP[2]+xvy[2]]
				else:
					VecteurDePPP=[VecteurDePPP[0]-xvy[0],VecteurDePPP[1]-xvy[1],VecteurDePPP[2]-xvy[2]]
				pt0=pt1
				pt1=pt2
		except:
			fini=1
		debut=1
	Norme = math.sqrt((VecteurDePPP[0])**2+(VecteurDePPP[1])**2+(VecteurDePPP[2])**2)
	if Norme<>0:
		VecteurDePPP=[VecteurDePPP[0]/Norme,VecteurDePPP[1]/Norme,VecteurDePPP[2]/Norme]
	zmoy=0
	compteur=0
	for pt in pts:
		zmoy=zmoy+VecteurDePPP[0]*pt[0]+VecteurDePPP[1]*pt[1]+VecteurDePPP[2]*pt[2]
		compteur=compteur+1
	zmoy=zmoy/compteur
	return [VecteurDePPP,zmoy]


#Fonction pour trouver les bouts dans des chaines de vertexs
def TrouveBout(Vertexs):
	global mesh,obj
	bout=[]
	ok=1
	for i in range(len(mesh.verts)):
		if Vertexs.count(i)==1:
			bout.append(i)
		if Vertexs.count(i)>2:
			Blender.Draw.PupMenu(str(mesh.name)+" have a point used for more than 2 edges|%tCheck at the cursor position")
			ok=0
			Mat=obj.getMatrix()
			Vect=Blender.Mathutils.Vector([mesh.verts[i].co[0],mesh.verts[i].co[1],mesh.verts[i].co[2],1])
			Curs=Vect*Mat
			print Mat,Vect,Curs
			Blender.Window.SetCursorPos(Curs[0],Curs[1],Curs[2])
			print "Impossible : "+str(mesh.name)+" have a point used for more than 2 edges"
			break
		if Vertexs.count(i)==0 and courbe==0:
			Blender.Draw.PupMenu(str(mesh.name)+" have a point lost")
			print str(mesh.name)+" have a point lost"
			bout.append(i)
			bout.append(i)


	if len(bout)%2==1:
		ok=0
		#Cas ou il y a un nombre impair de bout... normalement impossible(ou sinon il y a eu une erreur)

	if ok<>0:
		return bout
	else: 
		return "PB"

#Creation d'une ligne de curve
def convert(Vertexs,ListeBout,courbe,Mode_3D,Mode_Type):
	global mesh,obj

	#Creation de l'objet
	path=Blender.Object.New('Curve',str(obj.name)+" curve "+str(courbe))
	curve=Blender.Curve.New(str(obj.name)+" "+str(courbe))
	path.link(curve)
	Blender.Scene.GetCurrent().link(path)
	#Cas 2D => rajustement a la localite


	if Mode_3D==0:
		CVertexs=[i for i in Vertexs]
		PPP=PPPP(CVertexs,ListeBout)
		zm=PPP[1]
		vn=PPP[0]
		#Matrice		
		Mat=obj.getMatrix()
		Mat.invert()
		v2=Blender.Mathutils.Vector([vn[0],vn[1],vn[2]])
		v1=Blender.Mathutils.Vector([0,0,1])
		v3=Blender.Mathutils.CrossVecs(v1,v2)
		try:
			ang=Blender.Mathutils.AngleBetweenVecs(v1,v2)
			RMat=Blender.Mathutils.RotationMatrix(ang,4,"r",v3)
		except:
			RMat=Blender.Mathutils.Matrix([1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1])

	else:
		zm=0
		vn=[0,0,0]
		RMat=Blender.Mathutils.Matrix([1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1])


	#Cas ou la liste de bout est vide ... Mais il y a des vertexs qui repondent au bon criteres (cf fct ci-dessus) => Cas cycle
	if ListeBout==[]:
		bout=[Vertexs[0],Vertexs[1]]
		cyclic=1
	#Cas ou la liste de bout contient des element ... au moins 2 cf ci-dessus... => cas lineaire
	else:
		bout=[ListeBout[0],ListeBout[1]]
		cyclic=0
	
	#Initialisation de la copie a proprement parler
	fini=0
	ind=bout[0]

	#Inutile si on endpoint:
	pt=mesh.verts[bout[0]].co
	#Terme correctif du au mode 2D
	ptSvn=pt[0]*vn[0]+pt[1]*vn[1]+pt[2]*vn[2]-zm
	V_pt=Blender.Mathutils.Vector([pt[0]-ptSvn*vn[0],pt[1]-ptSvn*vn[1],pt[2]-ptSvn*vn[2],0])
	if version>=238:
		V_pl=RMat*V_pt
	else:
		V_pl=Blender.Mathutils.MatMultVec(RMat,V_pt)
	curve.appendNurb([V_pl[0],V_pl[1],V_pl[2],100])
	#Definition des attribus de la curve
	if cyclic==1:
		curve[0].setFlagU(1)
	#curve[0].setType(Mode_Type)
	if Mode_3D==0:
		curve.setFlag(6)
	else:
		curve.setFlag(7)


	while fini==0:
		try:
			#on prend la premiere fois dans la liste ou apparait ind
			u=Vertexs.index(ind)
			
			#Cas 1 : ind etait le point v1
			if u%2==0:
				#on le point ind
				Vertexs.pop(u)
				#on prend le point qui lui etait lie et en meme temps on le vire aussi de la liste pour que le passage suivant ne le prenne pas en compte
				ind=Vertexs.pop(u)
			
			#Cas 2 : ind etait le point v2
			else:
				Vertexs.pop(u)
				ind=Vertexs.pop(u-1)
		#On rajoute a la courbe le pt ind
			pt=mesh.verts[ind].co
			if cyclic==0:
				ptSvn=pt[0]*vn[0]+pt[1]*vn[1]+pt[2]*vn[2]-zm
				V_pt=Blender.Mathutils.Vector([pt[0]-ptSvn*vn[0],pt[1]-ptSvn*vn[1],pt[2]-ptSvn*vn[2],0])
				if version>=238:
					V_pl=RMat*V_pt
				else:
					V_pl=Blender.Mathutils.MatMultVec(RMat,V_pt)
				curve[0].append([V_pl[0],V_pl[1],V_pl[2],100])
			if cyclic==1:
				try:
					u=Vertexs.index(ind)
					ptSvn=pt[0]*vn[0]+pt[1]*vn[1]+pt[2]*vn[2]-zm
					V_pt=Blender.Mathutils.Vector([pt[0]-ptSvn*vn[0],pt[1]-ptSvn*vn[1],pt[2]-ptSvn*vn[2],0])
					if version>=238:
						V_pl=RMat*V_pt
					else:
						V_pl=Blender.Mathutils.MatMultVec(RMat,V_pt)
					curve[0].append([V_pl[0],V_pl[1],V_pl[2],100])
				except:
					pass
		
		#Si cas 1 et cas 2 retourne une erreur c'est que Vertex n'a pas de point ind donc ya plus de boulot a faire
		except:
			fini=1
	if Mode_Type==0:
		curve[0].setType(Mode_Type)
	curve.update()
	#La on update la curve et on la met a sa place... la meme que le mesh
	OMat=obj.getMatrix()
	NMat=RMat*OMat
	path.setMatrix(NMat)
	path.layers=obj.layers
	

			
	return Vertexs

######################
#Fonction principale
ObjSel=Blender.Object.GetSelected()
aremesh=0



Mode_3D=abs(Blender.Draw.PupMenu("Conversion Mode%t|Mode 3D%x1|Mode 2D%x0"))
if Mode_3D==0:
	Mode_Type=Blender.Draw.PupMenu("Conversion Type%t|Nurb%x1|Poly%x0")
else:
	Mode_Type=4

#Boucle sur chaque objet
for obj in ObjSel:
	mesh=obj.getData()
	if type(mesh)==Blender.Types.NMeshType:
		#C'est bon : au moins un mesh selectionnee
		aremesh=1
		
		#Remplissage des points du mesh dans Vertex par couple de points liees par une face
		#Mfaces=mesh.faces
		Medges=mesh.edges
		#test d'erreur dans le cas ou il y aurai des faces (Version Blender>2.38)
		#if Mfaces<>[]:
		#	Blender.Draw.PupMenu(str(mesh.name)+" have a face : can\'t be converted ")
		#	continue		

		Vertexs=[]
		for edge in Medges:
			Vertexs.append(edge.v1.index)
			Vertexs.append(edge.v2.index)

		courbe=0
		while Vertexs<>[]:
			print "Conversion for : "+str(obj.name)+"/ line number : "+str(courbe+1)
			bout=TrouveBout(Vertexs)
			if bout<>"PB":
				Vertexs=convert(Vertexs,bout,courbe,Mode_3D,Mode_Type)
				print "Created curve object : "+str(obj.name)+" curve "+str(courbe)
				courbe=courbe+1
			elif bout=="PB":
				Vertexs=[]
	
if aremesh==0:
		Blender.Draw.PupMenu("Nothing done : No mesh selected")

Blender.Window.EditMode(editmode)
Blender.Redraw(-1)