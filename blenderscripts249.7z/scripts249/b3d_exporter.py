#!BPY
""" Registration info for Blender menus:
Name: 'Blitz3D (.b3d)...'
Blender: 243
Group: 'Export'
Tooltip: 'Export to Blitz3D (.b3d) file.'
"""

# b3d_export.py version 0.6
# Copyright (C) 2007  Bruce A Henderson
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# Known issues
#
# Textures appear mirrored (y) in MiniB3D
#
# Version History
#
# 0.6 :
#     Added suppor for multiple textures per mesh.
# 0.5 :
#     Fixed issue with some undefined variables
#

import Blender
from Blender import *
from Blender.Draw import *
from Blender.BGL import *
import string
from struct import *

version = "0.6"
ARGS = ""


# matrices for changing y to up and z to depth (Blender is opposite)
matrixBlender2B3d = Mathutils.Matrix([1,0,0,0], \
                               [0,0,1,0], \
                               [0,-1,0,0], \
                               [0,0,0,1])

matrixB3d2Blender = Mathutils.Matrix([1,0,0,0], \
                               [0,0,-1,0], \
                               [0,1,0,0], \
                               [0,0,0,1])


class B3DExporter:

	def __init__(self, filename):

		self.debugLevel = 2

		self.filename = filename
		self.vertDict = {}
		self.brushFacesDict = {}
		self.imageNameDict = {}
		self.imageIndexDict = {}
		

	def export(self):
	
		if self.debugLevel > 0:
			print "B3DExporter (v " + version + ")"
			print "Exporting " + self.filename


		b3dfile = self.makeFileChunk(Blender.Object.Get())
		
		file = open(self.filename, "wb")
		
		file.write(b3dfile)

		if self.debugLevel > 0:
			print "Done."


	def debugChunkStart(self, chunk):
	
		if self.debugLevel == 2:
			print " ++ Starting " + chunk + " chunk."

	def debugChunkEnd(self, chunk, size):
	
		if self.debugLevel == 2:
			print " ++ Finished " + chunk + ". Size = " + str(size)
	

	#
	# The main BB3D chunk
	#
	def makeFileChunk(self, objs):
	 	chunk = "BB3D"
	 	
	 	self.debugChunkStart(chunk)
	 		 	
	 	# version number
	 	contents = pack("i", 1)

		# any uv textures?
		if self.hasImages(objs):
			contents += self.makeTexsChunk(objs)
			contents += self.makeBrusChunk(objs)


		# do the mesh/node stuff
		contents += self.makeNodeChunk(objs, 1, None)
	 		
	 	
	 	
	 	self.debugChunkEnd(chunk, len(contents))
	 	
	 	# chunk + size + contents
	 	chunk += pack("i", len(contents)) + contents
	 	
	 	return chunk


	def hasImages(self, objs):

		for obj in objs:
			if obj.getType() != 'Mesh':
				continue

			mesh = Mesh.Get(obj.data.name)
			if mesh.faceUV:
				return 1

		return 0



	#
	# A TEXS chunk
	#
	def makeTexsChunk(self, objs):
		chunk = "TEXS"

	 	self.debugChunkStart(chunk)

		contents = ""

		imageCounter = 0

		# process every mesh, looking for images
		for obj in objs:

			if obj.getType() != 'Mesh':
				continue

			mesh = Mesh.Get(obj.data.name)

			for face in mesh.faces:

				image = face.image

				if image != None:

					if not self.imageNameDict.has_key(image.name):

						if self.debugLevel == 2:
							print "Image : '" + image.name + "'"

						# map the image name to our "index"
						self.imageNameDict[image.name] = imageCounter
						self.imageIndexDict[imageCounter] = image.name
						imageCounter += 1

						# node name, null terminated.
						contents += pack( str(len(image.filename) + 1) + "s", image.filename)
						
						# flags - default = 1
						contents += pack("i", 1)

						# blend - default = 2
						contents += pack("i", 2)

						# x, y - default = 0, 0
						contents += pack("2f", 0, 0)

						# xscale, yscale - default = 1, 1
						contents += pack("2f", 1, -1)

						# rotation - default = 0
						contents += pack("f", 0)



	 	self.debugChunkEnd(chunk, len(contents))

		
		# chunk + size + contents
		chunk += pack("i", len(contents)) + contents
		
		return chunk


	#
	# A BRUS chunk
	#
	def makeBrusChunk(self, objs):
		chunk = "BRUS"

	 	self.debugChunkStart(chunk)

		contents = ""
		
		# NOTE :
		# Not sure what to do in this section really...
		# the spec implies that you can have more than one texture per brush
		# but the first part indicates that there are n_texs brushes (or textures?)
		# Then the texture_id int array implies that there x number of textures there...
		# ho hum...  will seek explanation ;-)

		# for now, we'll keep things VERY simple

		# number of textures
		contents += pack("i", len(self.imageIndexDict))

		for n in range(0, len(self.imageIndexDict)):

			name = self.imageIndexDict[n]
			image = Blender.Image.Get(name)

			# brush name
			contents += pack( str(len(name) + 1) + "s", name)

			# r, g, b, a - default = 1, 1, 1, 1
			contents += pack("4f", 1, 1, 1, 1)

			# shininess - default = 0
			contents += pack("f", 0)

			# blend, fx - default = 1, 0
			contents += pack("2i", 1, 0)

			# textures use in brush
			# list of ints up to total n_tex
			# -1 for those not used in this brush
			
			# hacky.. for now we just set it to the current index.
			# will need to change this for multi-texture brushes...

			for i in range(0, len(self.imageIndexDict)):

				if i == 0:
					contents += pack("i", self.imageNameDict[name])
				else:
					contents += pack("i", -1)
		


	 	self.debugChunkEnd(chunk, len(contents))

		
		# chunk + size + contents
		chunk += pack("i", len(contents)) + contents
		
		return chunk


	#
	# A NODE chunk
	#
	def makeNodeChunk(self, node, isRoot, object):
		chunk = "NODE"

		self.vertDict = {}
		self.brushFacesDict = {}

	 	self.debugChunkStart(chunk)
		
	
		if isRoot:

			# node name, null terminated.
			contents = pack("11s", "ROOT_BLEND")
		
			# no pos, scale, rotation...
			contents += pack("10f", 0, 0, 0, 1, 1, 1, 1, 0, 0, 0)

			for obj in node:
				
				# NOTE: we are only currently handling meshes...
				# Is there b3d support for anything else ???
		 		
		 		if obj.getType() != 'Mesh':
					continue
	 		
				contents += self.makeNodeChunk(Mesh.Get(obj.data.name), 0, obj)

		else:

			if self.debugLevel == 2:
				print "Mesh %s : verts = %d" % (node.name, len(node.verts))

			# an empty mesh ? (ie. one with no faces)			
			if len(node.faces) == 0:
				return ""

			# node name, null terminated.
			contents = pack( str(len(node.name) + 1) + "s", node.name)
		
			# no pos, scale, rotation...
			contents += pack("10f", 0, 0, 0, 1, 1, 1, 1, 0, 0, 0)
		
			# do actual mesh stuff
			contents += self.makeMeshChunk(node, object)
		

	 	self.debugChunkEnd(chunk, len(contents))

		
		# chunk + size + contents
		chunk += pack("i", len(contents)) + contents
		
		return chunk

	#
	# A MESH chunk
	#
	def makeMeshChunk(self, node, object):
		chunk = "MESH"

	 	self.debugChunkStart(chunk)

		
		# recalc normals, just in case...
		node.calcNormals()
		
		# brush id : -1
		contents = pack("i", -1)
		
		
		# process verts
		contents += self.makeVertsChunk(node, object)
		
		# process tris
		# TODO : work with different brushes...
		contents += self.makeTrisChunk(node.faces, object)
		

	 	self.debugChunkEnd(chunk, len(contents))

	
		# chunk + size + contents
		chunk += pack("i", len(contents)) + contents
		
		return chunk

	#
	# A VRTS chunk
	#
	def makeVertsChunk(self, node, object):
		chunk = "VRTS"

	 	self.debugChunkStart(chunk)


		counter = 0
		contents = ""
		
		# flags
		#    1 : has normals
		#    2 : has colour info
		contents += pack("i", 1)
		
		# textute coords per vertex ?
		if node.faceUV:
			contents += pack("i", 1)
		else:
			contents += pack("i", 0)
		
		# components pet set
		if node.faceUV:
			contents += pack("i", 2)
		else:
			contents += pack("i", 0)

		if self.debugLevel == 2:
			print "Face count = %d" % len(node.faces)
		
		for face in node.faces:

			vertices = face.verts

			# add to the "brush/face" dictionary
			# this dict stores faces per image, which is later used for the TRIS chunk
			if node.faceUV:
				if face.image:
					if not self.brushFacesDict.has_key(self.imageNameDict[face.image.name]):
						self.brushFacesDict[self.imageNameDict[face.image.name]] = {}

					self.brushFacesDict[self.imageNameDict[face.image.name]][len(self.brushFacesDict[self.imageNameDict[face.image.name]])] = face
				else:
					if not self.brushFacesDict.has_key(-1):
						self.brushFacesDict[-1] = {}

					self.brushFacesDict[-1][len(self.brushFacesDict[-1])] = face
			else:
				if not self.brushFacesDict.has_key(-1):
					self.brushFacesDict[-1] = {}

				self.brushFacesDict[-1][len(self.brushFacesDict[-1])] = face

			
			mm = object.getMatrix()

			for vi in range(len(vertices)):

				vert = face.verts[vi]

				
				# rotate vetices by -90 about the x axis, because Z is up in Blender
				objMatrix = Mathutils.Matrix(object.getMatrix('worldspace'))
				mm = matrixBlender2B3d * objMatrix * matrixB3d2Blender
				blenvert = Mathutils.Vector(vert.co)
				v = matrixBlender2B3d * blenvert * mm
			
				#for vert in face.verts:
				if node.faceUV:
					if face.image:
						id = "%d,%f,%f" % (self.imageNameDict[face.image.name], face.uv[vi].x, face.uv[vi].y)
					else:
						id = "%d,%f,%f" % (-1, face.uv[vi].x, face.uv[vi].y)
				else:
					id = vert.index

				if not self.vertDict.has_key(id):

					#if self.debugLevel == 2:
					#	print "vert ( %s ) : %d" % (str(id), counter)

					self.vertDict[id] = counter
					counter += 1


					# coords
					contents += pack("3f", v[0], v[1], v[2])
				
					# normal
					contents += pack("3f", vert.no.x, vert.no.y, vert.no.z)

					# UV stuff - only 1 x,y coord here...
					if node.faceUV:

						#if self.debugLevel == 2:
						#	print "UV coord = %f, %f" % (face.uv[vi][0], face.uv[vi][1])

						# if we negate the y coord, it uses the correct origin
						# but the image appears "mirrored"
						contents += pack("2f", face.uv[vi][0], 1 - face.uv[vi][1])
				
		
	 	self.debugChunkEnd(chunk, len(contents))

	
		# chunk + size + contents
		chunk += pack("i", len(contents)) + contents
		
		return chunk


	#
	# A TRIS chunk
	#
	def makeTrisChunk(self, faces, object):
		chunk = "TRIS"

	 	self.debugChunkStart(chunk)

		contents = ""
		
		node = Mesh.Get(object.data.name)

		for imageIndex in range(-1, len(self.imageNameDict)):

			if self.brushFacesDict.has_key(imageIndex):

				# brush id
				contents += pack("i", imageIndex)


				for f in range(len(self.brushFacesDict[imageIndex])):

					face = self.brushFacesDict[imageIndex][f]

					if self.debugLevel == 2:
						print "(%s) face %d" % (object.data.name, face.index)
			
					if len(face.verts) == 3:

				
						for i in range(3):

							if node.faceUV:
								if face.image:
									id = "%d,%f,%f" % (self.imageNameDict[face.image.name], face.uv[i].x, face.uv[i].y)
								else:
									id = "%d,%f,%f" % (-1, face.uv[i].x, face.uv[i].y)
							else:
								id = face.verts[i].index
						
							# triangles
							contents += pack("i", self.vertDict[id])
		
					else:

						for i in range(3):

							if node.faceUV:
								if face.image:
									id = "%d,%f,%f" % (self.imageNameDict[face.image.name], face.uv[i].x, face.uv[i].y)
								else:
									id = "%d,%f,%f" % (-1, face.uv[i].x, face.uv[i].y)
							else:
								id = face.verts[i].index
	
							# triangles
							contents += pack("i", self.vertDict[id])

						# triangles
						if node.faceUV:
							if face.image:
								img = self.imageNameDict[face.image.name]
							else:
								img = -1
							contents += pack("i", self.vertDict["%d,%f,%f" % (img, face.uv[2].x, face.uv[2].y)])
							contents += pack("i", self.vertDict["%d,%f,%f" % (img, face.uv[3].x, face.uv[3].y)])
							contents += pack("i", self.vertDict["%d,%f,%f" % (img, face.uv[0].x, face.uv[0].y)])
						else:
							contents += pack("i", self.vertDict[face.verts[2].index])
							contents += pack("i", self.vertDict[face.verts[3].index])
							contents += pack("i", self.vertDict[face.verts[0].index])

				
		
	 	self.debugChunkEnd(chunk, len(contents))

	
		# chunk + size + contents
		chunk += pack("i", len(contents)) + contents
		
		return chunk


#
# File callback routine
#
def file_callback(filename):
	if Blender.sys.exists(filename):
		result = PupMenu("File Already Exists, Overwrite?%t|Yes%x1|No%x0")
		if result != 1:
			return
        
	if not filename.endswith(".b3d"):
		filename += ".b3d"

	b3dexport = B3DExporter(filename)
	b3dexport.export()



#
# Starts here !
#
#try:
#	ARGS = __script__['arg']
#except:
#	print "Uh Oh.... Something bad happened."

if Blender.Get('version') < 243:
	print "You need at least version 2.43 to use this exporter!"
	print "..probably. It's certainly the one I used to test this ;-)"
	
else:
	Blender.Window.FileSelector(file_callback,"Save Blitz3D", Blender.sys.makename(ext=".b3d"))


