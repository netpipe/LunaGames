#!BPY
""" Registration info Blender menues:
Name:'Sflender'
Blender: 236
Group: 'Export'
Tooltip: 'S2flender(V2.6 BETA) Exporter to Macromedia(R) Flash(TM)'
"""
# -------------------------------------------------------------
#	 Copyright (c) 2003,2004,2005 Emilio Aguirre 
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# -------------------------------------------------------------
# -------------------------------------------------------------
# *This program is based on the Macromedia Flash SWF File Format Specification (version 3)
# by Macromedia, Inc. Copyright(c) 1995-2003 Macromedia, Inc. All rights reserved. 
# Macromedia and Flash are trademarks of Macromedia, Inc. (www.macromedia.com)
# -------------------------------------------------------------

# ---------------------------------------------------------------
# 	
#	Import Section			
#
# ---------------------------------------------------------------	
import Blender
from os import listdir
from Blender import Object,Lamp,Camera,NMesh,Types,sys
from Blender.Mathutils import *
from Blender.Draw import *
from Blender.Types import *
from Blender.BGL import *
from Blender.Noise import *
from math import *
from operator import add,sub,mul
from time import *
from zlib import *

# -------------------------------------------------------------
# Generic Functions
# -------------------------------------------------------------

INFINITY = 1e300000
NAN = INFINITY-INFINITY
sINF = str(INFINITY)
sNAN = str(NAN)
			
def getMid(p,q):
	return [(p[0]+q[0])/2,(p[1]+q[1])/2]
	
def dist(p,q):
	w = [q[0]-p[0], q[1]-p[1]]
	return sqrt((w[0]*w[0])+(w[1]*w[1]))

def bez3(p1,p2,p3,t):
	p = [0,0]
	t2 = t*t
	ct = 1 - t
	ct2 = ct*ct
	ct3 = 2 * ct * t
	p[0] = p1[0]*ct2 + ct3 *p2[0] + p3[0]*t2
	p[1] = p1[1]*ct2 + ct3 *p2[1] + p3[1]*t2
	return p

def Rot(x,y,theta):
	angle = theta*pi/180
	x1 = x*cos(angle) - y*sin(angle)
	y1 = x*sin(angle) - y*cos(angle)
	return [x1,y1]
	
def MaxAbs(l):
	if len(l)>0:
		m = abs(l[0])
		for i in l:
			if abs(i)>m:	m = abs(i)
		return m
	else:	return 0

def BitSgn(val):
	if val>0: return 0
	else:	return 128

def Pad0(n):
	return [0]*n

def Pad1(n):
	return [1]*n

def Padding(s):
	if s<8:	return Pad0(8-s)
	d = s % 8
	if d == 0:
		return []
	else:
		n = 8 - d
		return Pad0(n)

def SetFileLength(movie,a):
	r =	UI32(a)
	movie[4] = r[0]
	movie[5] = r[1]
	movie[6] = r[2]
	movie[7] = r[3]
	return
	
def GetChars(list):
	k = 0
	l = 0
	size = len(list)
	numbytes = size/8
	if ((size % 8) >0):	numbytes+=1
	bytes = Pad0(numbytes)
	byte = 0	
	for i in range(size):
		byte += list[i] * (2**(7-k)) 
		k+=1
		if k>7:
			bytes[l]=chr(byte)
			byte = 0
			k = 0
			l+=1
	if k>0 and k<8:	bytes[l] = chr(byte)
	return bytes

def PadChars(l):
	l.extend(Padding(len(l)))
   	return GetChars(l)

def GetBinary(number,digits=0):
	if digits == 0:
		maxbits = 1024
	else:
		maxbits = digits
	Bits = Pad0(maxbits)	
	idx = maxbits-1
	while (((number/2)!=0) and (idx>=0)):
		# Get modulus
		Bits[idx] = number % 2 
		number/=2
		idx-=1
	if (number==1):	Bits[idx]=1
	else:	Bits[idx]=0
	if digits >0:	return Bits
	else:	return Bits[idx:]

def NBits(val):	return len(val)

def InverseBits(l):
	return map(lambda x:abs(x-1),l)

def TwosComplement(val):
	b = InverseBits(GetBinary(val))
	d = GetBinary(1,len(b))
	r = []
	c = 0
	l = range(len(b))
	l.reverse()
	for i in l:
		s = b[i]+d[i]+c
		if s == 2:	
			r.append(0)
			c = 1
		else:
			r.append(s)
			c = 0
	r.reverse()
	return r

# -------------------------------------------------------------
# SWF Constants
# -------------------------------------------------------------
SOLID_FILL = 0
LINEAR_GRADIENT_FILL = 16
RADIAL_GRADIENT_FILL = 18
TILED_BITMAP_FILL = 64
CLIPPED_BITMAP_FILL = 65

#Place Object Flags
PO_NAME = 32
PO_RATIO = 16
PO_COLOR_TRANS = 8
PO_MATRIX = 4
PO_CHAR_ID = 2
PO_MOVE = 1
#Shape Object Flags
SH_MOVE = 1
SH_FILL0 = 2
SH_FILL1 = 4
SH_LINESTYLE = 8
SH_NEWSTYLES = 16
#Button state flags
BT_HIT = 8
BT_DOWN = 4
BT_OVER = 2
BT_UP = 1
#Buttons State transitions triggering actions
BT_IDLE_TO_OVERUP = 1
BT_OVERUP_TO_IDLE = 2
BT_OVERUP_TO_OVERDOWN = 4
BT_OVERDOWN_TO_OVERUP = 8
BT_OVERDOWN_TO_OUTDOWN = 16
BT_OUTDOWN_TO_OVERDOWN = 32
BT_OUTDOWN_TO_IDLE = 64
BT_IDLE_TO_OVERDOWN = 128
BT_OVERDOWN_TO_IDLE = 256
#Font Flags
FONT_HASLAYOUT = 128 
FONT_SHIFTJIS = 64
FONT_UNICODE = 32	
FONT_ANSI = 16		
FONT_WIDEOFFSETS = 8
FONT_WIDECODES = 4
FONT_ITALIC = 2
FONT_BOLD = 1
#Text Flags
TEXT_HASFONT = 8
TEXT_HASCOLOR = 4
TEXT_HASYOFFSET = 2
TEXT_HASXOFFSET = 1

# -------------------------------------------------------------
# Basic Data Types
# -------------------------------------------------------------

def UI8(val):
	return chr(val)

def UI16(val):
	"""Return in little-endian"""
	return chr((val&0x00ff)),chr(val>>8)

def UI32(val):
	"""Return in little-endian"""
	hi = UI16(val&0x0000ffff)
	lo = UI16(val>>16)
	return hi[0],hi[1],lo[0],lo[1]

def REVUI32(v):
	h2 = ord(v[0])
	h1 = ord(v[1])
	l2 = ord(v[2])
	l1 = ord(v[3])	
	return (((l1*256) + l2)*65536)+((h1*256) + h2)

def UB(val,size=0):
	v = GetBinary(val)
	z = size - len(v)
	if z>0:
		r = Pad0(z)
		r.extend(v)
		return r
	else:
		return v  

def SB(val,size=0):
	if val>=0:
		r=[0]
		r.extend(GetBinary(abs(val)))
	else:	
		r=[1]
		r.extend(TwosComplement(abs(val)))
	z = size - len(r)
	if z>0:
		if (val<0):	v = Pad1(z)
		else:	v = Pad0(z)
		v.extend(r)
		return v
	else:
		return r

def SI16(val):
	r = GetChars(SB(val,16))
	return r[1],r[0]

def SI32(val):
	r = GetChars(SB(val,32))
	return r[3],r[2],r[1],r[0]
	
def FB(val,size=0):
	midpos = 512
	maxbits= 1024
	if val>=0:	r=[0]
	else:	r=[1] 
	
	#Create bit list
	Bits = Pad0(maxbits)
	num = abs(val)

	#Get integer part
	intnum = abs(int(num))

	#Get decimal part
	decnum = num - intnum

	# Get binary representation of integer part
	idxI = midpos
	while (((intnum/2)!=0) and (idxI>=0)):
		# Get modulus
		Bits[idxI] = intnum % 2 
		intnum/=2
		idxI-=1
	if (intnum==1):	Bits[idxI]=1
	else:	Bits[idxI]=0

	# Get binary representation of decimal part
	idxD = midpos+1
	while (decnum>0.0 and idxD<maxbits):
		decnum*=2
		if (decnum>=1):
			Bits[idxD] = 1
			decnum-=1.0
		else:
			Bits[idxD] = 0
		idxD+=1

	i = idxI
	while (i<=midpos):
		r.extend([Bits[i]])
		i+=1
	i = 1
	while (i<=16):
		r.extend([Bits[i+midpos]])
		i+=1
	
	z = size - len(r)
	if z>0:
		if (val<0):	v = Pad1(z)
		else:	v = Pad0(z)
		v.extend(r)
		return v
	else:
		return r

def IEEE_FIXED(val):
	"""This returns a memory representation of a float point
	   according to the IEEE 32 bits flotating point representation.
		+- 1.x * 2^e
		where x is the matissa field
		and e is the bias exponent (bias = 127)
	
	Memory out put: Bit 3	3222222	222211111111110000000000
						1	0987654	321098765432109876543210
						Sign  Bias		Matissa
							  exponent					"""
	midpos = 512
	maxbits= 1024

	#Create bit list
	Bits = Pad0(maxbits)
	num = abs(val)

	#Get integer part
	intnum = int(num)

	#Get decimal part
	decnum = num - intnum

	# Get binary representation of integer part
	idxI = midpos
	while (((intnum/2)!=0) and (idxI>=0)):
		# Get modulus
		Bits[idxI] = intnum % 2 
		intnum/=2
		idxI-=1
	if (intnum==1):	Bits[idxI]=1
	else:	Bits[idxI]=0

	# Get binary representation of decimal part
	idxD = midpos+1
	while (decnum>0.0 and idxD<maxbits):
		decnum*=2
		if (decnum>=1):
			Bits[idxD] = 1
			decnum-=1.0
		else:
			Bits[idxD] = 0
		idxD+=1

	#Get exponent
	idx = 0
	while ((idx<maxbits) and (Bits[idx]!=1)):	idx+=1
	exponent = midpos - idx
	if exponent<-126:
		#infinite number
		exponent = -127
	bytes = [0,0,0,0]
	biasExponent = exponent + 127
	bytes[0] = BitSgn(val)+ (biasExponent >> 1)
	j = (midpos+1+(-1*exponent))
	k = 1
	l = 1
	byte = 0	
	for i in range(j,j+23):
		byte += Bits[i] * (2**(7-k)) 
		k+=1
		if k>7:
			bytes[l]=byte
			byte = 0
			k = 0
			l+=1
	bytes[1] += ((biasExponent << 7) & 128)
	# Return value in little-endian
	return [chr(bytes[3]),chr(bytes[2]),chr(bytes[1]),chr(bytes[0])]	 

def FIXED(val):
	midpos = 512
	maxbits= 1024
	if val>=0:	r=[0]
	else:	r=[1] 
	
	#Create bit list
	Bits = Pad0(maxbits)
	num = abs(val)

	#Get integer part
	intnum = abs(int(num))

	#Get decimal part
	decnum = num - intnum

	# Get binary representation of integer part
	idxI = midpos
	while (((intnum/2)!=0) and (idxI>=0)):
		# Get modulus
		Bits[idxI] = intnum % 2 
		intnum/=2
		idxI-=1
	if (intnum==1):	Bits[idxI]=1
	else:	Bits[idxI]=0

	# Get binary representation of decimal part
	idxD = midpos+1
	while (decnum>0.0 and idxD<maxbits):
		decnum*=2
		if (decnum>=1):
			Bits[idxD] = 1
			decnum-=1.0
		else:
			Bits[idxD] = 0
		idxD+=1
	for i in range(31):
		r.extend([Bits[midpos-14+i]])
	return r[24:]+r[16:24]+r[8:16]+r[0:8]

def RECT(x0,y0,x1,y1):
	#Convert values from pixels to TWIPS
	xmin =x0*20
	xmax =x1*20
	ymin =y0*20
	ymax =y1*20
	#Number of bits per value
	nbits = NBits(SB(MaxAbs([xmin,xmax,ymin,ymax])))
	#Create struct RECT
	r = []
	r = UB(nbits,5)
	r.extend(SB(xmin,nbits))
	r.extend(SB(xmax,nbits))
	r.extend(SB(ymin,nbits))
	r.extend(SB(ymax,nbits))
	return r

def MATRIX(sx,sy,rot0,rot1,tx,ty):
	r = []
	hasscale = 0
	hasrotate = 0
	if (sx!=1.0 or sy!=1.0):	hasscale = 1
	if (rot0!=0.0 or rot1!=0.0):	hasrotate = 1
	r = [hasscale]
	if (hasscale==1):
		nScaleBits =NBits(FB(MaxAbs([sx,sy])))
		r.extend(UB(nScaleBits,5))
		r.extend(FB(sx,nScaleBits))
		r.extend(FB(sy,nScaleBits))
	r.extend([hasrotate])
	if (hasrotate==1):
		nRotateBits = NBits(FB(MaxAbs([rot0,rot1])))
		r.extend(UB(nRotateBits,5))
		r.extend(FB(rot0,nRotateBits))
		r.extend(FB(rot1,nRotateBits))
	nTranslateBits = NBits(SB(MaxAbs([tx,ty])))
	r.extend(UB(nTranslateBits,5))
	r.extend(SB(tx,nTranslateBits))
	r.extend(SB(ty,nTranslateBits))
	return r

def RGB(r,g,b):
	return [chr(r),chr(g),chr(b)]

def RGBn(r,g,b):
	return [chr(r*255),chr(g*255),chr(b*255)]	

def RGBA(r,g,b,a):
	return [chr(r),chr(g),chr(b),chr(a)]

def RGBAn(r,g,b,a):
	return [chr(r*255),chr(g*255),chr(b*255),chr(a*255)]
	
def CXFORM(rmul,gmul,bmul,radd,gadd,badd):
	hasmult = 0
	hasadd = 0
	if (rmul!=0 or gmul!=0 or bmul!=0):	hasmult = 1
	if (radd!=0 or gadd!=0 or badd!=0):	hasadd = 1
	r = [hasadd,hasmult]
	nbits =  NBits(SB(MaxAbs([rmul,gmul,bmul,radd,gadd,badd])))
	r.extend(UB(nbits,4))
	if (hasmult>0):
		r.extend(SB(rmul,nbits))
		r.extend(SB(gmul,nbits))
		r.extend(SB(bmul,nbits))
	if (hasadd>0):
		r.extend(SB(radd,nbits))
		r.extend(SB(gadd,nbits))
		r.extend(SB(badd,nbits))
	return r 

def CXFORMWITHALPHA(rmul,gmul,bmul,amul,radd,gadd,badd,aadd):
	hasmult = 0
	hasadd = 0
	if (rmul!=0 or gmul!=0 or bmul!=0 or amul!=0):	hasmult = 1
	if (radd!=0 or gadd!=0 or badd!=0 or aadd!=0):	hasadd = 1
	r = [hasadd,hasmult]
	nbits = NBits(SB(MaxAbs([rmul,gmul,bmul,amul,radd,gadd,badd,aadd])))
	r.extend(UB(nbits,4))
	if (hasmult>0):
		r.extend(SB(rmul,nbits))
		r.extend(SB(gmul,nbits))
		r.extend(SB(bmul,nbits))
		r.extend(SB(amul,nbits))
	if (hasadd>0):
		r.extend(SB(radd,nbits))
		r.extend(SB(gadd,nbits))
		r.extend(SB(badd,nbits))
		r.extend(SB(aadd,nbits))
	return r

def STRING(s):
	r = []
	for i in range(len(s)):	r.append(s[i])
	r.append(chr(0))
	return r

# -------------------------------------------------------------
# Core Data Types
# -------------------------------------------------------------
def GRADRECORD(ratio,color):
	r = [chr(ratio)]
	if (len(color)>3):
		r.extend(RGBA(color[0],color[1],color[2],color[3]))
	else:
		r.extend(RGB(color[0],color[1],color[2]))
	return r

def GRADIENT(NumGradients,records):
	r = [chr(NumGradients)]
	for i in records:
		r.extend(i)
	return r	
	
def FILLSTYLE(type,param1=None,param2=None):
	r = [chr(type)]
	if type == SOLID_FILL:
		if len(param1)>3:
			r.extend(RGBA(param1[0],param1[1],param1[2],param1[3]))
		else:
			r.extend(RGB(param1[0],param1[1],param1[2]))
	elif (type == LINEAR_GRADIENT_FILL or type == RADIAL_GRADIENT_FILL):
		r.extend(PadChars(MATRIX(param1[0],param1[1],param1[2],param1[3],param1[4],param1[5])))
		r.extend(GRADIENT(param2[0],param2[1]))
	elif (type == TILED_BITMAP_FILL or type == CLIPPED_BITMAP_FILL):
		r.extend(UI16(param1))
		r.extend(PadChars(MATRIX(param2[0],param2[1],param2[2],param2[3],param2[4],param2[5])))
	return r

def FILLSTYLEARRAY(fillstyles):
	count = len(fillstyles)
	r = []
	if count>=255:
		r = [UI16(count)]
	else:
		r.extend(UI8(count))
	for i in fillstyles:
		r.extend(i)
	return r

def LINESTYLE(width,color):
	# Width in TWIPS
	w = UI16(width*10)
	r = [w[0],w[1]]
	# Color value
	if (len(color)>3):
		r.extend(RGBA(color[0],color[1],color[2],color[3]))
	else:
		r.extend(RGB(color[0],color[1],color[2]))
	return r
		
def LINESTYLEARRAY(linestyles):
	count = len(linestyles)
	r = []
	if count>255:	r.extend(UI16(count))
	else:	r.extend(UI8(count))
	for i in linestyles:
		r.extend(i)
	return r

def CURVEEDGERECORD(ControlDeltaX,ControlDeltaY,AnchorDeltaX,AnchorDeltaY):
	"""SWF uses Quadratic Bezier curves, they need only 3 points:
			- 2 on-curve anchor points, and 
			  1 off-curve control point.
		So, the first anchor point is the current drawing position,
			the control point is the current drawing position plus the ControlDelta
			the last anchor point is the current drawing position plus ControlDelta plus AnchorDelta
	Parameters:
			ControlDeltaX, ControlDeltaY, LastAnchorDeltaX, LastAnchorDeltaY."""
	r = [1,0]	# Curved Edge
	nbits = NBits(SB(MaxAbs([ControlDeltaX*20,ControlDeltaY*20,AnchorDeltaX*20,AnchorDeltaY*20])))
	r.extend(UB(nbits-2,4))	# Nbits is biased by 2 in the swf reader
	r.extend(SB(ControlDeltaX*20,nbits))	# X Control point change
	r.extend(SB(ControlDeltaY*20,nbits))	# Y Control point change
	r.extend(SB(AnchorDeltaX*20,nbits))	# X anchor point change
	r.extend(SB(AnchorDeltaY*20,nbits))	# Y anchor point change
	return r

def LINEEDGERECORD(DeltaX,DeltaY,lineflag=1,vertflag=0):
	""" Parameters: Delta X - Position X
					Delta Y - Position Y
					Line Flag - 1 General Line (Default option)
								  DeltaX and DeltaY are used.
								  Vert Flag parameter not used
								0 Vertical or Hotizontal Lines
					Vert Flag - 0 Horizontal Line Only DeltaX used
								1 Vertical line only DeltaY used
	"""
	r = [1,1] 	#Straight Edge
	nbits = NBits(SB(MaxAbs([DeltaX*20,DeltaY*20])))
	r.extend(UB(nbits-2,4))
	r.extend([lineflag])
	if lineflag==1: 	# Save General Lines	#Nbits are biased by 2 in swf reader
		r.extend(SB(DeltaX*20,nbits))
		r.extend(SB(DeltaY*20,nbits))
	else:
		r.extend([vertflag])
		if vertflag == 0:	r.extend(SB(DeltaX*20,nbits))
		else:	r.extend(SB(DeltaY*20,nbits))	
	return r
		

def ENDSHAPERECORD():
	return [0,0,0,0,0,0]

def STYLESHAPERECORD(f,DeltaX=0,DeltaY=0,Fill0Style=0,Fill1Style=0,LineStyle=0,nfbits=1,nlbits=1,FillArr=[],LineArr=[],sizepad=0):
	# Defines changes in line style, fill style, position
	flags = GetBinary(f,5)
	r = [0]
	r.extend(flags)
	if flags[4]==1:
		MoveBits = NBits(SB(MaxAbs([DeltaX*20,DeltaY*20])))
		r.extend(UB(MoveBits,5))
		r.extend(SB(DeltaX*20,MoveBits))	# Move x converted to TWIPS (1 TWIP = 1 Pixel * 20 )
		r.extend(SB(DeltaY*20,MoveBits))	# Move y
	if flags[3]==1:							# StateFillStyle0
		r.extend(UB(Fill0Style,nfbits))	#Fill 0 style
	if flags[2]==1:
		r.extend(UB(Fill1Style,nfbits))	#Fill 1 style
	if flags[1]==1:
		r.extend(UB(LineStyle,nlbits))	#Line style
	if flags[0]== 1:
		r.extend(Padding(sizepad+len(r)))
		nfill = ord(FillArr[0])
		for i in FillArr:					# FillStylesArray
			r.extend(GetBinary(ord(i),8))
		nline = ord(LineArr[0])
		for i in LineArr:					# LineStylesArray
			r.extend(GetBinary(ord(i),8))
		r.extend(UB(NBits(GetBinary(nfill)),4))
		r.extend(UB(NBits(GetBinary(nline)),4))
	return r

def SHAPE(records,nfbits=15,nlbits=15):
	r = UB(nfbits,4)
	r.extend(UB(nlbits,4))
	for i in records:	r.extend(i)
	return r

def SHAPEWITHSTYLE(fillstylesarr,linestylesarr,records,nfbits=15,nlbits=15):
	r = []
	r.extend(fillstylesarr)
	r.extend(linestylesarr)
	r.extend([chr(((nfbits << 4) + nlbits) & 255)])
	for i in records:	r.extend(i)
	return r	

def BUTTONRECORD(flags,characterID,layer,matrix,ColorTransform=None):
	r = []
	r.extend(flags)
	r.extend(UI16(characterID))
	r.extend(UI16(layer))
	r.extend(PadChars(matrix))
	if ColorTransform!=None:
		r.extend(PadChars(ColorTransform))
	return r

def KERNINGRECORD(wideflag,Code1,Code2,Adjustment):
	r = []
	if wideflag == 1:
		r.extend(UI16(Code1))
		r.extend(UI16(Code2))
	else:
		r.extend(chr(Code1))
		r.extend(chr(Code2))
	r.extend(SI16(Adjustment))
	return r
		
# -------------------------------------------------------------
# SWF File Tags Headers
# -------------------------------------------------------------

def swfWrite(name,buf):
	ans = 0
	try:
		f = open(name,'wb')
		for byte in buf:
			f.write(byte)
		f.close()
	except IOError, (errno,strerror):
		print "I/O Error(%s):%s" % (errno,strerror)
		ans = 1
	return ans

def CompressSWF(name):
	f = open(name,'rb')
	header = f.read(8)
	sz =  REVUI32([header[4],header[5],header[6],header[7]])
	sz-=8
	data = f.read(sz)
	f.close()
	
	cm = compress(data)
	
	cmpheader = [chr(67),header[1],header[2],header[3],header[4],header[5],header[6],header[7]]
	f = open(name,'wb')
	for byte in cmpheader:
		f.write(byte);
	f.write(cm)
	f.close()
	del cm,header,data,sz,cmpheader
	
	return 

def swfHeaderBlock(filelength,framesize,framerate,framecount):
	"""Header Block:
		Signature	'F'	1 byte
					'W'	1 byte
					'S'	1 byte
		Version	 		1 byte
		File length	    4 bytes
		Frame size      5 bytes
		Frame rate      2 bytes
		Frame count     2 bytes"""
	#Initialize	
	buf = ['F','W','S',chr(6)] # SWF Version 6 to allow compression
	#FileLength
	buf.extend(UI32(filelength))
	#Frame Size
	buf.extend(PadChars(RECT(framesize[0],framesize[1],framesize[2],framesize[3])))
	#Frame rate
	fr = UI16(framerate)
	buf.extend(fr[1])
	buf.extend(fr[0])
	#Frame count
	fr = UI16(framecount)
	buf.extend(fr)
	# Return the buffer
	return buf
	
def swfTagHeader(tag,length):
	r = []
	if (length<=62):
		#Short Header
		n = (tag << 6) + length
		r.extend(UI16(n))
	else:
		#Long Header
		n = (tag << 6) + 63
		r.extend(UI16(n))
		r.extend(UI32(length))
	return r

# -------------------------------------------------------------
# SWF File Tags
# There are two categories of tags: definition and control
# Definition tags manage a dictionary of resources. 
# Control tags control the display list and enable actions.
#
# CAUTION: Not all the tags were defined in this program
# because I only use a base set of SWF tags to be able to
# export blender animations.
# -------------------------------------------------------------

# -------------------------------------------------------------
# 		Control Tags
# 		- Control:
#			SetBackgroundColor
#			Protect 
#			FrameLabel
#			StartSound
#			End
#		- Display List: 
#			PlaceObject
#			PlaceObject2
#			RemoveObject
#			RemoveObject2
#			ShowFrame
#		- Actions
#			DoAction
# -------------------------------------------------------------
def swfPlaceObject(characterId,depth,matrix,colortransform = None):
	size = 4 + len(matrix)
	if colortransform != None:
		size+= len(colortransform)
	r = swfTagHeader(4,size)
	r.extend(UI16(characterId))
	r.extend(UI16(depth))
	r.extend(PadChars(matrix))
	if colortransform !=None:	r.extend(PadChars(colortransform))
	return r

def swfPlaceObject2(f,depth,param):
	flags = GetBinary(f,6)
	size = 3 
	if flags[0] == 1:	#Has name
		name = STRING(param[0])
		size+=len(name)
	if flags[1] == 1:	#Has ratio
		ratio = UI16(param[1])
		size+=2
	if flags[2] == 1:	#Has color transform
		colortrans =  PadChars(CXFORM(param[2][0],param[2][1],param[2][2],param[2][3],param[2][4],param[2][5]))
		size+= len(colortrans)
	if flags[3] == 1:	#Has matrix
		matrix =  PadChars(MATRIX(param[3][0],param[3][1],param[3][2],param[3][3],param[3][4],param[3][5]))
		size+= len(matrix)
	if flags[4] == 1:	#Has place a character
		character = UI16(param[4])
		size+=2
	if flags[5] == 1:	#Move
  		pass
	r = swfTagHeader(26,size)
	bits = [0,0]	# Reserved flags
	bits.extend(flags)
	r.extend(GetChars(bits))
	r.extend(UI16(depth))
	if (flags[4]==1):	r.extend(character)
	if (flags[3]==1):	r.extend(matrix)
	if (flags[2]==1):	r.extend(colortrans)
	if (flags[1]==1):	r.extend(ratio)
	if (flags[0]==1):	r.extend(name)
	return r

def swfRemoveObject(id,depth):
	r = swfTagHeader(5,4)
	r.extend(UI16(id))
	r.extend(UI16(depth))
	return r

def swfRemoveObject2(depth):
	r = swfTagHeader(28,2)
	r.extend(UI16(depth))
	return r

def swfShowFrame():
	"""Flag the end of the current frame. During playback, the 
	characters present in the display list will be rendered and
	the mouvie paused for the duration of a single frame."""
	return swfTagHeader(1,0)

def swfSetBackgroundColor(r,g,b):
	""" Set the background color of the display  Tag ID = 9 """
	return swfTagHeader(9,3) + RGB(r,g,b)

def swfFrameLabel(label):
	str = STRING(label)
	r = swfTagHeader(43,len(str))
	r.extend(str)
	return r

def swfProtect():
	""" Marks a file as not importable for editing in the authoring tool."""
	return swfTagHeader(24,0)

def swfStartSound(id,soundinfo):
	"""Start playing the sound character"""
	size = 2 + len(soundinfo)
	r = swfTagHeader(15,size)
	r.extend(UI16(id))
	r.extend(soundinfo)
	return r

def swfEnd():
	"""Marks the end of a file. This should always be the last tag 
		in the file."""
	return swfTagHeader(0,0) 


# -------------------------------------------------------------
# 		Action Tags
# -------------------------------------------------------------
def swfActionGotoFrame(frame):
	r = [chr(129)]
	r.extend(UI16(2))
	r.extend(UI16(frame))
	return r

def swfActionGetURL(url,window):
	r = [chr(131)]
	us = STRING(url)
	uw = STRING(window)
	r.extend(UI16(len(us)+len(uw)))
	r.extend(us)
	r.extend(uw)
	return r

def swfActionNextFrame():
	return [chr(4)]

def swfActionPrevFrame():
	return [chr(5)]

def swfActionPlay():
	return [chr(6)]

def swfActionStop():
	return [chr(7)]

def swfActionToggleQualty():
	return [chr(8)]

def swfActionStopSounds():
	return [chr(9)]

def swfActionWaitForFrame(frame,skipcount):
	r = [chr(138)]
	r.extend(UI16(3))
	r.extend(UI16(frame))
	r.extend([chr(skipcount)])
	return r

def swfActionSetTarget(length,targetname):
	r = [chr(139)]
	r.extend(UI16(length))
	tn = STRING(targetname)
	r.extend(tn)
	return r

def swfActionGoToLabel(length,label):
	r = [chr(140)]
	r.extend(UI16(length))
	tn = STRING(label)
	r.extend(tn)
	return r
	
def swfDoAction(actionlist):
	r = swfTagHeader(12,len(actionlist)+1)
	if len(actionlist)>0:	r.extend(actionlist)
	r.extend([chr(0)])
	return r
# -------------------------------------------------------------
# 		Definition Tags
#		- DefineShape
#		- DefineShape2
# 		- DefineShape3
#		- DefineSprite	(SWF 3.0)
#		- DefineBits
#		- DefineButton
#		- DefineButton2
#		- DefineButtonCxform
# -------------------------------------------------------------
def swfDefineShape(id,rect,shapewithstyle):
	""" Defines a vector shape object. The shape definition
	is a full-length encoded list of bezier curve information
	line styles and fill styles. (SWF 1.0)"""
	c = PadChars(rect)
	size = len(c) + len(shapewithstyle)
	r = swfTagHeader(2,size+2)
	r.extend(UI16(id))
	r.extend(c)
	r.extend(shapewithstyle)
	return r

def swfDefineShape2(id,rect,shapewithstyle):
	"""Extends the capabilities of DefineShape with the ability
	to support more than 255 styles in the style list and multiple
	style lists in a single shape (SWF 2.0) """
	c = PadChars(rect)
	size = len(c) + len(shapeinfo)
	r = swfTagHeader(22,size+2)
	r.extend(UI16(id))
	r.extend(c)
	r.extend(shapewithstyle)
	return r

def swfDefineShape3(id,rect,shapewithstyle):
	"""Extends the capabilitys of the DefineShape2 
	by extending all of the RGB color fields to support
	RGBA with alpha transparency (SWF 3.0)"""
	c = PadChars(rect)
	size = len(c) + len(shapewithstyle)
	r = swfTagHeader(32,size+2)
	r.extend(UI16(id))
	r.extend(c)
	r.extend(shapewithstyle)
	return r

def swfDefineSprite(id,numframes,movie):
	size = len(movie) + 4
	r = swfTagHeader(39,size)
	r.extend(UI16(id))
	r.extend(UI16(numframes))
	r.extend(movie)
	return r

def swfDefineBits(id,jpeg):
	"""Define a Bitmap character with JPEG compression."""
	size = len(jpeg) + 2
	r = swfTagHeader(6,size)
	r.extend(UI16(id))
	r.extend(jpeg)
	return r

def JPEGTables(jpegencodingtable):
	"""Defines the JPEG encoding table for the JPEG images
		defined using the DefineBits records."""
	size = len(jpegencodingtable)
 	r = swfTagHeader(8,size)
	r.extend(jpegencodingtable)
	return r

def swfDefineBitsJPEG2(id,jpeg,jpegencodingtable):
	"""Define a Bitmap character with JPEG compression. This tag
	differs from DefineBits in that the record contains both JPEG
	encoding table and image data. This record allows multiple
	JPEGs with different compression rations inside a single SWF file.
	The JPEG encoding and image data contained here are two separate
	JPEG streams.
	Important NOTE:  Each JPEG stream begins with the tag (0xFF,0xD8)
	and a end of tream tag (0xFF,0xD9). This differs from the 
	standard JPEG file that combines the image and the encoding data
	into the same stream"""
	size = len(jpeg) + len(jpegencodingtable) + 2
	r = swfTagHeader(21,size)
	r.extend(UI16(id))
	r.extend(jpegencodingtable)
	r.extend(jpeg)
	return r

def swfDefineButton(id,buttonrecords,actions):
	"""Define a button character. A button is defined by an 
	up image, mouse over image, depressed image and a hit region.
	There is also a list of actions to take when the button is clicked
	and released."""
	size = 2 + len(buttonrecords) + len(actions)
	r = swfTagHeader(7,size)
	r.extend(UI16(id))
	r.extend(buttonrecords)
	r.extend([chr(0)])	# Button End Flag always 0
	r.extend(actions)
	r.extend([chr(0)])	# Actions End Flag always 0
	return r

def ACTCONDITIONLST(actconditions):
	r = []
	offset = 0
	for act in actconditions:
		r.extend(UI16(offset))
		r.extend(act)
		offset += len(act)
	return r

def ACTCONDITION(flags,actions):
	r = UI16(flags)
	r.extend(actions)
	r.extend([chr(0)]) #Actions End Flag always 0
	return

	
def swfDefineButton2(id,flags,buttonrecords,actconditionlst):
	"""Define a button character. A button is defined by an 
	up image, mouse over image, depressed image and a hit region.
	You can also specif the color transformation and sound data.
	There is also a list of actions to take when the button is clicked
	and released. (SWF 3.0) """	
	size = 3 + len(buttonrecords) + len(actconditionlst)
	r = swfTagHeader(34,size)
	r.extend(UI16(id))
	r.extend([chr(flags)])	# flags = 0 or 1
	r.extend(buttonrecords) # This records has to have COLORTRANSFORM with ALPHA
	r.extend([chr(0)])	# Button End Flag always 0
	r.extend(actionsconditions)
	return r

def swfDefineButtonCxform(id,colortransform):
	size = 2 + len(colortransform)
	r = swfTagHeader(23,size)
	r.extend(UI16(id))
	r.extend(colortransform)
	return r

# ------------------------------------------------------
# Fonts and Text
# ------------------------------------------------------

def swfDefineFont(id,OffsetTable,ShapeTable):
	size = 2 + len(OffsetTable)+ len(ShapeTable)
	r = swfTagHeader(10,size)
	r.extend(UI16(id))
	for offset in OffsetTable:	r.extend(UI16(offset))
	for shape in ShapeTable:	r.extend(shape)
	return r

def swfDefineFont2(id,FontFlags,Fontname,OffsetTable,ShapeTable,FontCodeTable,Layout=None):
	"""
		Id - Object Id
		
		FontFlags:
			FONT_HASLAYOUT	- FontFlagsHasLayout UB[1]: Has font metrics/layout information
			FONT_SHIFTJIS	- FontFlagsShiftJIS  UB[1]: ShiftJIS encoding
			FONT_UNICODE	- FontFlagsUnicode   UB[1]: Unicode encoding
			FONT_ANSI		- FontFlagsAnsi		 UB[1]: ANSI encoding
			FONT_WIDEOFFSETS- FontFlagsWideOffsets UB[1]: if 1, uses 32 bit offsets
			FONT_WIDECODES  - FontFlagsWideCodes UB[1]: If 1 fonts uses 16-bit codes
														o uses 8 bit codes.
			FONT_ITALIC		- FontFlagsItalic	 UB[1]: Italic Font
			FONT_BOLD		- FontFlagsBold		 UB[1]: Bold Font
		Fontname - String font name
		Offset Table - Beginnig of next shape in the Shape Table
		Shape Table - List of ShapeObjects that define each glyph
		FontCodeTable- Table of font codes
		Layout:
			[FontAscent,FontDescent,FontLeading,[{FontAdvanceTable <SI16>} list],[{FontBoundsTable <RECT>} list ],[Kerning <KERNINGRECORD> list]]
			
	"""
	flags = GetBinary(FontFlags)

	r = [] 
	r.extend(UI16(id))
	r.extend(chr(0))	# FontFlagsReserved UB[8]
	r.extend(chr(FontFlags))
	name = STRING(Fontname) 
	r.extend(chr(len(name)))
	r.extend(name)
  	r.extend(UI16(len(ShapeTable)))	#nGlyphs
	for offset in OffsetTable:	
		if (flags[4]==1):	# FONT_WIDEOFFSETS 
			r.extend(UI32(offset))
		else:	r.extend(UI16(offset))
	for shape in ShapeTable:	r.extend(shape)
	for code in FontCodeTable:
		if (flags[5]==1):	# FONT_WIDECODES
			r.extend(UI16(code))
		else:	r.extend(chr(code))
	if (flags[0]==1):		#FONT_HASLAYOUT
		r.extend(SI16(LayOut[0]))	#FontAscent	
		r.extend(SI16(Layout[1]))	#FontDescent
		r.extend(SI16(Layout[2]))	#FontLeading
		for glyph in Layout[3]:
			r.extend(SI16(glyph))	#FontAdvanceTable
		Bounds = []
		for rect in Layout[4]:	Bounds.extend(rect)	#FontBoundsTable
		r.extend(PadChars(Bounds))
		r.extend(UI16(len(Layout[5])))	#FontKerningCount
		for kerning in Layout[5]:	r.extend(kerning)
	
	r1 = swfTagHeader(48,len(r))
	r1.extend(r)
	return r1

def swfDefineFontInfo(FontId,Fontname,FontFlags,CodeTable):
	"""
		Font Id	- Id Font
		Font name - string 
		FontFlags:
			FONT_UNICODE	- FontFlagsUnicode   UB[1]: Unicode encoding
			FONT_SHIFTJIS	- FontFlagsShiftJIS  UB[1]: ShiftJIS encoding
			FONT_ANSI		- FontFlagsAnsi		 UB[1]: ANSI encoding
			FONT_ITALIC		- FontFlagsItalic	 UB[1]: Italic Font
			FONT_BOLD		- FontFlagsBold		 UB[1]: Bold Font
			FONT_WIDECODES  - FontFlagsWideCodes UB[1]: If 1 fonts uses 16-bit codes
														o uses 8 bit codes.
		CodeTable - Glyph code table 
	"""
	r = []
	r.extend(UI16(FontId))
	name = STRING(Fontname)
	r.extend(char(len(name)))
	r.extend(name)
	flags = GetBinary[FontFlags]
	newflags = [0,0,flags[2],flags[1],flags[3],flags[6],flags[7],flags[5]]
	r.extend(GetChars(newflags))
	for glyphs in CodeTable:
		if (flags[7]==1):	r.extend(UI16(glyphs))
		else:	r.extend(chr(glyphs))

	r1 = swfTagHeader(13,len(r))
	r1.extend(r)
	return r1

def GLYPHENTRY(idx,value,nGlyphBits=8,nAdvanceBits=8):
	r = []
	r.extend(UB(idx,nGlyphBits))
	r.extend(UB(value,nAdvanceBits))
	return r	

def TEXTRECORDTYPE0(TextGplyphEntries):
	r = [0]
	nglyphs = len(TextGplyphEntries)
	r.extend(UB(nglyphs,7))
	for glyph in TextGplyphEntries:
		r.extend(glyph)
	return PadChars(r)

def TEXTRECORDTYPE1(TextFlags,Fontid=0,height=0,color=None,x=0,y=0):
	f = [1,0,0,0]
	f.extend(GetBinary(flags))
	r = GetChars(f)
	if (f[4]==1):	r.extend(UI16(Fontid))
	if (f[5]==1):   
		if len(color)>3:	r.extend(RGBA(color))
		else:	r.extend(RGB(color))
	if (f[7]==1):	r.extend(UI16(x))
	if (f[6]==1):	r.extend(UI16(y))
	if (f[4]==1):	r.extend(UI16(height))
	return r

def swfDefineText(Textid,bounds,matrix,textrecords,nGlyphBits=8,nAdvanceBits=8):
	r = []
	r.extend(UI16(Textid))
	a = []
	a.extend(bounds)
	a.extend(matrix)
	r.extend(PadChars(a))
	r.append(chr(nGlyphBits))
	r.append(chr(nAdvanceBits))
	for record in textrecords:	r.extend(record)
	r.append(chr(0))
	r1 = swfTagHeader(11,len(r))
	r1.extend(r)
	return r1

def swfDefineText2(Textid,bounds,matrix,textrecords,nGlyphBits=8,nAdvanceBits=8):
	r = []
	r.extend(UI16(Textid))
	a = []
	a.extend(bounds)
	a.extend(matrix)
	r.extend(PadChars(a))
	r.append(chr(nGlyphBits))
	r.append(chr(nAdvanceBits))
	for record in textrecords:	r.extend(record)
	r.append(chr(0))
	r1 = swfTagHeader(11,len(r))
	r1.extend(r)
	return r1

# ------------------------------------------------------
# Blender SWF Wrap Classes
# ------------------------------------------------------

# --------------------------------------------------------------
# 
# Class bShape
# 
# -------------------------------------------------------------
class bShape:
	"Blender swf shape class"
	recbits = []
	fsa = []
	lsa = []
	nFills = 0
	nLines = 0
	def __init__(self,fillstylearr=[],linestylearr=[]):
		"bShape initialization."	
		recbits = []
		fsa = fillstylearr
		lsa = linestylearr
	def AddFillStyle(self,fillstyle):
		self.fsa.append(fillstyle)
		self.nFills+=1
	def AddLineStyle(self,linestyle):
		self.lsa.append(linestyle)
		self.nLines+=1
	def MoveTo(self,x,y):
		self.recbits.extend(STYLESHAPERECORD(SH_MOVE,x,y))
	def SetCurrentFill0(self,id,numfills=0):
		if numfills>0:	self.recbits.extend(STYLESHAPERECORD(SH_FILL0,0,0,id,0,0,NBits(UB(numfills))))
		else:	self.recbits.extend(STYLESHAPERECORD(SH_FILL0,0,0,id,0,0,NBits(UB(self.nFills))))
	def SetCurrentFill1(self,id,numfills=0):
		if numfills>0:	self.recbits.extend(STYLESHAPERECORD(SH_FILL1,0,0,0,id,0,NBits(UB(numfills))))
		else:	self.recbits.extend(STYLESHAPERECORD(SH_FILL1,0,0,0,id,0,NBits(UB(self.nFills))))
	def SetCurrentLine(self,id,numlines=0):
		if numlines>0:	self.recbits.extend(STYLESHAPERECORD(SH_LINESTYLE,0,0,0,0,id,0,NBits(UB(numlines))))
		else:	self.recbits.extend(STYLESHAPERECORD(SH_LINESTYLE,0,0,0,0,id,0,NBits(UB(self.nLines))))
	def AddNewStyles(self,nfb=1,nlb=1,FillArr=[],LineArr=[],sizepad=0):
		self.recbits.extend(STYLESHAPERECORD(SH_NEWSTYLES,0,0,0,0,0,nfb,nlb,FillArr,LineArr,len(self.recbits)))
	def SetStyleRecord(self,f,DeltaX=0,DeltaY=0,Fill0Style=0,Fill1Style=0,LineStyle=0,nfbits=1,nlbits=1,FillArr=[],LineArr=[]):
		self.recbits.extend(STYLESHAPERECORD(f,DeltaX,DeltaY,Fill0Style,Fill1Style,LineStyle,nfbits,nlbits,FillArr,LineArr,len(self.recbits)))
	def LineTo(self,x,y):
		self.recbits.extend(LINEEDGERECORD(x,y))
	def CurveTo(self,cx,cy,ax,ay):
		self.recbits.extend(CURVEEDGERECORD(cx,cy,ax,ay))
	def EndShape(self):
		self.recbits.extend(ENDSHAPERECORD())
	def GetShape(self):
		nFillBits = NBits(UB(self.nFills))
		nLineBits = NBits(UB(self.nLines))
		return SHAPEWITHSTYLE(FILLSTYLEARRAY(self.fsa),LINESTYLEARRAY(self.lsa),PadChars(self.recbits),nFillBits,nLineBits)
	def Reset(self):
		self.recbits = []
		self.fsa = []
		self.lsa = []
		self.nFills = 0
		self.nLines = 0

# -----------------------------------------------------------------
# Test SWF
# -----------------------------------------------------------------
#movie = swfHeaderBlock(0,[0,0,4000,4000],12,1)
#movie+=swfSetBackgroundColor(255,255,255)
#actions = swfActionStop()
#movie+=swfDoAction(actions)
#a = FILLSTYLEARRAY([FILLSTYLE(SOLID_FILL,[0,255,0,255]),FILLSTYLE(SOLID_FILL,[0,0,255,255]),FILLSTYLE(SOLID_FILL,[255,255,0,255])])
#b = LINESTYLEARRAY([LINESTYLE(1,[0,0,0,255]),LINESTYLE(3,[0,255,255,255])])
#nFillBits = NBits(UB(3)) 
#nLineBits = NBits(UB(2))
#sh = bShape()
#sh.AddFillStyle(FILLSTYLE(RADIAL_GRADIENT_FILL,[0.065,0.065,0.0,0.0,1000,3500],[2,[GRADRECORD(0,[255,0,0,255]),GRADRECORD(255,[0,0,0,255])]]))
#sh.AddFillStyle(FILLSTYLE(LINEAR_GRADIENT_FILL,[0.065,0.065,0.0,0.0,1000,3500],[2,[GRADRECORD(0,[0,255,0,255]),GRADRECORD(255,[0,0,0,255])]]))
#sh.AddFillStyle(FILLSTYLE(SOLID_FILL,[255,255,0,255]))
#sh.AddLineStyle(LINESTYLE(1,[0,0,0,255]))
#sh.AddLineStyle(LINESTYLE(3,[0,255,255,255]))
#sh.SetStyleRecord(SH_MOVE+SH_FILL0+SH_FILL1+SH_LINESTYLE,0,3000,0,1,0,nFillBits,nLineBits)
#sh.LineTo(0,1000)
#sh.CurveTo(1000,0,0,-1000)
#sh.LineTo(-1000,0)
#sh.SetStyleRecord(SH_MOVE+SH_FILL0+SH_FILL1+SH_LINESTYLE,1000,3000,0,2,0,nFillBits,nLineBits)
#sh.LineTo(0,1000)
#sh.LineTo(1000,0)
#sh.LineTo(0,-1000)
#sh.LineTo(-1000,0)
#sh.MoveTo(150,305)
#sh.LineTo(250,0)
#sh.LineTo(0,200)
#sh.LineTo(-250,0)
#sh.LineTo(0,-250)
#sh.SetStyleRecord(SH_MOVE+SH_FILL0+SH_FILL1,0,2900,3,1,0,nFillBits,nLineBits)
#sh.LineTo(0,500)
#sh.LineTo(500,0)
#sh.LineTo(0,-500)
#sh.MoveTo(1000,2900)
#sh.LineTo(0,500)
#sh.CurveTo(200,0,0,-500)
#sh.LineTo(-500,0)
#sh.MoveTo(2000,2900)
#sh.LineTo(0,500)
#sh.LineTo(500,0)
#sh.LineTo(0,-500)
#sh.LineTo(-500,0)
#sh.EndShape()
#movie+=swfDefineShape3(1,RECT(0,0,4000,4000),sh.GetShape())
#movie+=swfPlaceObject2(PO_MATRIX+PO_CHAR_ID,2,[0,0,0,[1.0,1.0,0.0,0.0,0.0,0.0],1])
#movie+=swfShowFrame()
#movie+=swfEnd()
#SetFileLength(movie,len(movie))
#print movie
#swfWrite('c:\swf\demo.swf',movie)
#print "Saved!"

# --------------------------------------------------------------
# 
# Class CRect
# 
# -------------------------------------------------------------
class CRect:
	""" CRect (Left,Top, Right, Bottom) Rectangle class
		Remember that the position (0,0) correspond to the
		left-bottom of the screen. """
	def __init__(self,l=0,t=0,r=0,b=0):
		self.SetRect(l,t,r,b)
	def SetRect(self,l=0,t=0,r=0,b=0):
		self.L = l
		self.T = t
		self.R = r
		self.B = b
	def SetNullRect(self):
		self.L = 0
		self.T = 0
		self.R = 0
		self.B = 0
	def Width(self):
		return abs(self.R-self.L)
	def Height(self):
		return abs(self.T-self.B)
	def Center(self):
		return self.L+int((float(self.Width())/2.0)+0.5),self.B+int((float(self.Height())/2.0)+0.5)
	def PtInRect(self,x,y):
		if (x>=self.L and x<=self.R and y>=self.B and y<=self.T):	return 1
		else:	return 0
	def OffsetRect(self,x,y):
		self.L += x
		self.T += y
		self.R += x
		self.B += y
		
def drawFrame(l,t,w,h,b=3):
	glShadeModel(GL_SMOOTH)
	glBegin(GL_QUADS)
	glColor3f(0.8,0.8,0.8)
	glVertex2d(l,t)
	glColor3f(0.5,0.5,0.5)
	glVertex2d(l+w,t)
	glColor3f(0.2,0.2,0.2)
	glVertex2d(l+w,t-h)
	glColor3f(0.5,0.5,0.5)
	glVertex2d(l,t-h)
	glEnd()		
	glBegin(GL_QUADS)
	glColor3f(0.2,0.2,0.2)
	glVertex2d(l+b,t-b)
	glColor3f(0.5,0.5,0.5)
	glVertex2d(l+w-b,t-b)
	glColor3f(0.8,0.8,0.8)
	glVertex2d(l+w-b,t-h+b)
	glColor3f(0.5,0.5,0.5)
	glVertex2d(l+b,t-h+b)
	glEnd()		
	glShadeModel(GL_FLAT)
	return

# --------------------------------------------------------------
# 
# Class CGHandle
# 
# -------------------------------------------------------------
class CGHandle:
	"Graphic Handle class"
	rc = None
	id = 0
	intensity = 0
	maxcolors = 32
	def __init__(self,i=0,id=0,l=0,t=0,r=0,b=0,ty=0):
		self.rc = CRect(l,t,r,b)
		self.id = id
		self.intensity = i
		self.type = ty
	def SetID(self,id):
		self.id = id
	def SetType(self,ty):
		self.type = ty
	def MoveTo(self,x,y):
		ctr = self.rc.Center()
		dx = x - ctr[0]
		dy = y - ctr[1]
		self.rc.OffsetRect(dx,dy)
		del dx,dy,ctr
	def SetIntensity(self,i):
		self.intensity = i
	def Draw(self):
		if self.type == 0:
			glColor3f(1.0,0.0,0.0)
			glBegin(GL_TRIANGLES)
			glVertex2d(self.rc.L,self.rc.B+15)
			glVertex2d(self.rc.R,self.rc.B+15)
			glVertex2d(self.rc.Center()[0],self.rc.T+5)
			glEnd()
			glColor3f(0.0,0.0,0.0)
			glRasterPos2d(self.rc.L,self.rc.B+5)
			Text(str(self.id))
		else:
			glColor3f(1.0,1.0,1.0)
			glBegin(GL_LINE_LOOP)
			glVertex2d(self.rc.L,self.rc.B)
			glVertex2d(self.rc.R,self.rc.B)
			glVertex2d(self.rc.R,self.rc.T)
			glVertex2d(self.rc.L,self.rc.T)
			glEnd()	
			glColor3f(0.0,0.0,0.0)
			glBegin(GL_LINES)
			glVertex2d(self.rc.L+1,self.rc.B-1)
			glVertex2d(self.rc.R,self.rc.B-1)
			glEnd()	
			glBegin(GL_LINES)
			glVertex2d(self.rc.L+1,self.rc.T)
			glVertex2d(self.rc.L+1,self.rc.B-2)
			glEnd()	
	def HitTest(self,x,y):
		return self.rc.PtInRect(x,y)

# --------------------------------------------------------------
# 
# Class CFlatButton
# 
# -------------------------------------------------------------
class CFlatButton:
	"Flat Button class"
	def __init__(self,l=0,b=0,w=0,h=0,oncolor=[255,0,0],offcolor=[75,0,0],text="button"):
		self.rc = CRect(l,b+h,l+w,b)
		self.oncolor = oncolor
		self.offcolor = offcolor
		self.text = text
		self.state = 0
		self.over = 0
		self.fmouse = 0
	def SetState(self,s):
		self.state=s
	def GetState(self):
		return self.state
	def Draw(self):
		drawFrame(self.rc.L,self.rc.T,self.rc.Width(),self.rc.Height())

		glColor3f(0.0,0.0,0.0)
		glBegin(GL_LINE_LOOP)
		glVertex2d(self.rc.L,self.rc.T)
		glVertex2d(self.rc.R,self.rc.T)
		glVertex2d(self.rc.R,self.rc.B)
		glVertex2d(self.rc.L,self.rc.B)
		glEnd()	
		glShadeModel(GL_SMOOTH)
		glColor3f(1,1,1)
		
		glBegin(GL_QUADS)
		glColor3f(0,0,0)
		glVertex2d(self.rc.L+5,self.rc.T-15)
		glVertex2d(self.rc.R-5,self.rc.T-15)
		if self.state == 1:
			clr = self.oncolor
		elif self.over==1:
			clr = self.offcolor
		else:
			clr = [0,0,0]
		glColor3f(clr[0]/255.0,clr[1]/255.0,clr[2]/255.0)
		glVertex2d(self.rc.R-5,self.rc.T-10)
		glVertex2d(self.rc.L+5,self.rc.T-10)
		glEnd()
		glBegin(GL_QUADS)
		if self.state == 1:
			clr = self.oncolor
		elif self.over==1:
			clr = self.offcolor
		else:
			clr = [0,0,0]
		glColor3f(clr[0]/255.0,clr[1]/255.0,clr[2]/255.0)
		glVertex2d(self.rc.L+5,self.rc.T-10)	
		glVertex2d(self.rc.R-5,self.rc.T-10)
		glColor3f(1,1,1)
		glVertex2d(self.rc.R-5,self.rc.T-5)
		glVertex2d(self.rc.L+5,self.rc.T-5)
		glEnd()
		glShadeModel(GL_FLAT)
		if self.over==1:
			glColor3f(0.3,0.3,0.3)
		else:
			glColor3f(0,0,0)
		ctr = self.rc.Center()
		glRasterPos2d(ctr[0]-(len(self.text)*3),self.rc.B+5)
		Text(self.text)	
		
	def HitTest(self,x,y):
		return self.rc.PtInRect(x,y)
	
	def OnMouseMove(self,dx,dy,buttons):
		""" Mouse Move Rutine for this control."""	
		rtn = 0
		
		if self.HitTest(dx,dy)==0:
			self.over=0
			return rtn
		rtn=1	
		if (buttons[0] == 1):	# Left Button Down
			if self.fmouse==0:
				self.SetState(not self.GetState())
				self.fmouse==1
				rtn = 2
		elif (buttons[0] == 0):	# Left Button Up
			self.fmouse = 0
			self.over=1			
		elif (buttons[1]==1):	# Middle Button Down
			rtn = 0
		elif (buttons[2]==1):	# Right Button Down
			rtn = 0
		Draw()
		
		
		return rtn
		
# --------------------------------------------------------------
# 
# Class CVScrollList
# 
# -------------------------------------------------------------
class CVScrollLst:
	"Vertical Scroll List class"
	def __init__(self,l=0,b=0,w=0,h=0,clr = [0.0,0.0,1.0]):
		self.selidx = -1
		self.topline = 0
		self.datalst = []
		self.color = [clr[0],clr[1],clr[2]]
		self.wndrc = CRect(l,b+h,l+w,b)
		self.fmouse = 0
	def SetPos(self,l,b,w,h):
		self.wndrc.SetRect(l,b+h,l+w,b)
	def ClearLst(self):
		del self.datalst
		self.datalst = []
	def AddItem(self,s,tag=""):
		self.datalst.append([s,tag])
	def DelItem(self,idx):
		del self.datalst[idx]
		if self.selidx==idx:	self.selidx=-1
	def Sort(self):
		self.datalst.sort()
	def GetSelected(self):
		if (self.selidx>-1):	return self.datalst[self.selidx]
		else:	return None
	def Draw(self):
		glPushAttrib(GL_LIGHTING_BIT|GL_ENABLE_BIT|GL_DEPTH_BUFFER_BIT|GL_COLOR_BUFFER_BIT)
		glColor3f(0.75,0.75,0.75)
		glRectf(self.wndrc.L,self.wndrc.T,self.wndrc.R,self.wndrc.B)
		glColor3f(0.0,0.0,0.0)
		glBegin(GL_LINE_LOOP)
		glVertex2d(self.wndrc.L,self.wndrc.T)
		glVertex2d(self.wndrc.R,self.wndrc.T)
		glVertex2d(self.wndrc.R,self.wndrc.B)
		glVertex2d(self.wndrc.L,self.wndrc.B)
		glEnd()	
		glLineWidth(2.0)
		glColor3f(1.0,1.0,1.0)
		glBegin(GL_LINE_STRIP)
		glVertex2d(self.wndrc.L+2,self.wndrc.B+2)
		glVertex2d(self.wndrc.L+2,self.wndrc.T-2)
		glVertex2d(self.wndrc.R-2,self.wndrc.T-2)
		glEnd()
		glColor3f(0.45,0.45,0.45)
		glBegin(GL_LINE_STRIP)
		glVertex2d(self.wndrc.L+2,self.wndrc.B+2)
		glVertex2d(self.wndrc.R-2,self.wndrc.B+2)
		glVertex2d(self.wndrc.R-2,self.wndrc.T-2)
		glEnd()
		glColor3f(0.55,0.55,0.55)
		glRectd(self.wndrc.L+5,self.wndrc.T-5,self.wndrc.R-27,self.wndrc.B+5)
		# Draw Items
		sz = len(self.datalst)
		max = self.wndrc.Height()/15
		strmax = self.wndrc.Width()/8
		for i in range(max):
			if self.selidx==i+self.topline:
				glColor3f(self.color[0],self.color[1],self.color[2])
				glRectf(self.wndrc.L+7,self.wndrc.T-5-(i*15),self.wndrc.R-30,self.wndrc.T-(i*15)-20)
				glColor3d(1,1,1)
			else:
				glColor3d(0,0,0)
			glRasterPos2d(self.wndrc.L+7,self.wndrc.T-(i*15)-15)
			try:
				msg = self.datalst[i+self.topline][0]
				if len(msg)>strmax:	msg = msg[0:strmax]
				Text(msg)
			except:
				pass
		#Draw Handle
		if sz==0:	sz=1
		glColor3f(0.75,0.75,0.75)
		glRectf(self.wndrc.R-27,self.wndrc.T-5,self.wndrc.R-25,self.wndrc.B+5)
		glColor3f(0.55,0.55,0.55)
		glRectd(self.wndrc.R-25,self.wndrc.T-5,self.wndrc.R-5,self.wndrc.B+5)
		if sz<max:	l = 1.0
		else:	l = float(max)/float(sz)
		glColor3f(self.color[0],self.color[1],self.color[2])
		hand = int(float(self.wndrc.Height())*l)
		k = int((float(self.wndrc.Height())/float(sz))*self.topline)
		glRectd(self.wndrc.R-22,self.wndrc.T-(5+k),self.wndrc.R-7,self.wndrc.T-(hand+k))
		del i,l,sz,max,strmax
		glPopAttrib()

	def HitTest(self,x,y):
		return self.wndrc.PtInRect(x,y)

	def OnMouseMove(self,dx,dy,buttons):
		""" Mouse Move Rutine for this control."""	
		rtn = 0
		if self.HitTest(dx,dy)==0:	return
		if (buttons[0] == 1):	# Left Button Down
			# if handle was hit
			sz = len(self.datalst)
			max = self.wndrc.Height()/15
			if (dx>=self.wndrc.R-27) and (dx<=self.wndrc.R-5) and (dy>=self.wndrc.B+5) and (dy<=self.wndrc.T-5):
				if (sz>max) and ((self.fmouse == 0) or (self.fmouse == 1)):
					self.topline = int(float(self.wndrc.T-dy)/float(self.wndrc.Height())*float(sz))
					if self.topline>sz-max:	self.topline = sz-max
					self.fmouse = 1
			elif (dy>=self.wndrc.B+5) and (dy<=self.wndrc.T-5):
				if (self.fmouse == 0) or (self.fmouse ==2):
					nidx = int(float(self.wndrc.T-dy)/float(self.wndrc.Height()-8)*float(max))
					if nidx>max-1:	nidx = max-1
					self.selidx=self.topline+ nidx
					rtn=1
					self.fmouse = 2
		elif (buttons[0] == 0):	# Left Button Up
			self.fmouse = 0
		elif (buttons[1]==1):	# Middle Button Down
			pass
		elif (buttons[2]==1):	# Right Button Down
			pass
		Draw()

		return rtn
	
# --------------------------------------------------------------
# 
# Class CColorPicker
# 
# -------------------------------------------------------------	
def rgb2hsb(r,g,b):
	fr = r/255.0
	fg = g/255.0
	fb = b/255.0
	lst = [fr,fg,fb]
	lst.sort()
	max=lst[2]
	min=lst[0]
	del lst
	d = max-min
	l = (max+min)/2.0
	if (min==max):
		s = 0.0
		h = 0.0
	else:
		if l<0.5:	s = d/(max+min)
		else:	s = d/(2.0-d)
		if fr == max:	h = (fg-fb)/d
		if fg == max:	h = 2.0+(fb-fr)/d
		if fb == max:	h = 4.0+(fr-fg)/d
		h = h*60
		if h<0:	h+=360.0	
	hsb = [int(h),int(s*100),int(l*100)]
	return hsb
	
def hsb2rgb(h,s,l):
	rgb=[0,0,0]
	if s>0:
		fl = float(l)/100.0
		fs = float(s)/100.0
		fh = float(h)/360.0
		temp2 = 0
		if fl<0.5:	temp2 = fl*(1.0+fs)
		else:	temp2 = fl+fs - fl*fs
	
		temp1 = 2.0*fl - temp2

	
		temp3=[0,0,0]
		temp3[0] = fh+0.33333333
		temp3[1] = fh
		temp3[2] = fh-0.33333333
		for i in [0,1,2]:
			if temp3[i]<0.0:	temp3[i] = temp3[i]+1.0
			if temp3[i]>1.0:	temp3[i] = temp3[i]-1.0	

		for i in [0,1,2]:
			if ((6.0*temp3[i])<1):	rgb[i]= temp1+(temp2-temp1)*6.0*temp3[i]
			elif ((2.0*temp3[i])<1):	rgb[i]= temp2
			elif ((3.0*temp3[i])<2):	rgb[i]= temp1+(temp2-temp1)*(0.66666667-temp3[i])*6.0
			else:	rgb[i] = temp1
			rgb[i]=int(rgb[i]*255.0)
	else:
		r = l*255.0/100.0
		rgb = [int(r),int(r),int(r)]
	return rgb	
	
class CColorPicker:
	"Color Picker class"
	def __init__(self,l=0,b=0,w=0,h=0,clr = [0.0,0.0,1.0]):
		self.rgb = [0,0,0]
		self.hsl = [0,0,0]
		self.wndrc = CRect(l,b+h,l+w,b)
		self.fmouse = 0
		self.hueclr = [0,0,0]
		self.huehnd = CGHandle(0,0,0,0,5,5)
		self.huehnd.SetType(1)		
		self.huehnd.MoveTo(l+w/2,b+h)			
		self.boxhnd = CGHandle(0,0,0,0,5,5)
		self.boxhnd.SetType(1)
		x = w/2
		y = h/2
		t = b+h
		r = l+w
		self.colorbox =  CRect(l+x/2,t-y/2,r-x/2,b+y/2)
		self.nullbox = CRect(l-10+x/2,t+10-y/2,r+10-x/2,b-10+y/2)
	def SetPos(self,l,b,w,h):
		self.wndrc.SetRect(l,b+h,l+w,b)
	def setRGB(self,r,g,b):
		self.rgb = [r,g,b]
		self.hsl = rgb2hsb(r,g,b)
		x,y = self.colorbox.Center()
		p = Rot(x/2+20,0,self.hsl[0]+90)
		self.huehnd.MoveTo(x+p[0],y+p[1])	
		p = [int(self.hsl[1]/100.0*self.colorbox.Width()),int(self.hsl[2]/100.0*self.colorbox.Height())]
		self.boxhnd.MoveTo(self.colorbox.L+p[0],self.colorbox.B+3+(p[1]*2))	
		self.hueclr = hsb2rgb(self.hsl[0],100,50)
	def refresh(self):
		self.hueclr = hsb2rgb(self.hsl[0],100,50)
	def setHSL(self,h,s,l):
		self.rgb = hsb2rgb(h,s,l)
		self.hsl = [h,s,l]
		x,y = self.colorbox.Center()
		p = Rot(x/2+20,0,h+90)
		self.huehnd.MoveTo(x+p[0],y+p[1])	
		p = [int(s/100.0*self.colorbox.Width()),int(l/100.0*self.colorbox.Height())]
		self.boxhnd.MoveTo(self.colorbox.L+p[0],self.colorbox.B+3+(p[1]*2))	
	def getRGB(self):
		return [self.rgb[0],self.rgb[1],self.rgb[2]]
	def getHSL(self):
		return [self.hsl[0],self.hsl[1],self.hsl[2]]
	def Draw(self):
		glPushAttrib(GL_LIGHTING_BIT|GL_ENABLE_BIT|GL_DEPTH_BUFFER_BIT|GL_COLOR_BUFFER_BIT)
		
		glShadeModel(GL_SMOOTH)
		w = self.wndrc.Width()
		h = self.wndrc.Height()
		x,y = self.colorbox.Center()
		
		factor = 8
		x1 = self.wndrc.R
		x2 = self.wndrc.L
		dx = 0 
		dy = 0 

		glBegin(GL_QUADS)
		glColor3d(1,0,0)
		glVertex2d(x,self.wndrc.T-dy)
		glColor3f(1,1,0)
		glVertex2d(x2,self.wndrc.T-dy)		
		glColor3f(1,1,0)
		glVertex2d(x,y)	
		glColor3f(1,0,0)
		glVertex2d(x,y)	
		glEnd()
		
		glBegin(GL_QUADS)
		glColor3d(1,1,0)
		glVertex2d(x2,self.wndrc.T-dy)		
		glColor3f(0,1,0)
		glVertex2d(x2,self.wndrc.B+dy)	
		glColor3f(1,1,0)
		glVertex2d(x,y)	
		glColor3f(1,1,0)
		glVertex2d(x,y)	
		glEnd()
		
		glBegin(GL_QUADS)
		glColor3d(0,1,0)
		glVertex2d(x2,self.wndrc.B+dy)	
		glColor3f(0,1,1)
		glVertex2d(x,self.wndrc.B+dy)	
		glColor3f(0,1,1)
		glVertex2d(x,y)	
		glColor3f(0,1,0)
		glVertex2d(x,y)	
		glEnd()
							
		glBegin(GL_QUADS)
		glColor3d(0,1,1)
		glVertex2d(x,self.wndrc.B+dy)	
		glColor3f(0,0,1)
		glVertex2d(x1,self.wndrc.B+dy)	
		glColor3f(0,1,1)
		glVertex2d(x,y)	
		glColor3f(0,1,1)
		glVertex2d(x,y)	
		glEnd()
		
		glBegin(GL_QUADS)
		glColor3d(0,0,1)
		glVertex2d(x1,self.wndrc.B+dy)	
		glColor3f(1,0,1)
		glVertex2d(x1,self.wndrc.T-dy)	
		glColor3f(0,0,1)
		glVertex2d(x,y)	
		glColor3f(0,0,1)
		glVertex2d(x,y)	
		glEnd()
		
		glBegin(GL_QUADS)
		glColor3d(1,0,1)
		glVertex2d(x1,self.wndrc.T-dy)	
		glColor3f(1,0,0)
		glVertex2d(x,self.wndrc.T-dy)	
		glColor3f(1,0,0)
		glVertex2d(x,y)	
		glColor3f(1,0,1)
		glVertex2d(x,y)	
		glEnd()
		
		glBegin(GL_QUADS)
		glColor3f(0.75,0.75,0.75)
		glVertex2d(self.colorbox.L-2,self.colorbox.T+2)
		glVertex2d(self.colorbox.R+2,self.colorbox.T+2)
		glVertex2d(self.colorbox.R+2,self.colorbox.B-2)
		glVertex2d(self.colorbox.L-2,self.colorbox.B-2)
		glEnd()	

	
		glBegin(GL_TRIANGLES)
		glColor3f(1,1,1)
		glVertex2d(self.colorbox.L,self.colorbox.T)
		glColor3f(self.hueclr[0]/510.0,self.hueclr[1]/510.0,self.hueclr[2]/510.0)
		glVertex2d(x,y)
		glColor3f(0,0,0)
		glVertex2d(self.colorbox.L,self.colorbox.B)
		glColor3f(1,1,1)
		glVertex2d(self.colorbox.L,self.colorbox.T)
		glColor3f(self.hueclr[0]/510.0,self.hueclr[1]/510.0,self.hueclr[2]/510.0)
		glVertex2d(x,y)
		glColor3f(self.hueclr[0]/255.0,self.hueclr[1]/255.0,self.hueclr[2]/255.0)
		glVertex2d(self.colorbox.R,self.colorbox.T)
		glVertex2d(self.colorbox.R,self.colorbox.T)
		glColor3f(self.hueclr[0]/510.0,self.hueclr[1]/510.0,self.hueclr[2]/510.0)
		glVertex2d(x,y)
		glColor3f(0,0,0)
		glVertex2d(self.colorbox.R,self.colorbox.B)
		glVertex2d(self.colorbox.L,self.colorbox.B)
		glVertex2d(self.colorbox.R,self.colorbox.B)
		glColor3f(self.hueclr[0]/510.0,self.hueclr[1]/510.0,self.hueclr[2]/510.0)
		glVertex2d(x,y)
		glEnd()	
		
		glLineWidth(1.0)
		
		self.huehnd.Draw()			
		self.boxhnd.Draw()
	
		glPopAttrib()

	def HitTest(self,x,y):
		return self.wndrc.PtInRect(x,y)

	def OnMouseMove(self,dx,dy,buttons):
		""" Mouse Move Rutine for this control."""	
		rtn = 0
		if self.HitTest(dx,dy)==0:	return
		if (buttons[0] == 1):	# Left Button Down
			if (self.colorbox.PtInRect(dx,dy)):
				self.setHSL(self.hsl[0],((dx-self.colorbox.L)/self.colorbox.Width())*100,((dy - self.colorbox.B)/(self.colorbox.Height()<<1))*100)
				rtn = 1
			elif (self.nullbox.PtInRect(dx,dy)): 
				pass
			else:
				x,y = self.colorbox.Center()
				v = Vector([dy-y,dx-x])
				angle = (360 - atan2(v[1],v[0])*180.0/pi)%360
				self.setHSL(angle,self.hsl[1],self.hsl[2])
				self.refresh()
				rtn = 1
			self.Draw()
		elif (buttons[0] == 0):	# Left Button Up
			self.fmouse = 0
		elif (buttons[1]==1):	# Middle Button Down
			pass
		elif (buttons[2]==1):	# Right Button Down
			pass
		Draw()
		

		return rtn
		
# --------------------------------------------------------------
# 
# Class CPickPalette
# 
# -------------------------------------------------------------
class CPickPalette:
	"Pick Palette class"
	wndrc = CRect()
	clientrc = CRect()
	palrc = CRect()
	hndlst = []
	curidx = 0
	vs = 0
	maxcolors = 0
	curHandle = None
	fmouse = 0
	visible=1
	def __init__(self,l=0,t=0,w=0,h=0,m=32):
		self.SetPos(l,t,w,h)
		self.maxcolors = m
		self.fmouse = 0
	def SetPos(self,l,t,w,h):
		px = l - self.wndrc.L
		py = t - self.wndrc.T
		self.wndrc.SetRect(l,t,l+w,t-h)
		self.clientrc.SetRect(5,5,self.wndrc.Width()-5,self.wndrc.Height()-5)
		self.vs = float(self.clientrc.Height())/3.0 
		self.palrc.SetRect(self.wndrc.L+5,self.wndrc.T-5-self.vs,self.wndrc.R-5,self.wndrc.B+5+self.vs)
		for hnd in self.hndlst:
			hnd.rc.OffsetRect(px,py)
		del px,py
	def SetMaxColors(self,m):
		self.mascolors = m
	def Draw(self):
		if self.visible == 0:	return
		glColor3f(0.75,0.75,0.75)
		glBegin(GL_QUADS)
		glVertex2d(self.wndrc.L,self.wndrc.T)
		glVertex2d(self.wndrc.R,self.wndrc.T)
		glVertex2d(self.wndrc.R,self.wndrc.B)
		glVertex2d(self.wndrc.L,self.wndrc.B)
		glEnd()
		glColor3f(0.0,0.0,0.0)
		glBegin(GL_LINE_LOOP)
		glVertex2d(self.wndrc.L,self.wndrc.T)
		glVertex2d(self.wndrc.R,self.wndrc.T)
		glVertex2d(self.wndrc.R,self.wndrc.B)
		glVertex2d(self.wndrc.L,self.wndrc.B)
		glEnd()	
		glLineWidth(2.0)
		glColor3f(1.0,1.0,1.0)
		glBegin(GL_LINE_STRIP)
		glVertex2d(self.wndrc.L+2,self.wndrc.B+2)
		glVertex2d(self.wndrc.L+2,self.wndrc.T-2)
		glVertex2d(self.wndrc.R-2,self.wndrc.T-2)
		glEnd()
		glColor3f(0.45,0.45,0.45)
		glBegin(GL_LINE_STRIP)
		glVertex2d(self.wndrc.L+2,self.wndrc.B+2)
		glVertex2d(self.wndrc.R-2,self.wndrc.B+2)
		glVertex2d(self.wndrc.R-2,self.wndrc.T-2)
		glEnd()
		glLineWidth(1.0)
		glBegin(GL_LINES)
		for i in range(self.clientrc.R-5):
			c = float(i)/float(self.clientrc.R-5)
			glColor3f(c,c,c)
			glVertex2d(self.wndrc.L+5+i,self.wndrc.B+5+self.vs)
			glVertex2d(self.wndrc.L+5+i,self.wndrc.T-5-self.vs)
		glEnd()
		sz = len(self.hndlst)
		if (sz>0):
			c = (self.clientrc.R-5)/sz
			i = 0		
			for hnd in self.hndlst:
				hnd.Draw()
				glColor3f(hnd.intensity,hnd.intensity,hnd.intensity)
				glBegin(GL_QUADS)
				glVertex2d(self.wndrc.L+5+(i*c),self.wndrc.T-5)
				glVertex2d(self.wndrc.L+5+(i*c)+c,self.wndrc.T-5)
				glVertex2d(self.wndrc.L+5+(i*c)+c,self.wndrc.T-6-self.vs)
				glVertex2d(self.wndrc.L+5+(i*c),self.wndrc.T-6-self.vs)
				glEnd()
				i+=1
		del i,c,sz	
	
	def HitTest(self,x,y):
		return self.wndrc.PtInRect(x,y)

	def PaletteHitTest(self,x,y):
		""" Return None if HitTest over the palette of colors fail
		or the created Handle where the user clicks the mouse."""
		if (self.palrc.PtInRect(x,y)):
			if self.curidx<self.maxcolors:
				i =float(x-self.palrc.L)/float(self.clientrc.R)
				py = self.wndrc.B + (self.vs/2)+5
				self.curidx+=1
				return CGHandle(i,self.curidx,x-3,py+8,x+3,py-8)
			else:	return None
		else:
			return None

	def GetIntensityAt(self,x):
		return float(x-self.palrc.L)/float(self.clientrc.R)

	def HandlerAreaHitTest(self,x,y):
		"""Return 1 if point inside Handler Area, 0 if otherwise"""
		rc = CRect(self.palrc.L,self.palrc.T,self.palrc.R,self.palrc.B)
		rc.OffsetRect(0,-self.vs)
		i = rc.PtInRect(x,y)
		del rc
	 	return i		

	def GetIntenLst(self):
		lst = []
		for h in self.hndlst:	lst.append(h.intensity)
		return lst

	def SetLstfromInten(self,l):
		self.ResetContent()
		self.maxcolors= len(l) 
		delta = self.palrc.Width()
		gPalette.curidx=0
		for i in l:
			px = gPalette.palrc.L+ (delta*i)
			py = gPalette.wndrc.B + (gPalette.vs/2)+5	
			gPalette.curidx+=1
			w = CGHandle(i,gPalette.curidx,px-3,py+8,px+3,py-8)
			gPalette.AddHandle(w)
			del w
		del i,delta
	
	def AddHandle(self,hnd):
		if len(self.hndlst)<self.maxcolors:	self.hndlst.append(hnd)
		return 

	def RemoveHandle(self,hnd):
		i = -1
		for j in range(len(self.hndlst)):
			h = self.hndlst[j]
			if h.id==hnd.id:	i = j
			elif h.id>hnd.id:	h.id-=1
		del self.hndlst[i]
		self.curidx-=1	

	def HndLstHitTest(self,x,y):
		for hnd in self.hndlst:
			if (hnd.rc.PtInRect(x,y)):	return hnd
		return None

	def ResetContent(self):
		for hnd in self.hndlst:
			c = hnd
			hnd = None
			del c
		self.hndlst = []
		self.curidx = 0

	def GetNumColors(self):
		return len(self.hndlst)
		
	def Visible(self,val=1):
		self.visible = val
	
	def OnMouseMove(self,dx,dy,buttons):
		""" Mouse Move Rutine for this control."""
		if self.visible == 0:	return 0	
		rtn = 0
		if self.HitTest(dx,dy)==0:	return
		ViewPort = Buffer(GL_FLOAT,4)
		glGetFloatv(GL_VIEWPORT,ViewPort)

		if (buttons[0]):	# Left Button Down
			self.fmouse = 1
			if self.curHandle!=None:
				#Move handle
				if (self.HandlerAreaHitTest(dx,dy)):
					self.curHandle.MoveTo(dx,dy)
			else:
				# Create a new handle
				hnd = self.PaletteHitTest(dx,dy)
				if (hnd != None): 
					w = CGHandle(hnd.intensity,hnd.id,hnd.rc.L,hnd.rc.T,hnd.rc.R,hnd.rc.B)
					w.SetType(1)
					self.AddHandle(w)
					del w,hnd
				else:
					# Select handle
					self.curHandle=self.HndLstHitTest(dx,dy)
		elif (buttons[0] == 0) and (self.fmouse ==1):	# Left Button Up
			if self.curHandle!=None:
				i = self.GetIntensityAt(dx)
				self.curHandle.SetIntensity(self.GetIntensityAt(dx))
				self.curHandle = None
				rtn = 1
			self.fmouse = 0
		elif (buttons[1]==1):	# Middle Button Down
			pass
		elif (buttons[2]==1):	# Right Button Down
			# Select handle
			self.curHandle=self.HndLstHitTest(dx,dy)
			if self.curHandle:	self.fmouse = 2
	
		elif (buttons[2]==0):	#Right Button Up
			if self.curHandle!=None and (self.fmouse == 2):
				if Blender.Draw.PupMenu("Delete?%t|Yes%x1|No%x0"):
					#Delete handle
					self.RemoveHandle(self.curHandle)
					self.curHandle=None
			self.fmouse = 0
		Draw()
		del ViewPort

		return rtn

# ---------------------------------------------------------------
#
#	Event Definitions
#
# ---------------------------------------------------------------	
EVENT_NONE = 0
EVENT_WIDTH  = 1
EVENT_HEIGHT = 2
EVENT_ASPX   = 3
EVENT_ASPY   = 4
EVENT_CHANGE_MASK = 5
EVENT_LINE_W = 6
EVENT_TOON_LINES=7
EVENT_LINES = 8	
EVENT_RENDER_TYPE = 9
EVENT_PIXELATE=10
EVENT_LEVEL=11
EVENT_SILHOUETTE = 12
EVENT_COLOR = 13
EVENT_STARTFRAME = 14
EVENT_ENDFRAME = 15
EVENT_STEPFRAME = 16
EVENT_CREATE_SWF = 23
EVENT_CREATE_BMP = 24 
EVENT_FILENAME =25
EVENT_MASK = 26
EVENT_REFRESH=27
EVENT_QUIT= 28
EVENT_LOOP=29
EVENT_QLTY=30
EVENT_FPS=31
EVENT_PREVIEW=32
EVENT_CREATE_TIF=33
EVENT_ADD_ITEM = 37
EVENT_DEL_ITEM = 38
EVENT_REMOVE_ALL = 39
EVENT_ADD_ALL = 40
EVENT_GET_FILE = 41
EVENT_PATHNAME = 42
EVENT_SEQUENCE_SWF = 43
EVENT_BROWSE = 44
EVENT_SEQ_FLAG = 45
EVENT_NUM_SEQ_F = 46
EVENT_PARAMS = 47
EVENT_RESETFRAMES = 48
EVENT_VEC_PREVIEW = 49
EVENT_VEC_TYPE = 50
EVENT_TOLERANCE = 51
EVENT_SHADOW = 52
EVENT_LAMP_SHADOW = 53
EVENT_COMPRESS_FLAG = 54
EVENT_MATERIAL_LINES = 55
EVENT_FLARE = 56
EVENT_OK = 57
EVENT_CANCEL = 58
EVENT_LINE_MIN_DISTANCE = 59
EVENT_STROKES = 60
EVENT_INCREMENT = 61
EVENT_DECREMENT = 62
EVENT_NOISE = 63
EVENT_SPACING = 64
EVENT_BRUSH_TYPE = 65

# -------------------------------------------------------------
#
# Constants
#
# -------------------------------------------------------------
SMALL = 0.000001

# -------------------------------------------------------------
#
# Common functions
#
# -------------------------------------------------------------
def sgn(n):	
	if (n>=0):	return 1
	else:	return -1
def sgn0(n):
	if (n>SMALL):	return 1
	elif (n<SMALL):	return -1
	else:	return 0.0

# -------------------------------------------------------------
#
# _Plane class
# 
# -------------------------------------------------------------
class _Plane:
	"""Class _Plane
	   	A plane P is defined by the equation Ax+By+Cz+D = 0
		where A,B,C are the coordinates of the normal vector
		of the plane and D is the distance of the plane to 
		the origin."""
	def __init__(self,_vn = [0,0,0],_d=0,_pts = []):	
		self.d = _d	
		self.vn =  Vector(_vn)
		self.pts = _pts
	def set(self,v):
		if (len(v)==4):	
			self.d = v[-1]
			self.vn = Vector(v[0:3])
		else: print "Error:The vector should be of type [A,B,C,D]"
	def solve(self,v):
		return (DotVecs(self.vn,Vector(v)))+self.d
	def set_d_from_pt(self,p):
		""" Calculate the parameter D of the plane with a given
			point p = [x,y,z] that lies in the surface of the plane.""" 
		self.d = -1 * DotVecs(self.vn,Vector(p))
	def set_from_face(self,f):
		"""	Calculate the normal vector of the plane with the
			vertices from a given polygon.
			face: Polygon face [[x0,y0,z0],[x1,y1,z1],...[xn,yn,zn]]"""
		if (len(f)<3):
			print "Error:The polygon face should have at least 3 points."	
		else:
			self.pts = []
			for i in f:	self.pts.append(i)
			p = Vector([f[1][0]-f[0][0],f[1][1]-f[0][1],f[1][2]-f[0][2]])
			q = Vector([f[2][0]-f[0][0],f[2][1]-f[0][1],f[2][2]-f[0][2]])
			self.vn = CrossVecs(p,q)
			self.vn.normalize()
			self.set_d_from_pt(f[0])
			return _Plane([self.vn.x,self.vn.y,self.vn.z],self.d,self.pts)
	def normalize(self):
		"Normalized plane."
		m = 0.0
		for i in self.vn:
			m = i*i
		m = sqrt(m)			
		self.vn.normalize()
		if (m==0):	self.d = 0
		else:	self.d = self.d/m
		return
	def intersect_line(self,line):
		"""
		Parameters:
				line:  Line ray [P,Q]; P = initial point, Q = end point
				Ray in vector representation: P' = P + t * D
				P' = point in line, t = float number, D = Direction vector of the line ray
		Return values:
				[[x,y,z],t] The point where the plane and the line intersect
	 						and the distance from the origin of the line to the intersection point.
				None - 	if they don't intersect.
		"""
		# Obtain Direction of line (D = ray direction)
		D = Vector([line[1][0]-line[0][0],line[1][1]-line[0][1],line[1][2]-line[0][2]])
		D.normalize()
		# Obtain the Normal vector of the plane
		norm = self.vn
		norm.normalize()
		denom = DotVecs(norm,D)
		if (denom==0): return None
		# Obtain a point in the plane
		if float(norm[2]) == 0:
			if float(norm[0]) == 0:
				if float(norm[1]) == 0:
					p = line[1]
				else:
					p = [0,-self.d/norm[1],0]
			else:
				p = [-self.d/norm[0],0,0]
		else:
			p = [0,0,-self.d/norm[2]]
		# Find distance to collision point
		t = DotVecs(norm,Vector([p[0]-line[0][0],p[1]-line[0][1],p[2]-line[0][2]]))
		t/=denom
		# Return P'
		return  [[(D[0]*t)+line[0][0],(D[1]*t)+line[0][1],(D[2]*t)+line[0][2]],t]
	
	def intersect_plane(self,pl):
		"""Return:
			[Xo,D]	The line where the two planes intersect in 
					vector representation 
					L = Xo + t * D	Xo = Point in the line [x,y,z]
									D = Direction vector
									t = scalar
			None	If Planes are parallel	
		"""		
		# Compute intersection line L of this Plane and Plane T1
		D = CrossVecs(self.vn,pl.vn)	#Direction of the line
		# Test if planes are parallel
		if (reduce(add,D)==0):	return None
		# Compute a point in the intersected line
		if D[0]>=0:	ax = D[0]
		else:	ax = -D[0]
		if D[1]>=0:	ay = D[1]
		else:	ay = -D[1]
		if D[2]>=0:	az = D[2]
		else:	az = -D[2]
		if (ax+ay+az) < SMALL:	return None
		maxc = 0
		if (ax>ay):
			if (ax>az):	maxc =1
			else:	maxc = 3
		else:
			if (ay>az):	maxc =2
			else:	maxc = 3
		#Zero max coordinate and solve other two
		d1 = -1 * DotVecs(self.vn,Vector(self.pts[1]))
		d2 = -1 * DotVecs(pl.vn,Vector(pl.pts[1]))
		x = 0
		y = 0
		z = 0
		if maxc == 1:	# intersect with x=0
			y = (d2*self.vn[2] - d1*pl.vn[2]) / D[0]
			z = (d1*pl.vn[1] - d2*self.vn[1]) / D[0]
 		elif maxc == 2:	# intersect with y=0
			x = (d1*pl.vn[2] - d2*self.vn[2]) / D[1]
			z = (d2*self.vn[0] - d1*pl.vn[0]) / D[1]
		else:			#intersect with z=0
			x = (d2*self.vn[1] - d1*pl.vn[1]) / D[2]
			y = (d1*pl.vn[0] - d2*self.vn[0]) / D[2]
		D.normalize()
		return [[x,y,z],[D.x,D.y,D.z]] 

	def over_under_face(self,ptslst):
		u = map(sgn0,map(self.solve,ptslst))
		count=[0,0,0]	#-1,0,1	
		for item in u:
			if (item==-1):	count[0]+=1
			elif (item==0):	count[1]+=1
			else:	count[2]+=1
		sz = len(ptslst)
		if count[0]>0 and count[2]==0:	return -1		# poly at back
		elif count[2]>0 and count[0]== 0:	return 1	# poly at front
		elif count[1] == sz:	return 0	# poly on plane
		else:	return 2

	def intersect_face(self,ptslst,bsplit=1):
		"""Test if the face is intersecting this plane.
		Parameter: Polygon face [[x0,y0,z0],[x1,y1,z1],...[xn,yn,zn]]

		Return values:
			None 	- If face is on one side of the plane (Not intersection)
			[[face]]  - List containing one face (original given face) when the plane and
					  the face are coplanar (face and plane are the same plane)
			[[face],[face]] - List of two faces (original face splitted) one for the face 
					 infront of the plane and other for the face behind the plane.
		"""
		ans = self.over_under_face(ptslst)
		if (ans==-1 or ans == 1):	return None	#Face is on one side of the plane
		elif (ans == 0):	return [ptslst]		#Coplanar triangles
		else:	# Split
			#No split if flag off
			if bsplit==0:	return [ptslst]
			# Double check the intersection of faces not only planes
			#npl = _Plane().set_from_face(ptslst)
			#ans2 = npl.over_under_face(self.pts)
			#if ans2==-1 or ans2 == 1:	return None
			
			#Split 
			dv1 = map(self.solve,ptslst)
			s1 = map(sgn0,dv1)
			f1 = []
			f2 = []
			sz = len(s1)
			for idx in range(sz):
				i = idx + 1
				if i>=sz:	i = 0
				if (s1[idx]>0):	f1.append(ptslst[idx])
				elif (s1[idx]<0):	f2.append(ptslst[idx])
				else:	
					f1.append(ptslst[idx])
					f2.append(ptslst[idx])
				if s1[i]!=0 and s1[idx]!=0:
					if (s1[i]!=s1[idx]):
						k = self.intersect_line([ptslst[idx],ptslst[i]])
						f1.append(k[0])
						f2.append(k[0])
			return [f1,f2]

#p = _Plane()
#p = p. set_from_face([[0,0,0],[1,0,0],[1,1,0]])
#f = [[1,1,1],[3,1,1],[2,1,-1],[3,1,-1]]
#print p.intersect_face(f)


# --------------------------------------------------------------
# 
# Class _Frustum
# 
# -------------------------------------------------------------
class _Frustum:
	"Frustum class"
	val = []
	def calculate(self,m,p):
		"Calculate frustum bouding box."
		c =	p * m
		q =  c[3]
		self.val[0].set(q+c[0])
	#	self.val[0].normalize()
		self.val[1].set(q-c[1])
	#	self.val[1].normalize()
		self.val[2].set(q-c[0])
	#	self.val[2].normalize()		
		self.val[3].set(q+c[1])
	#	self.val[3].normalize()
		self.val[4].set(q-c[2])
	#	self.val[4].normalize()
		self.val[5].set(q+c[2])
	#	self.val[5].normalize()
	def __init__(self,model,proj):
		"Frustum is a vector of planes."	
		pl = _Plane()	# Left
		pt = _Plane()	# Top
		pr = _Plane()	# Right
		pb = _Plane()	# Bottom
		pk = _Plane()	# bacK
		pf = _Plane()	# Forward
		self.val = [pl,pt,pr,pb,pk,pf]
		self.calculate(model,proj)
	def pt_inside(self,pt):
		"""Check if a point [x,y,z] is inside the frustum.
		(1 = inside, 0 = outside)"""
		for pl in self.val:
			if (pl.solve(pt)<0): return 0
		return 1
	def sphere_inside(self,center,r):
		"""Check if a sphere with the center point at [x,y,z]
		and with a radius r, is inside the frustum. Return 1
		if is inside, 0 if not."""
		for pl in self.val:
			if (pl.solve(center)<=-r):	return 0
		return 1
	def partial_sphere_inside(self,center,r):
		"""Check if a sphere with the center point at [x,y,z]
		and with a radius r, is partial inside the frustum. 
		Return: 0 - Totally outside
				1 - Partially inside
				2 - Totally inside"""
		p = 0
		for pl in self.val:
			d = pl.solve(center)
			if (d<=-r):	return 0
			elif (d>r):	p = p + 1
		if (p == 6):	return 2
		return 1
	def box_inside(self,box):
		"""Check if a box is inside the frustum (qFrustum).
		First check if the center of the box is infront of all
		the planes, if true then return 1, if not check every corner
		to find at least one that is infront of the frustum planes,
	    if such case occurs then return 1 else 0."""
		if (self.pt_inside(box.center)==1):	return 1
		else:
			for pl in self.val:
				found = 0
				for pt in box.val:
					if (pl.solve(pt)>0):
						found = 1
						break
				if (found == 0): return 0
		return 1
	def partial_box_inside(self,box):
		"""Check if a box is partial inside the frustum (qFrustum).
			Return: 0 - Totally outside
				1 - Partially inside
				2 - Totally inside"""
		for pt in box:
			found = 0
			for pl in self.val:
				if (pl.solve(pt))>0:	found+=1
			if found>=3:	return 1
		return 0
	def partial_face_inside(self,face):
		"""Check if a face is partial inside the frustum.
			Return: 0 - Totally outside
				1 - Partially inside
				2 - Totally inside"""
		p = 0	
		sz = len(face)
		for pl in self.val:
			found = 0
			for pt in face:
				if (pl.solve(pt)>=0): found = found + 1
			if (found==0):	return 0
			if (found == sz): p = p + 1
		if (p == 6):	return 2
		return 1

# ---------------------------------------------------------------
# 	Function	: MatrixToBuffer
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def MatrixToBuffer(m):
	return Buffer(GL_FLOAT,16,[m[0][0],m[0][1],m[0][2],m[0][3],
								m[1][0],m[1][1],m[1][2],m[1][3],
								m[2][0],m[2][1],m[2][2],m[2][3],
								m[3][0],m[3][1],m[3][2],m[3][3]])

# ---------------------------------------------------------------
# 	Function	: Perspective
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def Perspective(fovy, aspect, near,far):
	top = near * tan(fovy * pi / 360.0)
	bottom = -top
	left = bottom*aspect
	right= top*aspect
	x = (2.0 * near) / (right-left)
	y = (2.0 * near) / (top-bottom)
	a = (right+left) / (right-left)
	b = (top+bottom) / (top - bottom)
	c = - ((far+near) / (far-near))
	d = - ((2*far*near)/(far-near))
	return Matrix([x,0.0,a,0.0],[0.0,y,b,0.0],[0.0,0.0,c,d],[0.0,0.0,-1.0,0.0])
		
# ---------------------------------------------------------------
# 	Function	f: Ortho
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------			
def Ortho(fovy, aspect ,near,far,scale):
	top = near * tan(fovy * pi / 360.0) * (scale * 10)
	bottom = -top 
	left = bottom * aspect
	right= top * aspect
	rl = right-left
	tb = top-bottom
	fn = near-far 
	tx = -((right+left)/rl)
	ty = -((top+bottom)/tb)
	tz = ((far+near)/fn)
	return Matrix([2.0/rl,0.0,0.0,tx],[0.0,2.0/tb,0.0,ty],[0.0,0.0,2.0/fn,tz],[0.0,0.0,0.0,1.0])
						
	
# ---------------------------------------------------------------
# 	Function	: IntersectLines
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------		
def IntersectLines(l1,l2,flag = 0):
	ua = ((l2[2]-l2[0]) * (l1[1]-l2[1])) - ((l2[3]-l2[1])*(l1[0]-l2[0]))
	ub = ((l1[2]-l1[0]) * (l1[1]-l2[1])) - ((l1[3]-l1[1])*(l1[0]-l2[0]))
	c  = ((l2[3]-l2[1]) * (l1[2]-l1[0])) - ((l2[2]-l2[0])*(l1[3]-l1[1]))
	if c==0:	return None
	if (ua==0 and ub==0 and c==0):	return [l1[0],l1[1]]
	ua/=float(c)
	ub/=float(c)
	if flag:
		if (ua<-0.01 or ua>1.01) and (ub<-0.01 or ub>1.01):
			return None
	return [int(l1[0]+((ua*(l1[2]-l1[0]))+0.5)),int(l1[1]+((ua*(l1[3]-l1[1]))+0.5))]


# ---------------------------------------------------------------
# 	Function	: InsideEdge
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def InsideEdge(pt,e):
	if ((e[2]-e[0])*(pt[1]-e[1])) < ((pt[0]-e[0])*(e[3]-e[1])):	return 1
	return -1

# ---------------------------------------------------------------
# 	Function	: EdgeClip
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def EdgeClip(inlist,edge):
	outlst = []
	if len(inlist)==2:	s = inlist[1]
	else:	s = inlist[-1]
	i=[]
	for p in inlist:
		if InsideEdge(p,edge)>0:
			if InsideEdge(s,edge)<0:
				i = IntersectLines([s[0],s[1],p[0],p[1]],edge,1)
				if i!=None and len(inlist)>2:	outlst.append((i[0],i[1],s[2]))
			outlst.append(p)
		else:
			if InsideEdge(s,edge)>0:
				i = IntersectLines([s[0],s[1],p[0],p[1]],edge,1)
				if i!=None:	outlst.append((i[0],i[1],p[2])) 
		s = p
	return outlst

# ---------------------------------------------------------------
# 	Function	:PolyClip
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def PolyClip(vertexlst,x,y,w,h):
	ClipRgnEdges = [[x,y,x,y+h],[x,y+h,x+w,y+h],[x+w,y+h,x+w,y],[x+w,y,x,y]]
	inlist = vertexlst
	for edge in ClipRgnEdges:
		if inlist==None or inlist == []:	break
		inlist = EdgeClip(inlist,edge)
	return inlist
	
# ---------------------------------------------------------------
# 	Function	: RenderWireFrame
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def RenderWireFrame(tofile):
	global gLineWidth,gGenCol
	global gMsg,gCurrentFrame,gRendering,buffImage

	sc = Blender.Scene.getCurrent()
	context = sc.getRenderingContext()
	w = context.imageSizeX()
	h = context.imageSizeY()
	ax = context.aspectRatioX()
	ay = context.aspectRatioY()
	del sc,context
		
	gRendering = 1
	
	mW = w/2
	mH = h/2
	
	# Set Current Frame
	Blender.Set('curframe',gCurrentFrame)
	Blender.Window.RedrawAll()
	# Get Scene
	sc = Blender.Scene.getCurrent()
	obList = sc.getChildren()

	if tofile:
		sh = bShape()
		sh.Reset()
		movie = []
		gMsg = "Rendering Wireframe"
		oldclr = [-1,-1,-1]
		bChgColor = 0
	else:
		glClearColor(0.0,0.0,0.3,1.0)
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
		glPolygonMode(GL_FRONT_AND_BACK,GL_FILL)
		#Draw Background
		glColor3f(gGenCol[4][0],gGenCol[4][1],gGenCol[4][2])
		glBegin(GL_POLYGON)
		glVertex2d(9,50)
		glVertex2d(w+10,50)
		glVertex2d(w+10,h+50)
		glVertex2d(9,h+50)
		glEnd()
		glPolygonMode(GL_FRONT_AND_BACK,GL_LINE)

	# Get Visible Layers
	layerslst = Blender.Window.ViewLayer()
	layerslst.reverse()
	LayerMask = 0
	for l in layerslst:	LayerMask += (2**(l-1))
	del layerslst
	# Calculate Perspective Matrix from the current camera
	obCamera = sc.getCurrentCamera()
	del sc
	cam = obCamera.getInverseMatrix()
	cam.transpose()	

	# Changing the view mode
	cmra = obCamera.getData()
 
	fovy = atan(0.5/(float(w*ax)/float(h*ay))/(cmra.lens/32))
	fovy = fovy *360/pi
	if cmra.type:
		m2 = Ortho(fovy,float(w*ax)/float(h*ay),cmra.clipStart, cmra.clipEnd,17) #cmra.scale) 
	else:
		m2 = Perspective(fovy,float(w*ax)/float(h*ay),cmra.clipStart, cmra.clipEnd) 
	del fovy,cmra
	
	#Create Frustum	
	frustum = _Frustum(cam,m2)
	m1 = Matrix()
	mP = Matrix()
	numobj = 0
	for obMesh in obList:
		if (type(obMesh.data)==NMeshType) and ((obMesh.Layer & LayerMask)>0):
			mhActual = NMesh.GetRawFromObject(obMesh.name) #GetRaw
			#Obtain the colors of the objects in this frame
			colors = []
			if len(mhActual.materials)>0:
				for colsmat in mhActual.materials:
					colors.append([colsmat.R,colsmat.G,colsmat.B,colsmat.alpha])
			else:	colors = [[0.7,0.7,0.7,1.0]]
			m1 = obMesh.matrixWorld #mat
			m1.transpose()
			mP = cam * m1
			mP = m2  * mP

			b = obMesh.getBoundBox()
			bb=[]
			for nb in b:
				nb1 = MatMultVec(m1,Vector([nb[0],nb[1],nb[2],1.0]))
				bb.append([nb1[0],nb1[1],nb1[2]])

			if (frustum.partial_box_inside(bb)>0):
				# Obtain the list of faces
				for f in mhActual.faces:
					tf = []
					t2 = [] 
					for v in f.v:
						#Transform the vertices to global coordinates
						p = MatMultVec(mP,Vector([v.co[0],v.co[1],v.co[2],1.0]))
						tf.append(p)
						p = MatMultVec(m1,Vector([v.co[0],v.co[1],v.co[2],1.0]))
						t2.append([p[0],p[1],p[2]])
						if frustum.partial_face_inside(t2):
							iu = []	
							for p in tf:
								# Create Point
								if p[3]<=0:
									x = int(p[0]*mW)+mW
									y = int(p[1]*mH)+mH
								else:
									x = int((p[0]/p[3])*mW)+mW
									y = int((p[1]/p[3])*mH)+mH
								iu.append([x,y,0])
									
							#clipping
							iu = PolyClip(iu,0.0,0.0,w,h)	
							if len(iu)>0:
								if not tofile:
									glLineWidth(gLineWidth.val)
									glColor3f(colors[f.mat][0],colors[f.mat][1],colors[f.mat][2])	
									glBegin(GL_LINE_LOOP)
									for i in iu:	glVertex2d(i[0]+10,i[1]+50)
									glEnd()
								else:
									# ------------------------------------------------------------- SWF Begin
									clr = [int(colors[f.mat][0]*255),int(colors[f.mat][1]*255),int(colors[f.mat][2]*255),int(colors[f.mat][3]*255)]
									bChgColor = 0
									if (oldclr[0]!=clr[0] or oldclr[1]!=clr[1] or oldclr[2]!=clr[2] or oldclr[3]!=clr[3] ):
										_fsa = FILLSTYLEARRAY([FILLSTYLE(SOLID_FILL,[0,0,0,255])])
										_lsa = LINESTYLEARRAY([LINESTYLE(1,[clr[0],clr[1],clr[2],255])])
										oldclr = [clr[0],clr[1],clr[2],clr[3]]
										sh.SetStyleRecord(SH_MOVE+SH_LINESTYLE+SH_NEWSTYLES,iu[0][0],h-iu[0][1],0,0,1,1,1,_fsa,_lsa)
									else:	
										sh.MoveTo(iu[0][0],(h-iu[0][1]))
									for k in range(len(iu)):
										i = k+1
										if i>=len(iu): i = 0
										sh.LineTo(iu[i][0]-iu[k][0],(h-iu[i][1])-(h-iu[k][1]))
									# ------------------------------------------------------------- SWF End
							del iu
					del tf
		numobj+=1

	del LayerMask

	if tofile:
		# ------------------------------------------------------------- SWF Begin
		sh.EndShape()
		movie = sh.GetShape()
		gPercentage = 0.0
		del sh
		Draw()
		gRendering = 0
		return movie
		# ------------------------------------------------------------- SWF End
	else:
		glPolygonMode(GL_FRONT_AND_BACK,GL_FILL)
		glLineWidth(1.0)
		if buffImage==None:	
			buffImage = Buffer(GL_BYTE,w*h*3)
		# Viewpoint data
		ViewData = Buffer(GL_INT,4)
		glGetIntegerv(GL_VIEWPORT,ViewData)
		glReadBuffer(GL_BACK)
		glReadPixels(ViewData[0]+11,ViewData[1]+50,w-1,h,GL_RGB,GL_UNSIGNED_BYTE,buffImage)
		gRendering = 0
		return 0


def GetNeighboards(faces):
	dic = {}
	for fi in range(len(faces)):
		f = faces[fi]
		for iv in range(len(f.v)):
			i1 = f.v[iv].index
			i2 = f.v[iv-1].index
			if (i1,i2) in dic:
				dic[(i1,i2)].append(fi)
			elif (i2,i1) in dic:
				dic[(i2,i1)].append(fi)
			else:
				dic[(i1,i2)] = [fi]
	return dic
	
def GetSilhouettes(eye,faces,mat,invmat,neigh,cl,ch):
	global	gbLines,gbMaterial
	
	sil_lines = {}
	mat_lines = {}
	shp_lines = {}

	for fi in range(len(faces)):
		f = faces[fi]
		n = f.no
		n =Vector([n[0],n[1],n[2],1.0])
		n = MatMultVec(invmat,n)
		n.normalize()
	
		mverts= []
		for iv in range(len(f.v)):
			pt1 = f.v[iv]
			vtx1 = MatMultVec(mat,Vector([pt1[0],pt1[1],pt1[2],1.0]))
			mverts.append([vtx1[0],vtx1[1],vtx1[2]])

		D = -1 * DotVecs(n,Vector([mverts[0][0],mverts[0][1],mverts[0][2],1.0]))
		visibility = DotVecs(n,Vector([eye[0],eye[1],eye[2],1.0]))+D
			
		if 	(visibility>0):
			for iv in range(len(f.v)):
				v1 = f.v[iv-1].index
				v2 = f.v[iv].index
				
				lstneigh = None
				key = None
				if (v1,v2) in neigh:	key=(v1,v2)
				elif (v2,v1) in neigh:	key = (v2,v1)
				lstneigh = neigh[key]
		
				foundmat = 0
				foundshp = 0	
				if len(lstneigh)>1:
					if lstneigh[0]==fi:	neighface	= lstneigh[1]
					else:	neighface = lstneigh[0]
					
					if (gbMaterial.val>0):	
						if f.materialIndex <> faces[neighface].materialIndex:
							if ((v1,v2) in mat_lines) or ((v2,v1) in mat_lines):
								pass
							else:
								mat_lines[(v1,v2)] = [mverts[iv-1],mverts[iv]]
								foundmat=1
	
					if (gbLines.val>0):
						angle = AngleBetweenVecs(Vector(f.no),Vector(faces[neighface].no))
						if (angle>cl) and (angle<ch):	
							if ((v1,v2) in shp_lines) or ((v2,v1) in shp_lines):
								pass
							else:
								shp_lines[(v1,v2)] = [mverts[iv-1],mverts[iv]]
								foundshp = 1
				# Silhouette Lines	
				if (v1,v2) in sil_lines:	sil_lines[(v1,v2)]=None
				elif (v2,v1) in sil_lines:	sil_lines[(v2,v1)]=None
				else:
					if (foundshp or foundmat):
						pass
					else:	
						sil_lines[(v1,v2)] = [mverts[iv-1],mverts[iv]]
					
	return mat_lines,shp_lines,sil_lines		

# ---------------------------------------------------------------
# 	Function	: DrawObjects
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def DrawObjects(tofile):
	global gRenderType,	buffImage,framebuff,gEnableMask,gCurrentFrame
	global gFX, gFXType,gLevel,gRendering
	global gLineWidth,gbLines,gbSilhouette,gbMaterial,gSilWidth,gMatWidth
	global gGenCol,gPalette,gDoubleSided
	global gShadow,gSilhouette,gFlare,gFlareObjName,gFlareLoc
	global gColors,gVertexLst,gLineRegions,gColordic
	global gStrokes, gIncrement, gDecrement, gNoise, gSpacing, gBrush

	framebuff = []
	gRendering = 1
	try:
		del gLineRegions
	except:
		pass
	gLineRegions = []
	
	# Set Current Frame
	Blender.Set('curframe',gCurrentFrame)
	Blender.Window.RedrawAll()
	#Get Current Scene
	sc = Blender.Scene.getCurrent()
	# Get Visible Layers
	layerslst = Blender.Window.ViewLayer()
	layerslst.reverse()
	LayerMask = 0
	for l in layerslst:	LayerMask += (2**(l-1))
	del layerslst
	# Get Current camera
	obCamera = sc.getCurrentCamera()
	cmra = obCamera.getData()
	obList = sc.getChildren()
	context = sc.getRenderingContext()
	gW = context.imageSizeX()
	gH = context.imageSizeY()
	gAspX = context.aspectRatioX()
	gAspY = context.aspectRatioY()
	del sc,context

	# Calculate Perspective Matrix from the current camera
	cam = obCamera.getInverseMatrix()
	cam.transpose()	
	fovy = atan(0.5/(float(gW*gAspX)/float(gH*gAspY))/(cmra.lens/32))
	fovy = fovy *360/pi
	if cmra.type:
		m3 = Ortho(fovy,float(gW*gAspX)/float(gH*gAspY),cmra.clipStart, cmra.clipEnd,17) #cmra.scale) 
	else:
		m3 = Perspective(fovy,float(gW*gAspX)/float(gH*gAspY),cmra.clipStart, cmra.clipEnd) 
	# Create Frustum
	frustum = _Frustum(cam,m3)
	LampLst = []
	#Get all lamps positions
	for obj in obList:
		if (obj.getType()=="Lamp"):
			lmp = obj.getData()
			flags = lmp.getMode()
			shdw = 0
			if ((flags & 0x1)<>0):	shdw=1
			loc = obj.loc
			LampLst.append([loc[0],loc[1],loc[2],shdw,lmp.getClipEnd()]) 
			del lmp,loc,shdw,flags
		
	numcolors = 64/gPalette.GetNumColors()
	m = 64 % gPalette.GetNumColors()
	vMaskColors = []
	for hnd in gPalette.hndlst:
		r = [hnd.intensity]
		r *= numcolors 
		vMaskColors.extend(r)
		del r
	if (m>0):
		idx = len(vMaskColors)-1
		r = [vMaskColors[idx-1]] * m
		vMaskColors.extend(r)
		del r,idx
	del hnd

	glPushAttrib(GL_LIGHTING_BIT|GL_ENABLE_BIT|GL_DEPTH_BUFFER_BIT|GL_COLOR_BUFFER_BIT)
	glDisable(GL_SCISSOR_TEST)
	glClearColor(0.0,0.0,0.3,1.0)
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
	glEnable(GL_SCISSOR_TEST)

	if gEnableMask.val and 	tofile>0:
		glColor3f(gGenCol[6][0],gGenCol[6][1],gGenCol[6][2])
	else:
		#Draw Background
		glColor3f(gGenCol[4][0],gGenCol[4][1],gGenCol[4][2])
	
	glBegin(GL_POLYGON)
	glVertex2d(9,50)
	glVertex2d(gW+10,50)
	glVertex2d(gW+10,gH+50)
	glVertex2d(9,gH+50)
	glEnd()

	Viewport = Buffer(GL_INT, 4)
	glGetIntegerv(GL_VIEWPORT, Viewport)
	glViewport(Viewport[0]+10, Viewport[1]+50, gW, gH)

	glEnable(GL_DEPTH_TEST)
	glDisable(GL_LIGHTING)
	glShadeModel(GL_FLAT)
	glDrawBuffer(GL_BACK)

	glMatrixMode(GL_MODELVIEW)
	glPushMatrix()
	glMatrixMode(GL_PROJECTION)
	glPushMatrix()
	glLoadIdentity()
	if cmra.type:
		m3 = Ortho(fovy,float(gW*gAspX)/float(gH*gAspY),cmra.clipStart, cmra.clipEnd,17) #cmra.scale) 
	else:
		m3 = Perspective(fovy,float(gW*gAspX)/float(gH*gAspY), cmra.clipStart, cmra.clipEnd) 
	del cmra,fovy

	m3.transpose()
	proj = MatrixToBuffer(m3)
	glMultMatrixf(proj)
	cam = MatrixToBuffer(obCamera.getInverseMatrix())
	glMultMatrixf(cam)

	glMatrixMode(GL_MODELVIEW)
	glLoadIdentity()

	glPolygonMode(GL_FRONT,GL_FILL)
	if (gRenderType.val>=2):
		glDisable(GL_TEXTURE_2D)
		glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_REPEAT)
		glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_T, GL_REPEAT)
		glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
		glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
		glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE, GL_DECAL)

	width = gW
	height = gH
	bsz = width*height*3
	if buffImage==None:	
		buffImage = Buffer(GL_BYTE,bsz)
	buffback = Buffer(GL_BYTE,bsz)
	buff2     = Buffer(GL_BYTE,bsz,[0]*bsz)
	del bsz
		
	gBmpTexture =  Buffer(GL_BYTE,32*3)
	gTextBits=[0]*32
	if (gRenderType.val>3) and (gRenderType.val<7):
		gTextBits = [1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0]

	w3 = width * 3
	j3 = height*w3
	bj3 = j3-w3


	dictfilter={}
	dictfilter[(0,0,0)]=1
	dictfilter[(255,255,255)]=1
	# __________________________________________________
	# Add Background, lines, silhouette, and mask colors
	# __________________________________________________
	for i in [0,1,2,3,4]:
		ir = int(gGenCol[i][0]*255)
		ig = int(gGenCol[1][1]*255)
		ib = int(gGenCol[1][2]*255)
		if  (ir,ig,ib) in dictfilter:
			pass
		else:
			dictfilter[(ir,ig,ib)]=1
	ObjLst = []
	shadowlines = []
	gSilhouette=[]
	numobj = 0
	for obj in obList:
		if (type(obj.data)==NMeshType) and ((obj.Layer & LayerMask)>0):
			m1 = obj.matrixWorld
			m1.transpose()
			# ------------------------------------------------
			# Set Object Bounding Box
			# ------------------------------------------------
			Box = []
			b = obj.getBoundBox()
			bb=[]
			for nb in b:
				nb1 = MatMultVec(m1,Vector([nb[0],nb[1],nb[2],1.0]))
				bb.append([nb1[0],nb1[1],nb1[2]])
			Box.extend(bb)
			
			m1.transpose()
			m2 = CopyMat(m1)
			m2.transpose()
		
			if (frustum.partial_box_inside(Box)<1) :
				ObjLst.append(0)
			else:
				ObjLst.append(1)
				# ------------------------------------------------
				# Set Mesh
				# ------------------------------------------------
				Mesh = NMesh.GetRawFromObject(obj.name) 
				glPushMatrix()
				mat = MatrixToBuffer(m1)
				glMultMatrixf(mat)
				invmat = obj.getInverseMatrix()
				colors = []
				#Obtain the colors of the objects in this frame
				if len(Mesh.materials)>0:
					for colsmat in Mesh.materials:
						colors.append([colsmat.R,colsmat.G,colsmat.B,colsmat.alpha])
				else:	colors = [[0.7,0.7,0.7,1.0]]

				#Change the colors of the textures 
				textures = []
				for clr in colors:
					tones = []
					for t in range(64):
						ir = int((clr[0]*vMaskColors[t])*255)
						ig = int((clr[1]*vMaskColors[t])*255)
						ib = int((clr[2]*vMaskColors[t])*255)
						if  (ir,ig,ib) in dictfilter:
							pass
						else:
							dictfilter[(ir,ig,ib)]=1
						tones.append(int((clr[0]*vMaskColors[t])*255))
						tones.append(int((clr[1]*vMaskColors[t])*255))
						tones.append(int((clr[2]*vMaskColors[t])*255))
					textures.append(tones)
					del tones
				glLineWidth(1.0)	
	
				if gDoubleSided.val == 0:	glEnable(GL_CULL_FACE)
				
				lampedgedic = {}
				capnear =[]
				capfar = []
			
				if (gbSilhouette.val>0) or (gbLines.val>0) or (gbMaterial.val>0):
					neighboards = GetNeighboards(Mesh.faces)
					matlines, shplines,sillines = GetSilhouettes(obCamera.loc,Mesh.faces,m2,invmat,neighboards,45,360)
					gSilhouette.append([numobj,[sillines,shplines,matlines]])
					matlines,shplines,sillines = None,None,None
					del matlines,shplines,sillines
			
				for face in Mesh.faces:
					n = face.no
					n =Vector([n[0],n[1],n[2],1.0])
					n = MatMultVec(invmat,n)
					n.normalize()
					
					glEnable(GL_CULL_FACE)
					glCullFace(GL_BACK)
					if gDoubleSided.val == 1:	glDisable(GL_CULL_FACE)
					
					clr = colors[face.materialIndex]
					if (gRenderType.val==2) or (gRenderType.val==3):
						texbuff = Buffer(GL_BYTE, 64*3,textures[face.materialIndex])
						glDisable(GL_TEXTURE_1D)
						glTexImage1D(GL_TEXTURE_1D, 0, GL_RGB, 64, 0, GL_RGB, GL_UNSIGNED_BYTE, texbuff)
						glEnable(GL_TEXTURE_1D)
					elif (gRenderType.val>3):
						r1,g1,b1 = int(gGenCol[2][0]*255),int(gGenCol[2][1]*255),int(gGenCol[2][2]*255)
						r2,g2,b2 = int(clr[0]*255),int(clr[1]*255),int(clr[2]*255)
						j,i = 0,0
						for i in range(0,32*3,3):
							if gTextBits[j]:	
								gBmpTexture[i]=r1
								gBmpTexture[i+1]=g1
								gBmpTexture[i+2]=b1
							else:
								gBmpTexture[i]=r2
								gBmpTexture[i+1]=g2
								gBmpTexture[i+2]=b2
							j+=1
						del i,j,r1,g1,b1,r2,b2,g2
						params=[]
						if (gRenderType.val==4):	params=Buffer(GL_FLOAT,4,[1.0,0.0,0.0,0.0])
						elif (gRenderType.val==5):	params=Buffer(GL_FLOAT,4,[0.0,1.0,0.0,0.0])
						elif (gRenderType.val==6):	params=Buffer(GL_FLOAT,4,[0.0,0.0,1.0,0.0])
						glDisable(GL_TEXTURE_1D)
						glTexImage1D(GL_TEXTURE_1D, 0, GL_RGB, 32, 0, GL_RGB, GL_UNSIGNED_BYTE, gBmpTexture)
						glEnable(GL_TEXTURE_1D)
						glTexGeni(GL_S,GL_TEXTURE_GEN_MODE,GL_OBJECT_LINEAR)
						glTexGenfv(GL_S,GL_OBJECT_PLANE,params)
						glTexGeni(GL_T,GL_TEXTURE_GEN_MODE,GL_EYE_LINEAR)
						glTexGenfv(GL_T,GL_EYE_PLANE,params)
						glEnable(GL_TEXTURE_GEN_S)
					
						del params
					elif (gRenderType.val>-1) :
						glColor3f(clr[0],clr[1],clr[2])
					glPolygonMode(GL_FRONT,GL_FILL)
				
	
					mverts= []
					for iv in range(len(face.v)):
						pt1 = face.v[iv]
						vtx1 = MatMultVec(m2,Vector([pt1[0],pt1[1],pt1[2],1.0]))
						mverts.append([vtx1[0],vtx1[1],vtx1[2]])

					D = -1 * DotVecs(n,Vector([mverts[0][0],mverts[0][1],mverts[0][2],1.0]))
						
					#Create the Shadow Volume for the lamps that cast shadows
					if (len(LampLst)>0) and (gShadow.val>0):
						numlamp=0
						for lamp in LampLst:
							numlamp+=1
							if lamp[3]==0:	continue	#Skip lamps that don't cast shadows
							infinity=lamp[4]					#Lamp's Clip End
							visibility = DotVecs(n,Vector([lamp[0],lamp[1],lamp[2],1.0]))+D
							if visibility>0:
								_cn=[]	# Near Cap
								_cf=[] 	# Far Cap
								for iv in range(len(face.v)):
									# Find silhuette shadow
									v1 = face.v[iv-1].index
									v2 = face.v[iv].index
									if (numlamp,v1,v2) in lampedgedic:	lampedgedic[(numlamp,v1,v2)]=None
									elif (numlamp,v2,v1) in lampedgedic:	lampedgedic[(numlamp,v2,v1)]=None
									else:
										_v1 = Vector([mverts[iv-1][0]-lamp[0],mverts[iv-1][1]-lamp[1],mverts[iv-1][2]-lamp[2],1.0])
										_v1.normalize()
										_v2 = Vector([mverts[iv][0]-lamp[0],mverts[iv][1]-lamp[1],mverts[iv][2]-lamp[2],1.0])
										_v2.normalize()
										lampedgedic[(numlamp,v1,v2)] = [[mverts[iv][0],mverts[iv][1],mverts[iv][2]],
																					   [mverts[iv-1][0],mverts[iv-1][1],mverts[iv-1][2]],
																						 [mverts[iv-1][0]+(_v1[0]*infinity),mverts[iv-1][1]+(_v1[1]*infinity),mverts[iv-1][2]+(_v1[2]*infinity)],
							 															 [mverts[iv][0]+(_v2[0]*infinity),mverts[iv][1]+(_v2[1]*infinity),mverts[iv][2]+(_v2[2]*infinity)]]
									# Find Caps
									_v2 = Vector([mverts[iv][0]-lamp[0],mverts[iv][1]-lamp[1],mverts[iv][2]-lamp[2],1.0])
									_v2.normalize()
									_cn.append([mverts[iv][0]+(_v2[0]*0.001),mverts[iv][1]+(_v2[1]*0.001),mverts[iv][2]+(_v2[2]*0.001)])
									_cf.append([mverts[iv][0]+(_v2[0]*infinity),mverts[iv][1]+(_v2[1]*infinity),mverts[iv][2]+(_v2[2]*infinity)])
					
								_cf.reverse()
								capnear.append([numlamp,_cn])
								capfar.append([numlamp,_cf])	
								
										
														
					if gRenderType.val==2 or gRenderType.val>3:
						p1 = face.v[0]
						p1 = MatMultVec(m2,Vector([p1[0],p1[1],p1[2],1.0]))
						na = 0.0
						if len(LampLst)>0:
							# Obtain the Light Vector (Vertex to light source)
							for lamploc in LampLst:
								vLight =  Vector([lamploc[0]-p1[0],lamploc[1]-p1[1],lamploc[2]-p1[2],1.0])
								vLight.normalize()
								_a = DotVecs(vLight,n)
								if _a<0:	_a*=-1.0
								na+= _a
						else:
							#No lamps, so use camera position as lamp position
							vLight = Vector([obCamera.loc[0]-p1[0],obCamera.loc[1]-p1[1],obCamera.loc[2]-p1[2],1.0])
							vLight.normalize()
							na = max(DotVecs(vLight,n),0.0)
						if na>=1.0:	na = 0.99
						glBegin(GL_POLYGON)
						for v in face.v:
							glTexCoord1f(na) 
							glVertex3f(v[0], v[1], v[2])
						glEnd()	
					elif gRenderType.val==3:
						glBegin(GL_POLYGON)
						for v in face.v:
							p2 = Mesh.verts[v.index]
							p2 = MatMultVec(m2,Vector([p2[0],p2[1],p2[2],1.0]))
							n = Mesh.verts[v.index].no
							n =Vector([n[0],n[1],n[2],1.0])
							n = MatMultVec(invmat,n)
							n.normalize()
							na=0.0
							if len(LampLst)>0:
								# Obtain the Light Vector (Vertex to light source)
								for lamploc in LampLst:
									vLight =  Vector([lamploc[0]-p2[0],lamploc[1]-p2[1],lamploc[2]-p2[2],0.0])
									vLight.normalize()
									na+= (max(DotVecs(vLight,n),0.0)*1.85)
							else:
								#No lamps, so use camera position as lamp position
								vLight =   Vector([obCamera.loc[0]-p2[0],obCamera.loc[1]-p2[1],obCamera.loc[2]-p2[2],0.0])
								vLight.normalize()
								na = (max(DotVecs(vLight,n),0.0)*1.85)	
							if na>=1.0:	na = 0.99
							glTexCoord1f(na) 
							glVertex3f(v[0], v[1], v[2])
						glEnd()	
					else:
						glBegin(GL_POLYGON)
						for v in face.v:	glVertex3f(v[0], v[1], v[2])
						glEnd()	
					glDisable(GL_TEXTURE_1D)
				glPopMatrix()
				shadowlines.append([lampedgedic,capnear,capfar])
				
		numobj=numobj+1
	
	# Save image 
	glReadBuffer(GL_BACK)
	glReadPixels(Viewport[0]+11, Viewport[1]+50,width-1,height,GL_RGB,GL_UNSIGNED_BYTE,buffImage)
	glDisable(GL_TEXTURE_1D)
	
	m3.transpose()
	
	# -------------------------------------------
	# Filter
	# -------------------------------------------
	if (tofile>0):
		for j in range(w3,j3-w3,w3):
			for i in range(3,w3-3,3):
				r = buffImage[j+i]
				g = buffImage[j+i+1]
				b = buffImage[j+i+2]
				for ci in dictfilter:
					if (abs(ci[0]-r)<=8) and (abs(ci[1]-g)<=8) and (abs(ci[2]-b)<=8):
						buffImage[j+i] = ci[0]
						buffImage[j+i+1] = ci[1]
						buffImage[j+i+2] = ci[2]
						r,g,b =  ci[0], ci[1], ci[2]	
						break
		del dictfilter
										
	if (tofile>0) and gRenderType.val==2 or gRenderType.val==3: 
		for j in range(0,j3,w3):
			for i in range(0,w3,3):
				r = buffImage[j+i]
				g = buffImage[j+i+1]
				b = buffImage[j+i+2]
				gdic={}
				for j2 in [j-w3,j,j+w3]:
					for i2 in [i-3,i,i+3]:	
						try:
							ri,rg,rb = buffImage[j2+i2],buffImage[j2+i2+1],buffImage[j2+i2+2]		
							if 	(ri,rg,rb)	in gdic:
								gdic[(ri,rg,rb)]+=1
							else:
								gdic[(ri,rg,rb)]=1	
						except:
								pass
				num = gdic[(r,g,b)]			
				thekey = None	
				if num<3: 
					for key in gdic:
						if gdic[key]>=num: 
							num = gdic[key]
							thekey = key
					buff2[j+i] = thekey[0]
					buff2[j+i+1] =thekey[1]
					buff2[j+i+2] =thekey[2]		
				else:
					buff2[j+i] = r
					buff2[j+i+1] =g
					buff2[j+i+2] =b		 
		for j in range(0,j3,w3):
			for i in range(0,w3,3):
				buffImage[j+i] = buff2[j+i]
				buffImage[j+i+1] =buff2[j+i+1]
				buffImage[j+i+2]=buff2[j+i+2]	
	
				
	
									
	# -------------------------------------------
	# Set Flare obj
	# -------------------------------------------	
	if gFlare.val>0:
		gFlareLoc = [0,0]			
		for obj in obList:				
			if obj.name == gFlareObjName:
				cam =  obCamera.getInverseMatrix()
				cam.transpose()
				m1 = obj.matrixWorld 
				m1.transpose()
				mJ = cam * m1
				mJ = m3  * mJ
				mW = width>>1
				mH = height>>1
				p1 = MatMultVec(mJ,Vector([obj.loc[0],obj.loc[1],obj.loc[2],1.0]))
				px = (((p1[0]/p1[3])*mW)-0.5)+mW
				py = (((p1[1]/p1[3])*mH)-0.5)+mH
				gFlareLoc = [int(px),int(py)]
				del mJ,cam,mW,mH,p1,px,py
				break

		
	EDGE_OFFSET = 0.0001		
	# -------------------------------------------
	# Create black silhouette
	# -------------------------------------------		
	glEnable(GL_CULL_FACE)
	glEnable(GL_DEPTH_TEST)
	glCullFace(GL_BACK)
	glColor3f(0,0,0)
	if gRenderType.val>-1:
		numobj = 0
		for obj in obList:
			if (type(obj.data)==NMeshType) and ((obj.Layer & LayerMask)>0):
				glPushMatrix()
				mat = MatrixToBuffer(obj.matrixWorld)
				Mesh = NMesh.GetRawFromObject(obj.name) 
				glMultMatrixf(mat)
				for face in Mesh.faces:
					glBegin(GL_POLYGON)
					for v in face.v:
						glVertex3f(v[0], v[1], v[2])
					glEnd()		
				glPopMatrix()
			numobj+=1					

	glReadBuffer(GL_BACK)
	glReadPixels(Viewport[0]+11, Viewport[1]+50,width-1,height,GL_RGB,GL_UNSIGNED_BYTE,buffback)
	# Store black 
	gColordic[(0,0,0,255)]=0
	gColors.append([0,0,0,255])
	framebuff.append(buffback)	
	del buffback
	
	
	# Store color regions
	framebuff.append(buffImage)	
	
	# -------------------------------------------
	# Create Silhouettes, Lines, Material Lines
	# -------------------------------------------	
	
	if (gbSilhouette.val>0) or (gbLines.val>0) or (gbMaterial.val>0):
		glClearColor(1.0,1.0,1.0,1.0)
		glClear(GL_COLOR_BUFFER_BIT)
		glDepthRange(0.0,1.0-EDGE_OFFSET)
		glLineWidth(4.0)
		colorsil = 0
		for objmesh in gSilhouette:
			for dic in objmesh[1]:
				for key in dic:
					i = dic[key]
					if i<>None:
						colorsil+=16
						r = (colorsil>>16)
						g = ((colorsil>>8)&0xff)
						b = (colorsil&0xff)
						glColor3f(r/255.0, g/255.0, b/255.0)	
						glBegin(GL_LINES)
						glVertex3f(i[0][0],i[0][1],i[0][2])
						glVertex3f(i[1][0],i[1][1],i[1][2])
						glEnd()
		
		glLineWidth(1.0)
		glReadPixels(Viewport[0]+11, Viewport[1]+50,width-1,height,GL_RGB,GL_UNSIGNED_BYTE,buff2)	
		
		glDepthRange(0.0,1.0)
		
		mP = Matrix()
		cam =  obCamera.getInverseMatrix()
		cam.transpose()
		mP = m3 * cam
		mW = width>>1
		mH = height>>1
		fw = 10.0/float(width)
		fh = 100.0/float(height)
				
		colorsil =0
		numobj=0
		for objmesh in gSilhouette:
			matlines = [[],[],[]]
			linetype = -1	
			quad = [[None]*100,[None]*100,[None]*100]
			for dic in objmesh[1]:
				linetype+=1			
				for key in dic:
					i = dic[key]
					if i<>None:
						colorsil+=16
						hr,hg,hb = (colorsil>>16),((colorsil>>8)&0xff),(colorsil&0xff)
						iu = []
						glColor3f(hr/255.0, hg/255.0, hb/255.0)	
						p1 = MatMultVec(mP,Vector([i[0][0],i[0][1],i[0][2],1.0]))
						px = (((p1[0]/p1[3])*mW))+mW
						py = (((p1[1]/p1[3])*mH))+mH
						iu.append([px,py,0])
						p2 = MatMultVec(mP,Vector([i[1][0],i[1][1],i[1][2],1.0]))
						px = (((p2[0]/p2[3])*mW))+mW
						py = (((p2[1]/p2[3])*mH))+mH
						iu.append([px,py,0])
						#clipping
						iu = PolyClip(iu,0.0,0.0,float(width),float(height))
						if len(iu)>0:			
							vn = Vector([iu[1][0]-iu[0][0],iu[1][1]-iu[0][1]])
							d = int(sqrt((vn[0]*vn[0])+(vn[1]*vn[1])))
							edge1 = None
							edge2 = None
							if (d>3):
								d=d+1
								vn.normalize()						
								sflag = 0				
								edge1 = None
								edge2 = None
								for step in range(0,d):
									x = int(iu[0][0])+int(vn[0]*step)
									y = int(iu[0][1])+int(vn[1]*step)
									if (x>1) and (x<width-1) and (y>1) and (y<height-1):
										found = 0
										for px in [x-1,x,x+1]:
											for py in [y-1,y,y+1]:
												idx = (w3*py)+(px*3)
												ri,gi,bi = buff2[idx],buff2[idx+1],buff2[idx+2]
												if (ri==hr and gi==hg and bi==hb):
													found = 1
													break
											if found:	break
										if found:
											if sflag == 0:								
												edge1 = [int(x),int(y)]			
												sflag = 1
											else:
												edge2 = [int(x),int(y)]		
										else:
											sflag = 0
											if edge1<>None and edge2<>None and (not((edge1[0]==edge2[0]) and (edge1[1]==edge2[1]))):
												id = len(matlines[linetype])
							
												qidx = min(99,int((edge1[1]*fh) + (edge1[0]*fw)))
												if quad[linetype][qidx] == None:	quad[linetype][qidx] = [id]
												elif id not in quad[linetype][qidx]:	quad[linetype][qidx].append(id)
						
												qidx = min(99,int((edge2[1]*fh) + (edge2[0]*fw)))
												if quad[linetype][qidx] == None:	quad[linetype][qidx] = [id]
												elif id not in quad[linetype][qidx]:	quad[linetype][qidx].append(id)
						
												matlines[linetype].append([[edge1[0],edge1[1],edge2[0],edge2[1]],[-1,99],0])
												
											edge1=None
											edge2=None
							else:
								found = 0
								for point in iu:
									x = int(point[0])
									y = int(point[1])
									if (x>1) and (x<width-1) and (y>1) and (y<height-1):
										for px in [x-1,x,x+1]:
											for py in [y-1,y,y+1]:
												idx = (w3*py)+(px*3)
												ri,gi,bi = buff2[idx],buff2[idx+1],buff2[idx+2]
												if (ri==hr and gi==hg and bi==hb):
													found = found + 1
													break
								if found>2:
									edge1 = [int(iu[0][0]),int(iu[0][1])]						
									edge2 = [int(iu[1][0]),int(iu[1][1])]						
															
							if edge1<>None and edge2<>None and (not((edge1[0]==edge2[0]) and (edge1[1]==edge2[1]))):
								id = len(matlines[linetype])
	
								qidx = min(99,int((edge1[1]*fh) + (edge1[0]*fw)))
								if quad[linetype][qidx] == None:	quad[linetype][qidx] = [id]
								elif id not in quad[linetype][qidx]:	quad[linetype][qidx].append(id)
							
								qidx = min(99,int((edge2[1]*fh) + (edge2[0]*fw)))
								if quad[linetype][qidx] == None:	quad[linetype][qidx] = [id]
								elif id not in quad[linetype][qidx]:	quad[linetype][qidx].append(id)			
																					#   segment, id neighboard, angle neighboard, flag
								matlines[linetype].append([[edge1[0],edge1[1],edge2[0],edge2[1]],[-1,99],0])
							
			#Link segments  
			linetype = 0
			for m in matlines:
				for idx in range(len(m)):
					e1 = m[idx][0]
					#Get posible match
					qidx = min(99,int((e1[3]*fh) + (e1[2]*fw)))
					pmatch = []
					if quad[linetype][qidx]<>None:	pmatch.extend(quad[linetype][qidx])
					if qidx>1 and quad[linetype][qidx-1]<>None:	pmatch.extend(quad[linetype][qidx-1])
					if qidx<99 and quad[linetype][qidx+1]<>None:	pmatch.extend(quad[linetype][qidx+1])
					if qidx>9 and quad[linetype][qidx-10]<>None: 	pmatch.extend(quad[linetype][qidx-10])
					if qidx<89 and quad[linetype][qidx+10]<>None: 	pmatch.extend(quad[linetype][qidx+10])	
					box = [e1[2]-2,e1[3]+3,e1[2]+2,e1[3]-3]
										
					for idx2 in pmatch:
						if idx2<>idx:
							e2 = m[idx2][0]
							v1 = Vector([e1[2]-e1[0],e1[3]-e1[1]])
							v2 = Vector([e2[2]-e2[0],e2[3]-e2[1]])
							angle = int(AngleBetweenVecs(v1,v2))
							if angle<135:
								if (e2[0]>=box[0]) and (e2[0]<=box[2]) and (e2[1]>=box[3]) and (e2[1]<=box[1]):
									if m[idx][1][0] <> idx2:
										if angle<m[idx][1][1]:
											m[idx][1][0] = idx2
											m[idx][1][1] = angle
											x = (e1[2]+e2[0])>>1
											y = (e1[3]+e2[1])>>1
											e1[2] = x
											e1[3] = y
											e2[0] = x
											e2[1] = y	
				linetype+=1
			del quad,linetype
														
			# Store colors					
			idx=[0,0,0,0]
			for i in range(3):
				r,g,b = int(gGenCol[i][0]*255),int(gGenCol[i][1]*255),int(gGenCol[i][2]*255)
				if (r,g,b,255) in gColordic:
					idx[i] = gColordic[(r,g,b,255)]
				else:	
					idx[i] = len(gColordic)	
					gColordic[(r,g,b,255)] = idx[i]
					gColors.append([r,g,b,255])	

				
			# Store points
			numx = 0
			numidx = 0
			for linetype in matlines:				
				numx-=1	
				for segment in linetype:
					if segment[2]==0:
						edge = segment[0]
						idvec = len(gVertexLst)
						gVertexLst.append([[edge[0],edge[1]],idx[numidx],9,-1,-1])   #Xi
						gVertexLst.append([[edge[2],edge[3]],idx[numidx],9,-1,-1])  		#Xf 	
						lstpts = [idvec,idvec+1]	
						nextedge = segment[1][0]
						segment[2] = 1
						while (nextedge<>-1 and linetype[nextedge][2]	== 0) :
							p1 = [edge[2],edge[3]]
							edge= linetype[nextedge][0]
							p2 = [edge[0],edge[1]]
							idvec = len(gVertexLst)
							d = int(dist(p1,p2))
							if d<=3:
								p1 = [(p1[0]+p2[0])>>1,(p1[1]+p2[1])>>1]
								gVertexLst[-1][0] = [p1[0],p1[1]]
							else:				
								gVertexLst.append([[edge[0],edge[1]],idx[numidx],9,-1,-1])   #Xi
								lstpts.append(idvec)
								idvec = idvec + 1						
							gVertexLst.append([[edge[2],edge[3]],idx[numidx],9,-1,-1])  		#Xf 								
							lstpts.append(idvec)
							linetype[nextedge][2]	= 1
							nextedge = linetype[nextedge][1][0]	
						
						if len(lstpts)==2:
							p1 = gVertexLst[lstpts[0]][0]
							p2 = gVertexLst[lstpts[1]][0]
							#d = int(dist(p1,p2))
							#if d>5:	
							gLineRegions.append([[numobj,numx],lstpts])
						else:
							lstpts = curve_aprox(lstpts,0) # Curve Optimization	
							gLineRegions.append([[numobj,numx],lstpts])	
																
				numidx+=1
			del numx,numidx
			del idx
			
			numobj = numobj + 1  			
	# -------------------------------------------
	# Create Shadows
	# -------------------------------------------	
	if (gShadow.val>0):
		glClearColor(1.0,1.0,1.0,1.0)
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
		glEnable(GL_CULL_FACE)
		glCullFace(GL_BACK)
		glColor3f(1,1,1)
		if gRenderType.val>-1:
			numobj = 0
			for obj in obList:
				if (type(obj.data)==NMeshType) and ((obj.Layer & LayerMask)>0):
					glPushMatrix()
					mat = MatrixToBuffer(obj.matrixWorld)
					Mesh = NMesh.GetRawFromObject(obj.name) 
					glMultMatrixf(mat)
					for face in Mesh.faces:
						glBegin(GL_POLYGON)
						for v in face.v:
							glVertex3f(v[0], v[1], v[2])
						glEnd()		
					glPopMatrix()
				numobj+=1					
		bsz = width*height*3
		numlamp=0
		# For each lamp that cast shadows do ...
		for lamp in LampLst:
			numlamp+=1
			if lamp[3]==0:	continue	#Skip lamps that don't cast shadows
			glColor3f(1,1,1)
			tempbuff= Buffer(GL_BYTE,bsz,[255]*bsz)
	 		# Clear background and foregound
			glRasterPos2d(10,50)
			glBegin(GL_QUADS)
			glVertex2d(10,50)
			glVertex2d(10+width,50)
			glVertex2d(10+width,50+height)
			glVertex2d(10,50+height)
			glEnd()
			glDrawPixels(width,height,GL_RGB,GL_UNSIGNED_BYTE,tempbuff)
			# Draw the Scene
			glEnable(GL_CULL_FACE)
			glCullFace(GL_BACK)
			
			numobj = 0
			for obj in obList:
				if (type(obj.data)==NMeshType) and ((obj.Layer & LayerMask)>0):
					if ObjLst[numobj]:
						glPushMatrix()
						mat = MatrixToBuffer(obj.matrixWorld)
						Mesh = NMesh.GetRawFromObject(obj.name) 
						glMultMatrixf(mat)
						for face in Mesh.faces:
							glBegin(GL_POLYGON)
							for v in face.v:
								glVertex3f(v[0], v[1], v[2])
							glEnd()		
						glPopMatrix()
					numobj+=1
			# Draw Shadows

			glEnable(GL_BLEND)
			glDepthMask(GL_FALSE)
			glEnable(GL_CULL_FACE)
			
			for triplet in shadowlines:
				edgelst= triplet[0]
				glCullFace(GL_BACK)
				glBlendFunc(GL_DST_COLOR,GL_ZERO)		
				glColor4f(0.5,0.5,0.5,1)
				for key in edgelst:
					if key[0] == numlamp:
						edge = edgelst[key]
						if edge<>None:
							i = edge
							glBegin(GL_QUADS)
							glVertex3f(i[0][0],i[0][1],i[0][2])
							glVertex3f(i[1][0],i[1][1],i[1][2])
							glVertex3f(i[2][0],i[2][1],i[2][2])
							glVertex3f(i[3][0],i[3][1],i[3][2])
							glEnd()
		
				for cap in triplet[1]:
					if cap[0] == numlamp:
						glBegin(GL_POLYGON)
						for i in cap[1]:
							vk = Vector([i[0]-obCamera.loc[0],i[1]-obCamera.loc[1],i[2]-obCamera.loc[2]])
							vk.normalize()
							vk *=2 
							glVertex3f(i[0]+vk[0],i[1]+vk[1],i[2]+vk[2])
						glEnd()
				for cap in triplet[2]:
					if cap[0] == numlamp:
		 				glBegin(GL_POLYGON)
						for i in cap[1]:
							glVertex3f(i[0],i[1],i[2])
						glEnd()		
				
				glCullFace(GL_FRONT)
				glBlendFunc(GL_DST_COLOR,GL_ONE)
				glColor4f(1,1,1,0.5)
				for key in edgelst:
					if key[0] == numlamp:
						edge = edgelst[key]
						if edge<>None:
							i = edge
							glBegin(GL_QUADS)
							glVertex3f(i[0][0],i[0][1],i[0][2])
							glVertex3f(i[1][0],i[1][1],i[1][2])
							glVertex3f(i[2][0],i[2][1],i[2][2])
							glVertex3f(i[3][0],i[3][1],i[3][2])
							glEnd()
				
				for cap in triplet[1]:
					if cap[0] == numlamp:
						glBegin(GL_POLYGON)
						for i in cap[1]:
							vk = Vector([i[0]-obCamera.loc[0],i[1]-obCamera.loc[1],i[2]-obCamera.loc[2]])
							vk.normalize()
							vk *=2 
							glVertex3f(i[0]+vk[0],i[1]+vk[1],i[2]+vk[2])
						glEnd()
				for cap in triplet[2]:
					if cap[0] == numlamp:
		 				glBegin(GL_POLYGON)
						for i in cap[1]:
							glVertex3f(i[0],i[1],i[2])
						glEnd()	
							
			glDepthMask(GL_TRUE)
			glDisable(GL_BLEND)
			glCullFace(GL_BACK)
			
			glReadBuffer(GL_BACK)
			glReadPixels(Viewport[0]+11, Viewport[1]+50,width-1,height,GL_RGB,GL_UNSIGNED_BYTE,tempbuff)
		
			#Binarize (W&B)	
			for j in range(0,j3,w3):
				for i in range(0,w3,3):
					if ((tempbuff[j+i]<255) or (tempbuff[j+i+1]<255) or (tempbuff[j+i+1]<255)):
						tempbuff[j+i] = int(gGenCol[5][0]*255)
						tempbuff[j+i+1] = int(gGenCol[5][1]*255)
						tempbuff[j+i+2] = int(gGenCol[5][2]*255)
						
			# Save shadow for lamp n
			framebuff.append(tempbuff)

	glPopAttrib()
	glMatrixMode(GL_PROJECTION)
	glPopMatrix()
	glMatrixMode(GL_MODELVIEW)
	glPopMatrix()
	glViewport(Viewport[0]+10, Viewport[1]+51, Viewport[2],Viewport[3])	
	
	
	# -------------------------------------------
	# FX Pixelate and voronoi
	# -------------------------------------------		
	if gFX.val:
		mr = int(gGenCol[6][0]*255.0)	# Mask color
		mg = int(gGenCol[6][1]*255.0)
		mb = int(gGenCol[6][2]*255.0)	
		kr = int(gGenCol[4][0]*255.0)	# BackColor color
		kg = int(gGenCol[4][1]*255.0)
		kb = int(gGenCol[4][2]*255.0)		
		if gFXType.val == 0:
			#__________________________________
			# Pixelate 
			#__________________________________
			l1 = width/gLevel.val
			l2 = height/gLevel.val
			lw = l2 * w3
			l3 = l1 * 3
			ll = l1 * l2
			for j in range(0,j3,lw):
				for i in range(0,w3,l3):
					r = 0
					g = 0
					b = 0
					count = 0
					for bj in range(j,j+lw,w3):
						for bi in range(i,i+l3,3):
							try:
								wr= buffImage[bj+bi] 
								wg= buffImage[bj+bi+1] 
								wb= buffImage[bj+bi+2]
								if (wr==mr) and (wg==mg) and (wb==mb):
									r+= kr
									g+= kg
									b+= kb
								else: 
									r+= wr
									g+= wg
									b+= wb
							except:
								r += 128
								g += 128
								g += 128
					r /=ll
					g /=ll
					b /=ll

					for bj in range(j,j+lw,w3):
						for bi in range(i,i+l3,3):
							try:
								buffImage[bj+bi]   = r
								buffImage[bj+bi+1] = g
								buffImage[bj+bi+2] = b 
							except:	pass
		elif gFXType.val == 1:
			#__________________________________
			# Voronoi
			#__________________________________
			if gEnableMask.val:
				r,g,b = kr,kg,kb	#Background color
			else:
				r,g,b = int(gGenCol[5][0]*255.0),int(gGenCol[5][1]*255.0),int(gGenCol[5][2]*255.0)	#Shadow color
			denom = max(gLevel.val*1.0,10.0)
			j,j1,i,i1 = 0,0,0,0
			for j in range(0,j3,w3):
				i1 = 0
				for i in range(0,w3,3):
					if (noise([i1/denom,j1/denom,0.0],NoiseTypes.VORONOI_CRACKLE)<0.5):
						buffImage[j+i]   = r
						buffImage[j+i+1] = g
						buffImage[j+i+2] = b
					i1+=1
	 			j1+=1

			del j,i,j1,i1
			
		del kr,kg,kb,mr,mb,mg
							
#	glEnable(GL_LINE_SMOOTH)
			
	# -------------------------------------------
	# Draw shadows
	# -------------------------------------------	
	if (tofile==0) and (gShadow.val>0) and (len(framebuff)>2): 
		mr = int(gGenCol[5][0]*255.0)
		mg = int(gGenCol[5][1]*255.0)
		mb = int(gGenCol[5][2]*255.0)
		for j in range(0,j3,w3):
				for i in range(0,w3,3):
					for numbuff in range(2,len(framebuff)):
						buff = framebuff[numbuff]
						if (buff[j+i]==mr) and  (buff[j+i+1]==mg) and (buff[j+i+2]==mb):
							buffImage[j+i]   = (buffImage[j+i] >> 1) + (mr >> 1)
							buffImage[j+i+1] = (buffImage[j+i+1] >> 1) + (mg >> 1)
							buffImage[j+i+2] = (buffImage[j+i+2] >> 1) + (mb >> 1)
		del mr,mg,mb
							
	# -------------------------------------------
	# Draw silhouette and lines
	# -------------------------------------------		
	if (tofile==0 or gStrokes.val) and ((gbLines.val>0) or (gbSilhouette.val>0) or (gbMaterial.val>0)):
		bsz = width*height*3
		buff2 = Buffer(GL_BYTE,bsz,[0]*bsz)
		del bsz
		glClearColor(1.0,1.0,1.0,1.0)
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

		if gStrokes.val == 0:
			flst = [0.0,0.2,0.4,0.6,0.8,1.0]
			for i in	gLineRegions:
				linedraw = 1
				if (i[0][1]==-1) and (gbSilhouette.val>0):
					glColor3f(gGenCol[3][0],gGenCol[3][1],gGenCol[3][2])
					glLineWidth(gSilWidth.val)
				elif (i[0][1] == -2) and (gbLines.val>0) :
					glColor3f(gGenCol[2][0],gGenCol[2][1],gGenCol[2][2])
					glLineWidth(gLineWidth.val)	
				elif (i[0][1] == -3) and (gbMaterial.val>0):
					glColor3f(gGenCol[1][0],gGenCol[1][1],gGenCol[1][2])
					glLineWidth(gMatWidth.val)	
				else:
					linedraw=0	
			
				if linedraw:	
					glBegin(GL_LINE_STRIP)
					for j in i[1]:
						if str(type(j))=="<type 'list'>":
							for fix in flst:
								p1 = bez3(j[0],j[1],j[2],fix)
								glVertex2d(p1[0],p1[1])	
						else:
							p1 = 	gVertexLst[j][0]
							glVertex2d(p1[0],p1[1])
					glEnd()
			del flst
			glLineWidth(1.0)	
		
		else:
			for stk in	gLineRegions:
				lst = stk[1]
				sz = len(lst)
				midsz = sz/2
				szline = 0
				
				if (stk[0][1]==-1) and (gbSilhouette.val>0):	szline=float(gSilWidth.val)
				elif (stk[0][1] == -2) and (gbLines.val>0) :	szline=float(gLineWidth.val)
				elif (stk[0][1] == -3) and (gbMaterial.val>0):	szline=float(gMatWidth.val)
				for i in range(sz-1):
					currsz = float(szline)
					perc = i/float(sz)
					if (gIncrement.val) and (gDecrement.val):
						if i< midsz:	currsz *= perc
						else:	currsz *= (1.0-perc)
					elif (gIncrement.val):	currsz *= perc
					elif (gDecrement.val):	currsz *= (1.0-perc)
					halfsz = int((currsz/2.0)+0.5)
					if halfsz<=0: halfsz=1
						
					if (str(type(lst[i]))<>"<type 'list'>"):
						p = gVertexLst[lst[i]][0]
						q = []
						if (i+1==sz):	j=i-1
						else:	j=i+1
						if (str(type(lst[j]))<>"<type 'list'>"):
							q = gVertexLst[lst[j]][0]
						else:
							q = lst[j][0]
						v = Vector([q[0]-p[0],q[1]-p[1]])
						v.normalize()
						d = int(dist(p,q))
						midsz = d/2.0	
						for j in range(0,d,gSpacing.val):
							rv =[0,0]
							if (gNoise.val):	rv = Blender.Noise.randuvec()
							dx = int(p[0]+(v[0]*j)+rv[0]*gSpacing.val)
							dy = int(p[1]+(v[1]*j)+rv[1]*gSpacing.val)
							k = 4 + stk[0][1]
							glColor3f(gGenCol[k][0],gGenCol[k][1],gGenCol[k][2])
							drawBrush(dx,dy,halfsz)
					else:
						j = lst[i]
						d = dist(j[0],j[1])	
						d += dist(j[1],j[2])
						delta =float(gSpacing.val)/d
						numdiv = int(d)/gSpacing.val
						flst = []
						for xi in range(numdiv+1):
							r = xi*delta
							if r>1.0:	r=1.0
							elif r<0:	r=0.0
							flst.append(r)
						for u in flst:
							p = bez3(j[0],j[1],j[2],u)
							q = bez3(j[0],j[1],j[2],u+delta)
							v = Vector([q[0]-p[0],q[1]-p[1]])
							v.normalize()	
							rv =[0,0]
							if (gNoise.val):	rv = Blender.Noise.randuvec()
							dx = int(p[0]+rv[0]*gSpacing.val)
							dy = int(p[1]+rv[1]*gSpacing.val)
							k = 4 + stk[0][1]
							glColor3f(gGenCol[k][0],gGenCol[k][1],gGenCol[k][2])
							drawBrush(dx,dy,halfsz)
						k = i+1
						if (k<>sz):
							p = [j[2][0],j[2][1]]
							if (str(type(lst[k]))<>"<type 'list'>"):
								q = gVertexLst[lst[k]][0]
							else:
								q = lst[k][0]	
							v = Vector([q[0]-p[0],q[1]-p[1]])
							v.normalize()
							d = int(dist(p,q))
							for j in range(0,d,gSpacing.val):
								rv =[0,0]
								if (gNoise.val):	rv = Blender.Noise.randuvec()
								dx = int(p[0]+(v[0]*j)+rv[0]*gSpacing.val)
								dy = int(p[1]+(v[1]*j)+rv[1]*gSpacing.val)
								k = 4 + stk[0][1]
								glColor3f(gGenCol[k][0],gGenCol[k][1],gGenCol[k][2])
								drawBrush(dx,dy,halfsz)
			del gLineRegions
							
		glReadPixels(Viewport[0]+11, Viewport[1]+50,width-1,height,GL_RGB,GL_UNSIGNED_BYTE,buff2)	
		for j in range(0,j3,w3):
			for i in range(0,w3,3):
				if (buff2[j+i]==255) and  (buff2[j+i+1]==255) and (buff2[j+i+2]==255):
					pass
				else:
						buffImage[j+i]   = buff2[j+i] 
						buffImage[j+i+1] = buff2[j+i+1]
						buffImage[j+i+2] = buff2[j+i+2] 
	
#	glDisable(GL_LINE_SMOOTH)			
			
	del buff2,w3,j3,bj3
	del LayerMask
	del gSilhouette
		
	gRendering = 0
	return	0			

# ---------------------------------------------------------------
# Function	: linear_aprox
#	Inputs		:
# OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def linear_aprox(lst):
	global	gVertexLst,gMinDistance

	e = 0.0; idxe = 0
		
	if ((lst[0]==lst[-1]) and len(lst)>2):
		e = 10.0
		idxe = len(lst)/2
	else:
		pi = gVertexLst[lst[0]][0]
		pf = gVertexLst[lst[-1]][0]
		v = Vector([pf[0]-pi[0],pf[1]-pi[1]])
		v.normalize()
		mv = abs((v[0]*v[0])+(v[1]*v[1]))

		for i in range(1,len(lst)-1):
			p = gVertexLst[lst[i]][0]
			u = Vector([p[0]-pi[0],p[1]-pi[1]])
			dv = DotVecs(u,v)
			if mv==0.0:	d = 0
			else:
				try:
					fat=(dv/mv)
					proyu = Vector([v[0]*fat,v[1]*fat])
					proyu = [proyu[0]+pi[0],proyu[1]+pi[1]]
					w = [p[0]-proyu[0], p[1]-proyu[1]]
					d = sqrt((w[0]*w[0])+(w[1]*w[1]))
				except:
					d = 0
			if d>=e:
				e = d
				idxe = i
	if (e<gMinDistance.val):
		return [lst[0],lst[-1]]
	else:
		if len(lst)>2:
			l1 = lst[0:idxe+1]
			l2 = lst[idxe:]
			l1 = linear_aprox(l1)
			l2 = linear_aprox(l2)
			l2 = l2[1:]
			l1.extend(l2)
			return l1
		else:	return lst
			
# ---------------------------------------------------------------
# Function	: curve_aprox
#	Inputs		:
# OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	

def curve_aprox(lst,cycle=1): 
	global	gVertexLst,gCurveMax
	sz = len(lst)
	if sz<3:	return lst
	start = 0
	end = sz
	outlst = []
	if cycle<1:
		outlst.append(lst[0])
		start = 1
		end = sz - 1
	item = 0		
	for i in range(start,end):
		p1 = gVertexLst[lst[i-1]][0]
		p2 = gVertexLst[lst[i]][0]
		if (i+1)==sz:	j = 0
		else: j = i+1
		p3 = gVertexLst[lst[j]][0]
		v1 = Vector([p1[0]-p2[0],p1[1]-p2[1]])
		v2 = Vector([p3[0]-p2[0],p3[1]-p2[1]])
		angle = int(AngleBetweenVecs(v1,v2))
		q1 = getMid(p1,p2)
		q2 = getMid(p2,p3)
		v = [q1[0]-q2[0],q1[1]-q2[1]]
		ptv = getMid(q1,q2)
		tv = Vector([ptv[0]-p2[0],ptv[1]-p2[1]])
		if (tv[0]<>0 or tv[1]<>0):	tv.normalize()
		r1 = [p2[0]+(tv[0]*1.2),p2[1]+(tv[1]*1.2)]
		L1 = [p2[0],p2[1],q1[0],q1[1]]
		L2 = [r1[0],r1[1],r1[0]+v[0],r1[1]+v[1]]
		pt1 = IntersectLines(L1,L2)
		item = lst[i]
		if pt1<>None and (str(pt1[0])<>sNAN) and  (str(pt1[1])<>sNAN):
			d1 = dist(q1,p2)
			d2 = dist(q1,pt1)
			g = d2/d1
			a = (4*g)/3
			sa = str(a)
			if sa==sNAN or sa==sINF:
				print "NaN!"
			else:	
				if a>=0.25 and a<=gCurveMax.val:
					item = [[q1[0],q1[1]],[p2[0],p2[1]],[q2[0],q2[1]]]
		outlst.append(item)
	if (cycle<1):	outlst.append(lst[-1])
	return outlst

# ---------------------------------------------------------------
# Function	: ScanImage
#	Inputs		:
# OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def ScanImage(width,height,framebuff):
	global gVertexLst,gColordic, gColors, gGenCol,gEnableMask
	mr = int(gGenCol[6][0]*255.0)	# Mask color
	mg = int(gGenCol[6][1]*255.0)
	mb = int(gGenCol[6][2]*255.0)								
	for numbuff in range(len(framebuff)):
		buff = framebuff[numbuff]	
		#__________________________________
		# Scanning image 
		#__________________________________
		rb,gb,bb=-10,-10,-10
		sz = 0
		# 			   				 0     1     2    3    4   
		# gVertexLst = ((x,y),clridx,flag,prev,next)
		r0 = []
		r1 = []
		xi= 0
		w3 = width * 3
		top = w3-3
		idx = 0
		first = 0
		xf = 0
		for j in range(0,height,1):
			flag=0
			rb,gb,bb,ab=-10,-10,-10,-10
			jw = j*w3
			for i in range(0,w3,3):
					if numbuff > 1:	# shadows
						a = 127 - numbuff
					else:						# colors
						a = 255
					r=buff[jw+i]
					g=buff[jw+i+1]
					b=buff[jw+i+2]
					if abs(r-rb)>9 or abs(g-gb)>9 or abs(b-bb)>9 or abs(a-ab)>9 or i==top or j==height-1: 
						if flag==0:	flag = 1
						else:
							if (rb,gb,bb,ab) in gColordic:
								idx = gColordic[(rb,gb,bb,ab)]
							else:	
								idx = len(gColordic)	
								gColordic[(rb,gb,bb,ab)]=idx
								gColors.append([rb,gb,bb,ab])
							if (numbuff == 1) and (rb==0 and gb==0 and bb == 0):
								pass
							elif (numbuff > 1) and (rb==255 and gb==255 and bb == 255):
								pass
							elif (gEnableMask.val) and (rb==mr and gb==mg and bb == mb):
								pass
							else:
								xf = i/3
								sz = len(gVertexLst)
								if sz<0:	sz = 0
								gVertexLst.append([[xi-0.5,j+0.5],idx,0,sz+3,sz+1]) #Xi'
								gVertexLst.append([[xi-0.5,j-0.5],idx,0,sz,sz+2])   #Xi"
								gVertexLst.append([[xf+0.5,j-0.5],idx,0,sz+1,sz+3])	#Xf'
								gVertexLst.append([[xf+0.5,j+0.5],idx,0,sz+2,sz])	#Xf"
								r1.append([[xi,j],[xf,j],sz,idx]) #(Xi,Xf,idxXi',coloridx)
							
						xi= i/3
						rb,gb,bb,ab = r,g,b,a
				
			if first == 0:
				first = 1
			else:
				for _f in r1:
					dyi = _f[0]
					dyf = _f[1]
					for _i in r0:
						# Check intersect range of pairs
						dxi = _i[0]
						dxf = _i[1]
						if (_f[3]==_i[3]): #Same color
							if (((dyi<=dxf) and (dyi>=dxi)) or ((dyf<=dxf) and (dyf>=dxi))) or (((dxi>=dyi) and (dxi<=dyf)) or ((dxf>=dyi) and (dxf<=dyf))):
								# intersection
								z0 = gVertexLst[_f[2]+2][3]
								z1 = gVertexLst[_i[2]+3][4]
								z2 = _f[2]+2
								z3 = _i[2]+3
								gVertexLst[z0][4] = z1
								gVertexLst[z1][3] = z0
								gVertexLst[z3][4] = z2
								gVertexLst[z2][3] = z3
			r0 = r1
			r1 = []
		
	del r0,r1
	del	rb,gb,bb,xi,xf,idx,sz
	del w3,top,first

	framebuff[0]=None
	for i in range(1,len(framebuff)):
		buff = framebuff[i]
		del buff
		buff = 0
	del framebuff
	framebuff = []


# ---------------------------------------------------------------
# Function	: StrokeGeneration
#	Inputs		:
# OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def StrokeGeneration(stroke):
	global gSilWidth,LineWidth,gMatWidth,gIncrement,gDecrement,gNoise
	global gVertexLst
	
	lst = stroke[1]
	sz = len(lst)
	midsz = float(sz/2)
	szline = 0
	if (stroke[0][1]==-1):	szline=gSilWidth.val
	elif (stroke[0][1]==-2):	szline=gLineWidth.val
	elif (stroke[0][1]==-3):	szline=gMatWidth.val
	noisediv = 3 	#pixels
	outlst1 = []
	outlst2 = []
	lastv=[0,0]
	for i in range(sz-1):
		currsz = szline
		if (gIncrement.val == 1) and (gDecrement.val==1):
			if i==midsz: currsz = szline
			elif i< midsz:	currsz = (i/midsz)*szline
			else:	currsz = szline - ((i/midsz)*szline)
		elif (gIncrement.val == 1):	currsz = (i/float(sz))*szline
		elif (gDecrement.val==1):	currsz = szline - ((i/float(sz))*szline)			
		w = currsz/2	
		if (str(type(lst[i]))<>"<type 'list'>"):
			p = gVertexLst[lst[i]][0]
			q = []
			if (str(type(lst[i+1]))<>"<type 'list'>"):
				q = gVertexLst[lst[i+1]][0]
			else:
				q = lst[i+1][0]
			d = dist(p,q)
			v = Vector([q[0]-p[0],q[1]-p[1]])
			v.normalize()
			t1 = [-(v[1]*w),v[0]*w]
			t2 = [v[1]*w,-(v[0]*w)]
			outlst1.append([p[0]+t1[0],p[1]+t1[1]])
			outlst2.append([p[0]+t2[0],p[1]+t2[1]])
			if (gNoise.val) and ((i+1)<sz):
				for j in range(0,d,noisediv):
					rv = Blender.Noise.randuvec()
					outlst1.append([int(p[0]+(v[0]*j)+(t1[0]+rv[0])),int(p[1]+(v[1]*j)+(t1[1]+rv[1]))])
					outlst2.append([int(p[0]+(v[0]*j)+(t2[0]+rv[0])),int(p[1]+(v[1]*j)+(t2[1]+rv[1]))])
		else:
			if (gNoise.val):
				for u in [0.0,0.2,0.4,0.6,0.8,1.0]:
					if u>0.8:	v = Vector(lastv)
					else:
						j = lst[i]
						p = bez3(j[0],j[1],j[2],u)
						q = bez3(j[0],j[1],j[2],u+0.2)
						d = dist(p,q)
						v = Vector([q[0]-p[0],q[1]-p[1]])
						v.normalize()
					t1 = [-(v[1]*w),v[0]*w]
					t2 = [v[1]*w,-(v[0]*w)]
					rv = Blender.Noise.randuvec()
					outlst1.append([int(p[0]+v[0]+(t1[0]+rv[0])),int(p[1]+v[1]+(t1[1]+rv[1]))])
					outlst2.append([int(p[0]+v[0]+(t2[0]+rv[0])),int(p[1]+v[1]+(t2[1]+rv[1]))])
			else:
				p = lst[i][0]
				q = lst[i][2]
				v = Vector([q[0]-p[0],q[1]-p[1]])
				v.normalize()
				t1 = [-(v[1]*w),v[0]*w]
				t2 = [v[1]*w,-(v[0]*w)]
				outlst1.append([p[0]+t1[0],p[1]+t1[1]])
				outlst2.append([p[0]+t2[0],p[1]+t2[1]])
				r =  bez3(i[0],i[1],i[2],0.5)
				outlst1.append([r[0]+t1[0],r[1]+t1[1]])
				outlst2.append([r[0]+t2[0],r[1]+t2[1]])
				outlst1.append([q[0]+t1[0],q[1]+t1[1]])
				outlst2.append([q[0]+t2[0],q[1]+t2[1]])

	outlst2.reverse()
	outlst1.extend(outlst2)
	ans = [[1,stroke[0][1]],outlst1]
	return ans
	
# ---------------------------------------------------------------
# Function	: Vectorize
#	Inputs		:
# OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def Vectorize(width,height,colors):
	global gGenCol,gCurrentFrame,gLineWidth,gVertexLst
	global gbLines,gFlare
	global gSilWidth,gMatWidth,gbToonLines,gToonWidth
	global buffImage,gLineRegions,gbSilhouette,gbLines,gbMaterial,gStrokes
	
	sh = bShape()
	sh.Reset()
	movie = []
	
	#_________________________________
	# Optimize links
	#__________________________________	
	RegionVectors=[]				
	sz = len(gVertexLst)
	
	for numv in range(sz):
		area = 0
		v = gVertexLst[numv]
		lstpts = []
		idx = numv
		while v[2]==0:
			v[2] = 1
			lstpts.append(idx)	
			idx = v[4]
			v = gVertexLst[v[4]]
			if idx == numv:	lstpts.append(idx)
				
		if len(lstpts)>3:
			v = gVertexLst[lstpts[0]][1]
			lstpts = linear_aprox(lstpts)		# Linear Optimization
			lstpts.pop()
			if len(lstpts)>3:				
				lstpts = curve_aprox(lstpts) # Curve Optimization	
				if len(lstpts)>3:					
					RegionVectors.append([v,lstpts])
		del lstpts
	# Sort by color idx		
	RegionVectors.sort()	

	#Add lines
	if gStrokes.val==0:
		if len(gLineRegions)>0:
			for i in gLineRegions:
			#	i = StrokeGeneration(i)
				RegionVectors.append(i)
	
	#__________________________________
	# Create SWF file
	#__________________________________	

	h = height
	a = FILLSTYLEARRAY([FILLSTYLE(SOLID_FILL,[255,0,0,255])])
	b = LINESTYLEARRAY([LINESTYLE(1,[0,0,0,255])])
	
	oldcoloridx=-1
	coloridx =-1
	colorflag=0
	linetrans = 1
	fillshape = 1
	stroke = 0
	for q in RegionVectors:
		region = q[1]
		
		sz = len(region)
		stroke = 0
		if sz>0:
			if (str(type(q[0]))<>"<type 'list'>"):
				coloridx = q[0]
				color=colors[coloridx]
				# Set color flag that identify when a color idx has change	
				if (coloridx==oldcoloridx):	colorflag=0
				else:	
					colorflag=1
				 	oldcoloridx = coloridx
				fillshape = 1
				# Set Fillstyle and line style	
				if (gFlare.val>0):
					ctr = [gFlareLoc[0],gFlareLoc[1]]
					a = FILLSTYLEARRAY([FILLSTYLE(RADIAL_GRADIENT_FILL,[2.0,2.0,0,0,ctr[0],h-ctr[1]],[3,[GRADRECORD(0,[255,255,255,color[3]]),GRADRECORD(30,[color[0],color[1],color[2],color[3]]),GRADRECORD(255,[0,0,0,color[3]])]])])
				else:
					a = FILLSTYLEARRAY([FILLSTYLE(SOLID_FILL,[color[0],color[1],color[2],color[3]])])
				if (gbToonLines.val>0) and (color[3]==255):
					linetrans=1	
					b = LINESTYLEARRAY([LINESTYLE(gToonWidth.val,[int(gGenCol[0][0]*255),int(gGenCol[0][1]*255),int(gGenCol[0][2]*255),255])])
				else:
					linetrans=0	
					b = LINESTYLEARRAY([LINESTYLE(1,[color[0],color[1],color[2],color[3]])])
				fillshape = 1
			else:
				colorflag=1	
				#Strokes
				stroke = q[0][0]
				if q[0][0]==99999:
					if (q[0][1]==-1) and (gbSilhouette.val>0):
						a = FILLSTYLEARRAY([FILLSTYLE(SOLID_FILL,[int(gGenCol[3][0]*255),int(gGenCol[3][1]*255),int(gGenCol[3][2]*255),255])])
					elif (q[0][1]==-2) and (gbLines.val>0):
						a = FILLSTYLEARRAY([FILLSTYLE(SOLID_FILL,[int(gGenCol[2][0]*255),int(gGenCol[2][1]*255),int(gGenCol[2][2]*255),255])])
					elif (q[0][1]==-3) and (gbMaterial.val>0):
						a = FILLSTYLEARRAY([FILLSTYLE(SOLID_FILL,[int(gGenCol[1][0]*255),int(gGenCol[1][1]*255),int(gGenCol[1][2]*255),255])])
					fillshape = 1
					linetrans=0
				else:			
					#Lines	
					linetrans=1	
					if (q[0][1]==-1) and (gbSilhouette.val>0):
						b = LINESTYLEARRAY([LINESTYLE(gSilWidth.val,[int(gGenCol[3][0]*255),int(gGenCol[3][1]*255),int(gGenCol[3][2]*255),255])])
						colorflag=1
					elif (q[0][1]==-2) and (gbLines.val>0):
						b = LINESTYLEARRAY([LINESTYLE(gLineWidth.val,[int(gGenCol[2][0]*255),int(gGenCol[2][1]*255),int(gGenCol[2][2]*255),255])])
						if q[0][0]==1:	a = FILLSTYLEARRAY([FILLSTYLE(SOLID_FILL,[int(gGenCol[3][0]*255),int(gGenCol[3][1]*255),int(gGenCol[3][2]*255),255])])
						colorflag=1
					elif (q[0][1]==-3) and (gbMaterial.val>0):
						b = LINESTYLEARRAY([LINESTYLE(gMatWidth.val,[int(gGenCol[1][0]*255),int(gGenCol[1][1]*255),int(gGenCol[1][2]*255),255])])
						colorflag=1
					else:
						linetrans=0
					fillshape = 0	
					
			i = [0,0]
			f = [0,0]
			for numv in range(sz):
				if str(type(region[numv]))=="<type 'list'>" and (len(region[numv])==3):
					j = [int(region[numv][0][0]),h-int(region[numv][0][1])]
					j1= [int(region[numv][1][0]),h-int(region[numv][1][1])] 
					j2 = [int(region[numv][2][0]),h-int(region[numv][2][1])]
					if numv == 0:
						i = j
						if colorflag:
							sh.SetStyleRecord(SH_MOVE+SH_FILL0+SH_FILL1+SH_LINESTYLE+SH_NEWSTYLES,i[0],i[1],0,fillshape,linetrans,1,1,a,b)
						else:
							sh.MoveTo(i[0],i[1])
					else:
						sh.LineTo(j[0]-f[0],j[1]-f[1])			
					sh.CurveTo(j1[0]-j[0],j1[1]-j[1],j2[0]-j1[0],j2[1]-j1[1])					
					f = j2
				else:	
					
					if str(type(region[numv]))=="<type 'list'>" :
						j = [int(region[numv][0]),h-int(region[numv][1])]
					else:
						j = [int(gVertexLst[region[numv]][0][0]),h-int(gVertexLst[region[numv]][0][1])]
					if numv==0:
						i = j
						if colorflag:
							sh.SetStyleRecord(SH_MOVE+SH_FILL0+SH_FILL1+SH_LINESTYLE+SH_NEWSTYLES,i[0],i[1],0,fillshape,linetrans,1,1,a,b)
						else:
							sh.MoveTo(i[0],i[1])
					else:
						sh.LineTo(j[0]-f[0],j[1]-f[1])	
					f = [j[0],j[1]]
		if (str(type(q[0]))<>"<type 'list'>"):	sh.LineTo(i[0]-f[0],i[1]-f[1])
	sh.EndShape()
	movie = sh.GetShape()

	del RegionVectors,gVertexLst
	del colors,sh,numv,sz
	gVertexLst = []
	
	return movie

# ---------------------------------------------------------------
# 	Function	: TGARender
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def TGARender():
	global gFilename,gPathname
	
	sc = Blender.Scene.getCurrent()
	context = sc.getRenderingContext()
	w = context.imageSizeX()
	h = context.imageSizeY()
	del sc,context
	
	# Viewpoint data
	ViewData = Buffer(GL_FLOAT,4)
	glGetFloatv(GL_VIEWPORT,ViewData)
	dx = ViewData[0]
	dy = ViewData[1]

	# write to file
	size = w*h
	ImageR = Buffer(GL_BYTE,size)
	ImageG = Buffer(GL_BYTE,size)
	ImageB = Buffer(GL_BYTE,size)
	glReadBuffer(GL_FRONT)
	glReadPixels(dx+11,dy+50,w,h,GL_RED,GL_UNSIGNED_BYTE,ImageR)
	glReadPixels(dx+11,dy+50,w,h,GL_GREEN,GL_UNSIGNED_BYTE,ImageG)
	glReadPixels(dx+11,dy+50,w,h,GL_BLUE,GL_UNSIGNED_BYTE,ImageB)

	# Save TGA
	extname = gFilename.val+".tga"
	name = sys.join(gPathname.val,extname)
	del extname

	Header=[chr(0)]*18
	Header[2] = chr(2)		# Uncompressed RGB 
	Header[8] = chr(0)		# X Origin Lo
	Header[9] = chr(0)		# X Origin Hi
	Header[10] = chr(0)		# Y Origin Lo
	Header[11] = chr(0)		# Y Origin Hi
	Header[12] = chr(w%256)	# Width Hi 
	Header[13] = chr(w/256)	#       Lo
	Header[14] = chr(h%256)	# Height Hi
	Header[15] = chr(h/256) #        Lo
	Header[16] = chr(24)	# 24 bits color
	Header[17] = chr(32)		# Top->Down 32 Down->Top 0 

	try:
		f = open(name,"wb")
		# Save Header
		for byte in Header:
			f.write(byte)
		for x in range(h-1,-1,-1):
			for y in range(w):
				byte = (x * w)+ y
				f.write(chr(ImageB[byte]))
				f.write(chr(ImageG[byte]))
				f.write(chr(ImageR[byte]))
		f.close()
		print "TGA file:",name," saved!"
		del x,y,f
	except IOError, (errno,strerror):
		print "I/O Error (%s): %s" % (errno,strerror)
	del name,size,ImageR,ImageB,ImageG,Header
	del dx,dy,ViewData

# ---------------------------------------------------------------
# 	Function	: TIFRender
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def TIFRender():
	global gFilename,gPathname

	sc = Blender.Scene.getCurrent()
	context = sc.getRenderingContext()
	nx = context.imageSizeX()
	ny = context.imageSizeY()
	del sc,context

	# Viewpoint data
	ViewData = Buffer(GL_FLOAT,4)
	glGetFloatv(GL_VIEWPORT,ViewData)
	dx = ViewData[0]
	dy = ViewData[1]

	# write to file
	size = nx*ny
	ImageR = Buffer(GL_BYTE,size)
	ImageG = Buffer(GL_BYTE,size)
	ImageB = Buffer(GL_BYTE,size)
	glReadBuffer(GL_FRONT)
	glReadPixels(dx+11,dy+50,nx,ny,GL_RED,GL_UNSIGNED_BYTE,ImageR)
	glReadPixels(dx+11,dy+50,nx,ny,GL_GREEN,GL_UNSIGNED_BYTE,ImageG)
	glReadPixels(dx+11,dy+50,nx,ny,GL_BLUE,GL_UNSIGNED_BYTE,ImageB)

	extname = str(gFilename.val+".tif")
	name = sys.join(gPathname.val,extname)
	del extname

	try:
		f = open(name,"wb")
		# Save Header
		header = [chr(77),chr(77),chr(0),chr(42)]
	  	offset = size * 3 + 8;
		v = [chr(((offset & 4278190080) / 16777216)),chr(((offset & 16711680) / 65536)),chr(((offset & 65280) / 256)),chr(offset & 255)]
		header.extend(v)
		for byte in header:	f.write(byte)

		# Write the binary data 
		for y in range(ny-1,-1,-1):
			for x in range(nx):
				byte = (y * nx)+ x
				f.write(chr(ImageR[byte]))
				f.write(chr(ImageG[byte]))
				f.write(chr(ImageB[byte]))
		
		# Write the footer 
		f.write(chr(0))
		f.write(chr(14))	# Number of directory entries 
 		
		# Width tag, short int
		c = [1,0,0,3,0,0,0,1]
		for byte in c:	f.write(chr(byte))
		f.write(chr((nx & 65280) / 256))	#Image width
   		f.write(chr(nx & 255))
		f.write(chr(0))
		f.write(chr(0))
  
		# Height tag, short int 
		c = [1,1,0,3,0,0,0,1]
  		for byte in c:	f.write(chr(byte))
		f.write(chr((ny & 65280) / 256))	#Image height
   		f.write(chr(ny & 255))
		f.write(chr(0))
		f.write(chr(0))

		# Bits per sample tag, short int 
		c = [1,2,0,3,0,0,0,3]
  		for byte in c:	f.write(chr(byte))
		offset = (size * 3) + 182;
		v = [chr(((offset & 4278190080) / 16777216)),chr(((offset & 16711680) / 65536)),chr(((offset & 65280) / 256)),chr(offset & 255)]
		for byte in v:	f.write(byte)

		# Compression flag, short int 
		c = [1,3,0,3,0,0,0,1,0,1,0,0]
  		for byte in c:	f.write(chr(byte))
  		# Photometric interpolation tag, short int 
		c = [1,6,0,3,0,0,0,1,0,2,0,0]
  		for byte in c:	f.write(chr(byte))
 		# Strip offset tag, long int 
		c = [1,17,0,4,0,0,0,1,0,0,0,8]
  		for byte in c:	f.write(chr(byte))
   		# Orientation flag, short int 
		c = [1,18,0,3,0,0,0,1,0,1,0,0]
  		for byte in c:	f.write(chr(byte))
  		# Sample per pixel tag, short int
		c = [1,21,0,3,0,0,0,1,0,3,0,0]
  		for byte in c:	f.write(chr(byte))
   		#Rows per strip tag, short int 
		c = [1,22,0,3,0,0,0,1]
  		for byte in c:	f.write(chr(byte))
  		f.write(chr((ny & 65280) / 256))	
   		f.write(chr(ny & 255))
		f.write(chr(0))
		f.write(chr(0))
		#Strip byte count flag, long int 
		c = [1,23,0,4,0,0,0,1]
  		for byte in c:	f.write(chr(byte))
		offset = size * 3
  		v = [chr(((offset & 4278190080) / 16777216)),chr(((offset & 16711680) / 65536)),chr(((offset & 65280) / 256)),chr(offset & 255)]
		for byte in v:	f.write(byte)
		# Minimum sample value flag, short int 
		c = [1,24,0,3,0,0,0,3]
  		for byte in c:	f.write(chr(byte))
		offset = (size * 3) + 188
		v = [chr(((offset & 4278190080) / 16777216)),chr(((offset & 16711680) / 65536)),chr(((offset & 65280) / 256)),chr(offset & 255)]
		for byte in v:	f.write(byte)
  	    # Maximum sample value tag, short int 
		c = [1,25,0,3,0,0,0,3]
  		for byte in c:	f.write(chr(byte))
   		offset = (size * 3) + 194
  		v = [chr(((offset & 4278190080) / 16777216)),chr(((offset & 16711680) / 65536)),chr(((offset & 65280) / 256)),chr(offset & 255)]
		for byte in v:	f.write(byte)
		# Planar configuration tag, short int 
		c = [1,28,0,3,0,0,0,1,0,1,0,0]
  		for byte in c:	f.write(chr(byte))
  		# Sample format tag, short int 
		c = [1,83,0,3,0,0,0,3]
  		for byte in c:	f.write(chr(byte))
		offset = (size * 3) + 200
  		v = [chr(((offset & 4278190080) / 16777216)),chr(((offset & 16711680) / 65536)),chr(((offset & 65280) / 256)),chr(offset & 255)]
		for byte in v:	f.write(byte)
		# End of the directory entry 
		c = [0,0,0,0]
  		for byte in c:	f.write(chr(byte))
 		# Bits for each colour channel 
		c = [0,8,0,8,0,8]
  		for byte in c:	f.write(chr(byte))
  		# Minimum value for each component 
		c = [0,0,0,0,0,0]
  		for byte in c:	f.write(chr(byte))
 		# Maximum value per channel
		c = [0,255,0,255,0,255]
  		for byte in c:	f.write(chr(byte))
   		# Samples per pixel for each channel
		c = [0,1,0,1,0,1]
  		for byte in c:	f.write(chr(byte))
  		f.close()
		del x,y,c,v,f
		print "Tiff file:",name," saved"
	except IOError, (errno,strerror):
		print "I/O Error (%s): %s" % (errno,strerror)
	del name,size,ImageR,ImageB,ImageG
	del dx,dy,ViewData
	
# ---------------------------------------------------------------
# 	Function	: SFS2SWF()
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def SFS2SWF():
	global gScroll2,gFilename,gPathname
	global gMsg,gPercentage,gCompress

	if Blender.Window.EditMode():	Blender.Window.EditMode(0) #Leave EditMode

	sc = Blender.Scene.getCurrent()
	context = sc.getRenderingContext()
	w = context.imageSizeX()
	h = context.imageSizeY()
	del sc,context

	gMsg = "Converting SFS to SWF"
	gPercentage = 0.6
	Draw()

	bkcolor=[]
	w = 0
	h = 0
	fps = 0
	maxframes = 0
	fquality = 1
	floop = 1
	frames = []		

	if len(gScroll2.datalst)>0:
		numfiles = len(gScroll2.datalst)
		for file in gScroll2.datalst:
			name = sys.join(file[1],file[0])

			f = open(name,'rb')
			# _________________________________
			# Read header
			# _________________________________
			data = f.read(21)
			_w = REVUI32([data[0],data[1],data[2],data[3]])	
			_h = REVUI32([data[4],data[5],data[6],data[7]])
			_fps = REVUI32([data[8],data[9],data[10],data[11]])
			_numframes = REVUI32([data[12],data[13],data[14],data[15]])
			_color = [ord(data[16]),ord(data[17]),ord(data[18])]
			_qlty = ord(data[19])
			_loop = ord(data[20])
			# _________________________________
			# Read Data
			# _________________________________
			for i in range(_numframes):
				data = f.read(4)
				sz = REVUI32([data[0],data[1],data[2],data[3]])
				data = f.read(sz)
				recbits = []
				for byte in data:
					recbits.append(byte)
				frames.append(recbits)
			f.close()
			# _________________________________
			# Save first chunk of information	
			# _________________________________
			if _w>w:	w=_w		# keep the max size of movie 
			if _h>h:	h=_h
			fps+=_fps						# this will be the average of all chunks
			maxframes+=_numframes			# number of total frames
			if _qlty==0:	fquality = 0
			if _loop==0:	floop=0
			bkcolor.append([_numframes,_color])
			del _w,_h,_fps,_numframes,_color,_qlty,_loop,data
		
		fps/=numfiles

		movie = []
		# _________________________________
		#	Initialize SWF Movie
		# _________________________________
		# 	Header
		# _________________________________
		movie = swfHeaderBlock(0,[0,0,w,h],fps,maxframes)
		# _________________________________
		#	Quality
		# _________________________________
		if (not fquality):
			# Do some actions
	 		actions = swfActionToggleQualty()
			movie+=swfDoAction(actions)	
		# _________________________________
		#	Create frames
		# _________________________________
		id = 0
		for item in frames:
			movie+= swfDefineShape3(id,RECT(0,0,w,h),item)
			id+=1
		# _________________________________
		#	Create Sprite
		# _________________________________
		oldid = 0
		j = 0
		for c in bkcolor:
			movie+=swfSetBackgroundColor(c[1][0],c[1][1],c[1][2])
			for i in range(c[0]):
				if oldid>0:	movie.extend(swfRemoveObject2(oldid-1))
				movie.extend(swfPlaceObject2(PO_MATRIX+PO_CHAR_ID,j,[0,0,0,[1.0,1.0,0.0,0.0,0.0,0.0],j]))
				movie+=swfShowFrame()
				j+=1
				oldid = j
			if oldid>0:	movie.extend(swfRemoveObject2(oldid-1))
		# _________________________________
		#Loop Animation ?
		# _________________________________
		if (not floop):
			# Do some actions
	 		actions = swfActionStop()
			movie+=swfDoAction(actions)
			movie+=swfShowFrame()
		movie+=swfEnd()
		a = len(movie)
		SetFileLength(movie,a)
		extname = gFilename.val+".swf"
		# write to file
		name = sys.join(gPathname.val,extname)
		if swfWrite(name,movie):
			gPercentage=1
			gMsg = "Error: writing file."
			Draw()
		else:
			if gCompress.val>0:	
				print "Compressing file..."
				CompressSWF(name)
			print "Sequece convertion to SWF file completed."
	else:
		print "Error: Missing data files. Select at least one."

	del bkcolor,w,h,fps,maxframes,fquality,floop,frames
	gPercentage = 0.0
	gMsg = ""
	Draw()
	return

# ---------------------------------------------------------------
# Function	: SWFRender
#	Inputs		:
# OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def SWFRender():
	global gMsg,gPercentage,gExporting
	global gRenderType,gSequenceFileFlag,gNumSeqFiles
	global gGenCol,gFilename,gPathname,gStartFrame,gEndFrame,gStepFrame
	global gCurrentFrame,gCompress
	global gLoopAnimation,gFPS,gQlty
	global gColordic, gColors,gVertexLst
	
	if Blender.Window.EditMode():	Blender.Window.EditMode(0) #Leave EditMode
		
	gMsg = "Rendering SWF"
	startime = clock()
		
	sc = Blender.Scene.getCurrent()
	context = sc.getRenderingContext()
	w = context.imageSizeX()
	h = context.imageSizeY()
	aspx = context.aspectRatioX()
	aspy = context.aspectRatioY()
	del sc,context

		
	gExporting = 1

	if gSequenceFileFlag.val==0:
		movie = []
		#Initialize SWF Movie
		# Header
		movie = swfHeaderBlock(0,[0,0,w,h],gFPS.val,gEndFrame.val/gStepFrame.val)
		# Set Background color
		movie+=swfSetBackgroundColor(int(gGenCol[4][0]*255),int(gGenCol[4][1]*255),int(gGenCol[4][2]*255))

		# ___________________________
		#    Start animation
		# ___________________________
		placelst = []
		for frame in range(gStartFrame.val,gEndFrame.val+1,gStepFrame.val):
			start = clock()
			print "Rendering Frame:",frame,"...",
			gCurrentFrame = frame
			# Initlialize frame variable
			recbits = []
			gPercentage = 0.6
			# Render frame
			if gRenderType.val == 0:
				# Render Wire Frame 
				recbits = RenderWireFrame(1)
			else:
				del gVertexLst
				gVertexLst = []
				gColordic={}
				gColors= []
				gLineRegions=[]
				DrawObjects(1)
				ScanImage(w,h,framebuff)
				recbits = Vectorize(w,h,gColors)
			#Save Define Objects
			placelst.append(recbits)
			end = clock()
			print "%.2f %s" % (end-start,"sec.")
			Blender.Window.QRedrawAll()
		# ___________________________
		#		Quality
		# ___________________________
		if (not gQlty.val):
			# Do some actions
	 		actions = swfActionToggleQualty()
			movie+=swfDoAction(actions)	
		# ___________________________
		#		Create frames
		# ___________________________
		id = 0
		for item in placelst:
			movie+= swfDefineShape3(id,RECT(0,0,w,h),item)
			id+=1
		# ___________________________
		#	Create Sprite
		# ___________________________
		for i in range(len(placelst)):
			if i>0:	movie.extend(swfRemoveObject2(i-1))
			movie.extend(swfPlaceObject2(PO_MATRIX+PO_CHAR_ID,i,[0,0,0,[1.0,1.0,0.0,0.0,0.0,0.0],i]))
			movie+=swfShowFrame()
		if i>0:	movie.extend(swfRemoveObject2(i-1))
		# ___________________________
		#	Loop Animation ?
		# ___________________________
		if (not gLoopAnimation.val):
			# Do some actions
	 		actions = swfActionStop()
			movie+=swfDoAction(actions)
	
		movie+=swfShowFrame()
		movie+=swfEnd()
		a = len(movie)
		SetFileLength(movie,a)
		extname = gFilename.val+".swf"
		# ___________________________
		# 	Write to file
		# ___________________________
		name = sys.join(gPathname.val,extname)
		if swfWrite(name,movie):
			gPercentage=1
			gMsg = "Error: writing file."
			Draw()
		else:
			if gCompress.val>0:	
				print "Compressing file..."
				CompressSWF(name)
			print "Export Completed"
		del placelst	
	else:
		frames_per_file = (gEndFrame.val-gStartFrame.val+1)/gNumSeqFiles.val
		for numfile in range(gNumSeqFiles.val):
			movie = []
			# ___________________________
			#   Set Sequence Header
			# ___________________________
			# 21 byte Sflender File Sequence header
			movie.extend(UI32(w))					#Width
			movie.extend(UI32(h))					#Height
			movie.extend(UI32(gFPS.val))			#Frames per second
			movie.extend(UI32(frames_per_file/gStepFrame.val))	#Number of frames
			movie.extend(chr(int(gGenCol[4][0]*255)))	#Background Red
			movie.extend(chr(int(gGenCol[4][1]*255)))	#Background Green
			movie.extend(chr(int(gGenCol[4][2]*255)))	#Background Blue
			movie.extend(chr(gQlty.val))			#Quality Flag
			movie.extend(chr(gLoopAnimation.val))	#Loop Flag
			# ___________________________
			#    Start animation
			# ___________________________
			sf = (numfile*frames_per_file)+gStartFrame.val
			ef = sf+frames_per_file
			placelst = []
			for frame in range(sf,ef+1,gStepFrame.val):
				start = clock()
				print "Rendering Frame:",frame,"...",
				gCurrentFrame = frame
				# Initlialize frame variable
				recbits = []
				gPercentage = 0.6
				# Render frame
				if gRenderType.val == 0:
					# Render Wire Frame 
					recbits = RenderWireFrame(1)
				else:
					del gVertexLst
					gColordic={}
					gColors= []
					gVertexLst = []
					gLineRegions=[]
					DrawObjects(1)
					ScanImage(w,h,framebuff)
					recbits = Vectorize(w,h,gColors)
				#Save Define Objects
				placelst.append(recbits)
				end = clock()
				print "%.2f %s" % (end-start,"sec.")

			for item in placelst:
				movie.extend(UI32(len(item)))	
				movie.extend(item)
			fstart = "%d" % sf
			fend = "%d" % ef
			extname = gFilename.val+fstart.zfill(3)+"-"+fend.zfill(3)+".sfs"
			del fstart,fend
			# ___________________________
			# 	Write to file
			# ___________________________
			name = sys.join(gPathname.val,extname)
			if swfWrite(name,movie):
				gPercentage=1
				gMsg = "Error: writing file:"+name
				Draw()
				break

		print "Sequence Completed"

	print "%s %.2f %s" % ("Total exporting time:",(clock()-startime)/60.0,"mins.")

	gPercentage = 0.0
	gMsg = ""
	gExporting = 0
	Draw()

# ---------------------------------------------------------------
# 	Function	: Render
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def Render():
	global gRenderType,buffImage,gDirty,gExporting,gRendering

	if gExporting:	return
	if gRendering:	return		# Do not comment this line 
	
	if Blender.Window.EditMode():	Blender.Window.EditMode(0) #Leave EditMode

	sc = Blender.Scene.getCurrent()
	context = sc.getRenderingContext()
	w = context.imageSizeX()
	h = context.imageSizeY()
	if gDirty==1:
		if gRenderType.val == 0:
			gDirty=RenderWireFrame(0)
		else:
			obCamera = sc.getCurrentCamera()
			if obCamera:	gDirty=DrawObjects(0)
			else:
				print "Error, at least one camera object is needed."
				gDirty = 0
		glLineWidth(1.0)
		glColor3f(0.3,0.3,0.3)
	else:
		glRasterPos2d(10,50)
		glDrawPixels(w,h,GL_RGB,GL_UNSIGNED_BYTE,buffImage)
	del sc,context,w,h	


# ---------------------------------------------------------------
# 	Function	: drawBrush
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def drawBrush(dx,dy,w):
	global gBrush

	if gBrush.val==0:											#Square
		glBegin(GL_QUADS)
		glVertex2d(dx-w,dy-w)
		glVertex2d(dx+w,dy-w)
		glVertex2d(dx+w,dy+w)
		glVertex2d(dx-w,dy+w)
		glEnd()
	elif gBrush.val ==1:									#Oval
		flst=[0.0,0.2,0.4,0.6,0.8,1.0]
		glBegin(GL_POLYGON)
		for u in flst:
			p = bez3([dx-w,dy],[dx-w,dy-w],[dx,dy-w],u)
			glVertex2d(p[0],p[1])
		for u in flst:
			p = bez3([dx,dy-w],[dx+w,dy-w],[dx+w,dy],u)
			glVertex2d(p[0],p[1])
		for u in flst:
			p = bez3([dx+w,dy],[dx+w,dy+w],[dx,dy+w],u)
			glVertex2d(p[0],p[1])
		for u in flst:
			p = bez3([dx,dy+w],[dx-w,dy+w],[dx-w,dy],u)
			glVertex2d(p[0],p[1])
		glEnd()
	elif gBrush.val ==2:									#Slash
		glBegin(GL_QUADS)
		glVertex2d(dx-w-2,dy-w)
		glVertex2d(dx-w+2,dy-w)
		glVertex2d(dx+w+2,dy+w)
		glVertex2d(dx+w-2,dy+w)
		glEnd()	
	elif gBrush.val ==3:									#Bk Slash
		glBegin(GL_QUADS)
		glVertex2d(dx+w-2,dy-w)
		glVertex2d(dx+w+2,dy-w)
		glVertex2d(dx-w+2,dy+w)
		glVertex2d(dx-w-2,dy+w)
		glEnd()
	elif gBrush.val ==4:									#Vertical
		glBegin(GL_QUADS)
		glVertex2d(dx-2,dy-w)
		glVertex2d(dx+2,dy-w)
		glVertex2d(dx+2,dy+w)
		glVertex2d(dx-2,dy+w)
		glEnd()										
	elif gBrush.val ==5:									#Horizontal
		glBegin(GL_QUADS)
		glVertex2d(dx-w,dy-2)
		glVertex2d(dx+w,dy-2)
		glVertex2d(dx+w,dy+2)
		glVertex2d(dx-w,dy+2)
		glEnd()										
	elif gBrush.val ==6:									#Cross
		glBegin(GL_QUADS)
		glVertex2d(dx-w-2,dy-w)
		glVertex2d(dx-w+2,dy-w)
		glVertex2d(dx+w+2,dy+w)
		glVertex2d(dx+w-2,dy+w)
		glEnd()	
		glBegin(GL_QUADS)
		glVertex2d(dx+w-2,dy-w)
		glVertex2d(dx+w+2,dy-w)
		glVertex2d(dx-w+2,dy+w)
		glVertex2d(dx-w-2,dy+w)
		glEnd()
	return

# ---------------------------------------------------------------
# 	Function	: drawBrushTest
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------		
def drawBrushTest():
	global gIncrement, gDecrement, gNoise, gSpacing
	glColor3f(1,1,1)
	glBegin(GL_QUADS)
	glVertex2d(160,130)
	glVertex2d(200,130)
	glVertex2d(200,170)
	glVertex2d(160,170)
	glEnd()						
	glBegin(GL_QUADS)
	glVertex2d(18,175)
	glVertex2d(18,210)
	glVertex2d(365,210)
	glVertex2d(365,175)
	glEnd()						
	glColor3f(0,0,0)					
	for i in range(0,300,gSpacing.val*3):
		sz = (i/300.0)*10
		rv = [0,0]
		if gNoise.val:	rv = Blender.Noise.randuvec()
		dx = 30+i+rv[0]
		dy = 195+rv[1]
		if gIncrement.val and gDecrement.val:	
			if i<125:	drawBrush(dx,dy,sz*2)
			elif i>175:		drawBrush(dx,dy,(10-sz)*2)	
			else:	drawBrush(dx,dy,10)						
		elif gIncrement.val:	drawBrush(dx,dy,sz)
		elif gDecrement.val:	drawBrush(dx,dy,10-sz)		
		else:	drawBrush(dx,dy,10)			
						
	return


# ---------------------------------------------------------------
# 	Function	: drawMaskColors
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------		
def drawMaskColors(type=0):
	global gGenCol,gPalette
	#colors
	lst = [0,1,2,3]
	if type:	lst = [1,2,3]
	for i in lst:
		glColor3f(gGenCol[i][0],gGenCol[i][1],gGenCol[i][2])
		glBegin(GL_QUADS)
		glVertex2d(160,50+(i*16))
		glVertex2d(202,50+(i*16))
		glVertex2d(202,62+(i*16))
		glVertex2d(160,62+(i*16))
		glEnd()
	if type==0:
		for i in [0,1,2]:
			glColor3f(gGenCol[i+4][0],gGenCol[i+4][1],gGenCol[i+4][2])
			glBegin(GL_QUADS)
			glVertex2d(313,50+(i*16))
			glVertex2d(357,50+(i*16))
			glVertex2d(357,62+(i*16))
			glVertex2d(313,62+(i*16))
			glEnd()
	gPalette.Draw()
	del i,lst

# ---------------------------------------------------------------
# 	Function	: drawlogo
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------		
def drawlogo():
	global glogo,sflender
	glLineWidth(1.0)
	flst = [0.0,0.2,0.4,0.6,0.8,1.0]
	f = 4.7		
	for item in glogo:
		glColor3f(item[0][0]/255.0,item[0][1]/255.0,item[0][2]/255.0)
		glBegin(GL_LINE_LOOP)
		for j in item[1]:
			if len(j)==3:
				for fix in flst:
					p1 = bez3(j[0],j[1],j[2],fix)
					glVertex2d(p1[0]/f,225+(480-p1[1])/f)	
			else:
					glVertex2d(j[0]/f,225+(480-j[1])/f)
		glEnd()		
	f = 2.5				
	for item in sflender:
		glColor3f(item[0][0]/255.0,item[0][1]/255.0,item[0][2]/255.0)
		glBegin(GL_LINE_LOOP)
		for j in item[1]:
			if len(j)==3:
				for fix in flst:
					p1 = bez3(j[0],j[1],j[2],fix)
					glVertex2d(120+p1[0]/f,180+(480-p1[1])/f)	
			else:
					glVertex2d(120+j[0]/f,180+(480-j[1])/f)
		glEnd()			

# ---------------------------------------------------------------
# 	Function	: draw
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def draw():
	global gbLines,gLineWidth,gRenderType,gLevel,gFX,gFXType,gbMaterial				
	global gPercentage,gbSilhouette,gSilWidth,gMatWidth,gR,gG,gB,gGenCol,gCreateSWF,gCreateBMP
	global gFilename,gStartFrame,gEndFrame,gStepFrame,gCurrentColMask,gCurrentFrame,gMsg
	global gPreview,gEnableMask,gQuit,gPalette,gFlare
	global gLoopAnimation,gFPS,gQlty,gExporting,gDoubleSided
	global gMenuOption,gSequenceFileFlag,gNumSeqFiles
	global gScroll1,gScroll2,gCreateSq,gPathname
	global gShadow,gCompress,gCurveMax,gColorP1,gbToonLines
	global gOK,gCancel,gToonWidth,gLastEnable,gMinDistance
	global gStrokes,gIncrement, gDecrement, gNoise, gRenderBtn
	global gSpacing, gBrush

	# Clear window
	glClearColor(0.0,0.0,0.3,1.0)
	glClear(GL_COLOR_BUFFER_BIT)

	drawFrame(11,350,360,305)
	if gPreview.val == 0:
		
		glColor3f(0.7,0.3,0.0)
		glBegin(GL_QUADS)
		glVertex2d(18,327)
		glVertex2d(18,340)
		glVertex2d(365,340)
		glVertex2d(365,327)
		glEnd()
		
		glColor3f(0.0,0.35,1.0)
		glBegin(GL_QUADS)
		glVertex2d(18,247)
		glVertex2d(18,210)
		glVertex2d(365,210)
		glVertex2d(365,247)
		glEnd()
		drawlogo()
		
		if gMenuOption > -1:
			for btn in gRenderBtn:	btn.Draw()
			gQuit = Button("Quit",EVENT_QUIT,315,10,30,30)
	
		glColor3f(0.0,0.0,0.0)
		glRasterPos2d(175,330)
		Text("Copyright (c) 2005, E.Aguirre")
	
		glColor3f(1.0,1.0,1.0)
		glRasterPos2d(20,330)
		glColor3f(1.0,1.0,1.0)
		Text("v2.6 beta    S f l e n d e r")
		glColor3f(1.0,1.0,1.0)
		glRasterPos2d(3,20)
		Text("*Macromedia(R) and Flash(TM) are")
		glRasterPos2d(3,8)
		Text(" trademarks of Macromedia, Inc.")
		glFlush()
	

	if gMenuOption == -2:
	
		drawMaskColors(1)
		drawBrushTest()
		glColor3f(0,0,0)
		drawBrush(180,150,15)	

		gIncrement = Toggle("Increment",EVENT_INCREMENT,220,125,80,14,gIncrement.val)
		gDecrement = Toggle("Decrement",EVENT_DECREMENT,220,110,80,14,gDecrement.val)
		gNoise = Toggle("Noise",EVENT_NOISE,220,95,80,14,gNoise.val)
		gSpacing =  Slider("S:",EVENT_SPACING,220,140,80,14,gSpacing.val,1,15)
		gBrush = Menu("Brush Type:%t|Square%x0|Oval%x1|Slash%x2|Bk Slash%x3|Vertical%x4|Horizontal%x5|Cross%x6",EVENT_BRUSH_TYPE,220,156,80,14,gBrush.val)
	
		#Lines options
		gbSilhouette = Toggle("Silhouette",EVENT_SILHOUETTE,90,97,67,14,gbSilhouette.val)
		gbLines = Toggle("Lines",EVENT_LINES,90,82,67,14,gbLines.val)
		gbMaterial = Toggle("Mat-Lines",EVENT_MATERIAL_LINES,90,67,67,14,gbMaterial.val)
		#Lines and Background colors and styles
		linsiz = 30	
		gSilWidth = Slider(" ",EVENT_LINE_W,16,97,73,14,gSilWidth.val,1,linsiz)
		gLineWidth = Slider(" ",EVENT_LINE_W,16,82,73,14,gLineWidth.val,1,linsiz)
		gMatWidth = Slider(" ",EVENT_LINE_W,16,67,73,14,gMatWidth.val,1,linsiz)
	
		
		Button ("On",EVENT_OK,220,55,58,25,"Brush On")
		Button("Off",EVENT_CANCEL,280,55,58,25,"Brush Off")
	elif gMenuOption == -1:
		rgb = gColorP1.getRGB()
		glColor3f(rgb[0]/255.0,rgb[1]/255.0,rgb[2]/255.0)
		glBegin(GL_QUADS)
		glVertex2d(200,200)
		glVertex2d(258,200)
		glVertex2d(258,130)
		glVertex2d(200,130)
		glEnd()
		glColor3f(gGenCol[gLastEnable][0],gGenCol[gLastEnable][1],gGenCol[gLastEnable][2])
		glBegin(GL_QUADS)
		glVertex2d(260,200)
		glVertex2d(320,200)
		glVertex2d(320,130)
		glVertex2d(260,130)
		glEnd()

		gR = Slider("R:",EVENT_COLOR,200,125,120,14,gR.val,0.0,1.0)
		gG = Slider("G:",EVENT_COLOR,200,110,120,14,gG.val,0.0,1.0)
		gB = Slider("B:",EVENT_COLOR,200,95,120,14,gB.val,0.0,1.0)
		gOK = Button ("OK",EVENT_OK,200,55,58,25,"OK")
		gCancel = Button("Cancel",EVENT_CANCEL,260,55,58,25,"Cancel")
		gColorP1.Draw()
	
	elif gMenuOption == 0:

		if (gFlare.val == 0):	gPreview = Toggle("Preview",EVENT_PREVIEW,230,10,75,30,gPreview.val)

		if gPreview.val == 0:
			#Type of Render
			gRenderType = Menu("Render Type:%t|No color%x-1|Wired%x0|Flat%x1|Shade%x2|Toon%x3|Stripes 1%x4|Stripes 2%x5|Stripes 3%x6",EVENT_RENDER_TYPE,18,177,80,14,gRenderType.val)
			
			Button("Parameters",EVENT_PARAMS,280,192,80,15,"Load/Save Parameters")
			if gRenderType.val>0:
				#Special effect Flag
				gFX = Toggle("Filter",EVENT_PIXELATE,280,177,80,14,gFX.val)
				if gFX.val>0:
					gFXType = Menu("Type Filter:%t|Pixelate%x0|Voronoi%x1",EVENT_LEVEL,280,160,80,14,gFXType.val)
					gLevel = Menu("Level:%t|2%x2|4%x4|8%x8|16%x16|24%x24|32%x32|48%x48|64%x64",EVENT_LEVEL,280,144,80,14,gLevel.val)
			gFlare = Toggle("Flare",EVENT_FLARE,280,126,80,14,gFlare.val)
			gDoubleSided = Toggle("Double side",EVENT_NONE,280,110,80,14,gDoubleSided.val)
		
			#Number of colors
			if gPalette.visible:
				gCurrentColMask = Menu("Ramp:%t|1%x1|2%x2|3%x3|4%x4|5%x5|8%x8|16%x16|Custom%x32",EVENT_CHANGE_MASK,20,156,15,10,gCurrentColMask.val)

			# Color of mask, this color will be transparent and not will be consider when vectorizing
			gEnableMask = Toggle("Mask",EVENT_MASK,242,82,67,14,gEnableMask.val)
			gShadow = Toggle("Shadows",EVENT_SHADOW,242,67,67,14,gShadow.val)
			Button("Bk Color",EVENT_NONE,242,52,67,14)
			#Lines options
			gbSilhouette = Toggle("Silhouette",EVENT_SILHOUETTE,90,97,67,14,gbSilhouette.val)
			gbLines = Toggle("Lines",EVENT_LINES,90,82,67,14,gbLines.val)
			gbMaterial = Toggle("Mat-Lines",EVENT_MATERIAL_LINES,90,67,67,14,gbMaterial.val)
			gbToonLines = Toggle("Toon-Lines",EVENT_TOON_LINES,90,52,67,14,gbToonLines.val)
			
			Button("Brush",EVENT_STROKES,204,52,35,58)
			linsiz=30
			#Lines and Background colors and styles
			gSilWidth = Slider(" ",EVENT_LINE_W,16,97,73,14,gSilWidth.val,1,linsiz)
			gLineWidth = Slider(" ",EVENT_LINE_W,16,82,73,14,gLineWidth.val,1,linsiz)
			gMatWidth = Slider(" ",EVENT_LINE_W,16,67,73,14,gMatWidth.val,1,linsiz)
			gToonWidth =Slider(" ",EVENT_LINE_W,16,52,73,14,gToonWidth.val,1,linsiz)

			glColor3f(1.0,1.0,1.0)
			glRasterPos2d(18,198)
			Text("Select render type:")
			drawMaskColors()
		else:
			# Get Scene
			Render()
			gCreateTGA = Button("Save TGA",EVENT_CREATE_BMP,150,10,75,15,"Save TGA file")
			gCreateTIFF = Button("Save TIFF",EVENT_CREATE_TIF,150,30,75,15,"Save TIFF file")

	elif gMenuOption == 1:
		
		# SWF Render options
		gLoopAnimation = Toggle("Loop",EVENT_LOOP,20,158,35,14,gLoopAnimation.val)
		gQlty = Toggle("Qlty",EVENT_QLTY,57,158,35,14,gQlty.val)
		gFPS =  Number("FPS:",EVENT_FPS,95,158,70,14,gFPS.val,1,60,"Frames per second")
		gStartFrame = Number("Start",EVENT_STARTFRAME,20,140,65,14,gStartFrame.val,1,18000,"Start Frame")
		gEndFrame = Number("End",EVENT_ENDFRAME,87,140,65,14,gEndFrame.val,1,18000,"End Frame")
		gStepFrame =  Number("S:",EVENT_STEPFRAME,155,140,35,14,gStepFrame.val,1,100,"Step Frame")
		gCurveMax = Slider(" ",EVENT_VEC_TYPE,240,156,79,15,gCurveMax.val,0.26,1.3,0,"Near to 0 Line - Near to 1.3 Curve")
		gMinDistance = Slider ("D:",EVENT_LINE_MIN_DISTANCE ,240,139,79,15,gMinDistance.val,1.5,10.0,0,"Min. Distance in pixeles")
		gCompress = Toggle("Compress",EVENT_COMPRESS_FLAG, 240,122,79,15,gCompress.val)
		Button("Reset Frames ",EVENT_RESETFRAMES,20,123,170,15,"Reset Frames Blender Values.")
		if gSequenceFileFlag.val==0:
			gSequenceFileFlag = Toggle("Save as SWF file",EVENT_SEQ_FLAG,20,90,235,15,gSequenceFileFlag.val)
			gCreateSWF = Button("Export SWF",EVENT_CREATE_SWF,230,10,75,30,"Render SWF to file")
		else:
			gSequenceFileFlag = Toggle("Save as sequence file (.SFS )",EVENT_SEQ_FLAG,20,90,197,15,gSequenceFileFlag.val,"Automatically creates N number of sequence files")
			gNumSeqFiles=Number("#",EVENT_NUM_SEQ_F,216,90,50,15,gNumSeqFiles.val,1,50,"Number of sequence files")
			gCreateSWF = Button("Export SFS",EVENT_CREATE_SWF,230,10,75,30,"Render SWF to file")
		gPathname = String("Pathname:",EVENT_PATHNAME,20,70,325,15,gPathname.val,1024,"Set the path name.")
		gFilename = String("Filename:",EVENT_FILENAME,20,52,325,15,gFilename.val,1024,"Filename")
		Button("...",EVENT_BROWSE,347,50,15,35,"Browse Files")
		
		glColor3f(1.0,1.0,1.0)
		glRasterPos2d(20,177)
		Text("SWF Parameters:")
		glRasterPos2d(213,177)
		Text("Vectorize Parameters:")
		glRasterPos2d(213,160)
		Text("Line")
		glRasterPos2d(325,160)
		Text("Curve")
		glRasterPos2d(20,110)
		Text("A 3D View should be visible to export an animation.")

	elif gMenuOption ==2:
		Button(">",EVENT_ADD_ITEM,180,154,30,17,"Add Item")
		Button("<",EVENT_DEL_ITEM,180,134,30,17,"Delete Item")
		Button(">>",EVENT_ADD_ALL,180,114,30,17,"Add all items")
		Button("<<",EVENT_REMOVE_ALL,180,94,30,17,"Remove all items")
		Button("Get .SFS Files",EVENT_GET_FILE,25,171,150,15,"Get a sequence file (.SFS)")
		
		Button("Create SWF",EVENT_SEQUENCE_SWF,230,10,75,30,"Create unique SWF with all sequence files")
		gPathname = String("Pathname:",EVENT_PATHNAME,20,70,325,15,gPathname.val,1024,"Set the path name.")
		gFilename = String("Filename:",EVENT_FILENAME,20,52,325,15,gFilename.val,1024,"Filename")
		Button("...",EVENT_BROWSE,347,50,15,35,"Browse Files")

		glColor3f(1.0,1.0,1.0)
		gScroll1.Draw()
		gScroll2.Draw()
		glFlush()

	
		
	#Draw Progress Bar
	if (gPercentage>0):
		glColor3f(1.0,0.5,0.0)
		glBegin(GL_QUADS)
		glVertex2d(18,30)
		glVertex2d(18,40)
		glVertex2d(18+(gPercentage*100),40)
		glVertex2d(18+(gPercentage*100),30)
		glEnd()
		glColor3f(1.0,1.0,1.0)
		glRasterPos2d(3,32)
		Text(gMsg)
		if gExporting:	Text(" Frame %d" % gCurrentFrame)
	else:
		if gPreview.val == 0:
			glColor3f(0.75,0.75,0.75)
			glRasterPos2d(145,315)
			Text("Exporter for Macromedia(R) Flash(TM)*")
	glColor3f(1.0,1.0,1.0)


# ---------------------------------------------------------------
# 	Function	: event
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def event(evt,val):
	global gMouseXY,gMB
	if (evt == QKEY and not val):
		Exit()
	if (evt == MOUSEX):
		gMouseXY[0] = val
	elif (evt == MOUSEY):	
		gMouseXY[1] = val
		OnMouseMove()
	elif (evt == LEFTMOUSE):
		gMB[0] = val
		if val:	OnMouseMove()
	elif (evt == MIDDLEMOUSE):
		gMB[1] = val
		if val:	OnMouseMove()
	elif (evt == RIGHTMOUSE):
		gMB[2] = val
		if val:	OnMouseMove()
		



# ---------------------------------------------------------------
# 	Function	: drawMaskColors
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------		
def hitTestMaskColors(x,y,type=0):
	global gGenCol,gLastEnable,gMenuOption
	#colors
	if (x>160) and (x<202):
		for i in [0,1,2,3]:
			if (y>50+(i*16)) and (y<62+(i*16)):
				gLastEnable	= i
				gMenuOption = -1
				gColorP1.setRGB(int(gGenCol[i][0]*255),int(gGenCol[i][1]*255),int(gGenCol[i][2]*255))
				
				Draw()
				break	
	if type == 0:
		if (x>313) and (x<357):
			for i in [0,1,2]:
				if (y>50+(i*16)) and (y<62+(i*16)):
					gLastEnable	= i+4
					gMenuOption = -1
					gColorP1.setRGB(int(gGenCol[i+4][0]*255),int(gGenCol[i+4][1]*255),int(gGenCol[i+4][2]*255))
					Draw()
					break		
			
# ---------------------------------------------------------------
# 	Function	: OnMouseMove
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------
def OnMouseMove():
	global gMB,gMouseXY,gOldXY,gPalette, gMenuOption
	global gScroll1, gScroll2, gColorP1,gR,gB,gG
	global gRenderBtn,gLastEvent
	# Viewpoint data
	ViewData = Buffer(GL_FLOAT,4)
	glGetFloatv(GL_VIEWPORT,ViewData)
	dx = gMouseXY[0] - ViewData[0]
	dy = gMouseXY[1] - ViewData[1]


	if gMenuOption == -2:
		if (gMB[0] == 1):	
			hitTestMaskColors(dx,dy,1)
			gLastEvent =-2
		else:
			gLastEvent=0
	elif gMenuOption==-1:
		if (gColorP1.OnMouseMove(dx,dy,gMB)):
			rgb = gColorP1.getRGB()
			gR.val = rgb[0]/255.0
			gG.val = rgb[1]/255.0
			gB.val = rgb[2]/255.0
			Draw()
	elif gMenuOption == 0:
		if (gPalette.OnMouseMove(dx,dy,gMB)):
			Draw()
		if (gMB[0] == 1):	hitTestMaskColors(dx,dy)	
		gLastEvent = 0
	elif  gMenuOption == 2:
		if (gScroll1.OnMouseMove(dx,dy,gMB)):
			pass
		if (gScroll2.OnMouseMove(dx,dy,gMB)):
			pass
	
	if gMenuOption>=0:
		gRenderBtn[0].over = 0
		gRenderBtn[1].over = 0
		gRenderBtn[2].over = 0
		for i in range(len(gRenderBtn)):
			ans = gRenderBtn[i].OnMouseMove(dx,dy,gMB)
			if (ans==1):
				gRenderBtn[i].over = 1						
				break
			elif (ans==2):
				gRenderBtn[0].SetState(0)
				gRenderBtn[1].SetState(0)
				gRenderBtn[2].SetState(0)
				gRenderBtn[i].SetState(1)
				gMenuOption=i
				break
				
	del dx,dy,ViewData
	gOldXY[0] = gMouseXY[0]
	gOldXY[1] = gMouseXY[1]
	return

# ---------------------------------------------------------------
# 	Function	: SetColorsMask
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------
def SetColorsMask(num):
	global gPalette
	if num<32:	gPalette.maxcolors = num
	else:
		gPalette.maxcolors = 16
		num = 1		
	gPalette.ResetContent()
	denom = num-1
	if denom>0:
		delta = gPalette.palrc.Width()/denom
	else:
		delta = gPalette.palrc.Width()
	gPalette.curidx=0
	for j in range(num):
		if denom>0:
			i = float(j)/float(denom)
		else:	i = 0
		px = gPalette.palrc.L+ (delta*j)
		py = gPalette.wndrc.B + (gPalette.vs/2)+5	
		gPalette.curidx+=1
		w = CGHandle(i,gPalette.curidx,px-3,py+8,px+3,py-8)
		gPalette.AddHandle(w)
		del w
	del i,j,delta
	Redraw()

# ---------------------------------------------------------------
# 	Function	: GetFilename
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def GetFilename(name):
	global gFilename,gPathname
	n =  sys.splitext(sys.basename(name))
	gFilename.val = n[0]
	gPathname.val = sys.dirname(name)
	del n

# ---------------------------------------------------------------
# 	Function	: SaveParams
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def SaveParameters(name):
	global gSilWidth,gLineWidth,gMatWidth,gGenCol,gRenderType,gPalette
	f = open(name,'w')
	buff = "%d\n" % gSilWidth.val
	f.write(buff)
	buff = "%d\n" % gLineWidth.val
	f.write(buff)
	buff = "%d\n" % gMatWidth.val
	f.write(buff)
	buff = "%d\n" % gRenderType.val
	f.write(buff)
	for i in range(7):
		buff = "%f\n" % gGenCol[i][0]
		f.write(buff)
		buff = "%f\n" % gGenCol[i][1]
		f.write(buff)
		buff = "%f\n" % gGenCol[i][2]
		f.write(buff)
	lst = gPalette.GetIntenLst()
	sz = len(lst)
	buff = "%d\n" % sz
	f.write(buff)
	for i in lst:
		buff ="%f\n" % i
		f.write(buff)
	f.close	

# ---------------------------------------------------------------
# 	Function	: GetParams
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def GetParameters(name):
	global gSilWidth,gLineWidth,gMatWidth,gGenCol,gRenderType,gPalette
	f = open(name,'r')
	buff = f.readline()
	gSilWidth.val= int(buff)
	buff = f.readline()
	gLineWidth.val= int(buff)
	buff = f.readline()
	gMatWidth.val= int(buff)
	buff = f.readline()
	gRenderType.val= int(buff)
	for i in range(7):
		buff = f.readline()
		gGenCol[i][0] = float(buff)
		buff = f.readline()
		gGenCol[i][1] = float(buff)
		buff = f.readline()
		gGenCol[i][2] = float(buff)
	lst = []
	buff = f.readline()
	sz = int(buff)
	for i in range(sz):
		buff = f.readline()
		lst.append(float(buff))
	gPalette.SetLstfromInten(lst)
	
	f.close	
	if gRenderType.val==2 or gRenderType.val == 3:
		gPalette.Visible()
	else:	gPalette.Visible(0)
		
# ---------------------------------------------------------------
# 	Function	: bevent
#	Inputs		:
# 	OutPuts 	:
#	Description	:
# ---------------------------------------------------------------	
def bevent(evt):
	global gCurrentColMask,gRenderType,gPalette,gR,gB,gG,gColorP1
	global gCurrentFrame,gStartFrame,gEndFrame,gPalette,gPreview,gDirty
	global gMenuOption,gScroll1,gScroll2,gPathname,buffImage,gStrokes
	global gShadow,gFlare,gFlareObjName,gLastEnable,gGenCol,gLastEvent
	Repaint = 0
	if (evt == EVENT_QUIT):
		if buffImage<>None:	
			del buffImage
		Exit()
	elif (evt == EVENT_STROKES):
		gMenuOption = -2
		Repaint = 1
	elif (evt == EVENT_INCREMENT) or (evt ==EVENT_DECREMENT) or (evt == EVENT_NOISE) or(evt == EVENT_SPACING) or (evt == EVENT_BRUSH_TYPE):
		Repaint = 1
	elif (evt == EVENT_OK):
		if gMenuOption == -1:
			rgb = gColorP1.getRGB()
			gGenCol[gLastEnable][0]=rgb[0]/255.0
			gGenCol[gLastEnable][1]=rgb[1]/255.0
			gGenCol[gLastEnable][2]=rgb[2]/255.0
		elif gMenuOption == -2:
			gStrokes.val = 1
		gMenuOption = gLastEvent
		Repaint = 1
	elif (evt == EVENT_CANCEL):
		if gMenuOption == -2:
			gStrokes.val = 0
		gMenuOption = gLastEvent
		Repaint = 1
	elif (evt == EVENT_CHANGE_MASK):
		SetColorsMask(gCurrentColMask.val)
	elif (evt == EVENT_LINE_W) or (evt == EVENT_PIXELATE):
		Repaint = 1
	elif (evt == EVENT_RENDER_TYPE):
		if gRenderType.val==2 or gRenderType.val == 3:
			gPalette.Visible()
		else:	gPalette.Visible(0)
		gCurrentFrame = gStartFrame.val
		Repaint = 1
	elif (evt == EVENT_COLOR):
		gColorP1.setRGB(gR.val*255,gG.val*255,gB.val*255)
		Repaint = 1
	elif (evt == EVENT_CREATE_SWF):
 		SWFRender()
 	elif (evt == EVENT_CREATE_BMP):
 		TGARender()
 	elif (evt == EVENT_CREATE_TIF):
 		TIFRender()
 	elif (evt == EVENT_STARTFRAME):
		gCurrentFrame = gStartFrame.val
		if gEndFrame.val < gStartFrame.val: gEndFrame.val = gStartFrame.val
		# Set Current Frame
		Blender.Set('curframe',gCurrentFrame)
		Repaint = 1
 	elif (evt == EVENT_ENDFRAME):
		if gEndFrame.val < gStartFrame.val:	gEndFrame.val = gStartFrame.val
		Repaint = 1
 	elif (evt == EVENT_RESETFRAMES):
		gStartFrame.val = Blender.Get('staframe')
		gEndFrame.val = Blender.Get('endframe')
		Repaint = 1
	elif (evt == EVENT_PREVIEW):
		gCurrentFrame=Blender.Get('curframe')
		if gPreview.val == 1:	gDirty = 1 
		Repaint = 1
	elif (evt == EVENT_VEC_PREVIEW):
		Repaint = 1
	elif (evt==EVENT_SEQUENCE_SWF):	
		SFS2SWF()
	elif (evt ==EVENT_ADD_ITEM):
		str = gScroll1.GetSelected()
		if str<>None:
			gScroll1.DelItem(gScroll1.selidx)
			gScroll2.AddItem(str[0],str[1])
			Repaint = 1
	elif (evt ==EVENT_DEL_ITEM):	
		str = gScroll2.GetSelected()
		if str<>None:
			gScroll2.DelItem(gScroll2.selidx)
			gScroll1.AddItem(str[0],str[1])
			Repaint = 1
	elif (evt ==EVENT_REMOVE_ALL):
		for x in gScroll2.datalst:
			gScroll1.AddItem(x[0],x[1])
		gScroll2.ClearLst()
		gScroll2.selidx = -1
		Repaint = 1
	elif (evt ==EVENT_ADD_ALL):	
		for x in gScroll1.datalst:
			gScroll2.AddItem(x[0],x[1])
		gScroll1.ClearLst()
		gScroll1.selidx = -1
		Repaint = 1
	elif (evt ==EVENT_GET_FILE):
		lstfiles = listdir(gPathname.val)
		gScroll1.ClearLst()
		for file in lstfiles:
			n = sys.splitext(file)
			if n[1]==".sfs" or n[1]==".SfS":
				gScroll1.AddItem(file,gPathname.val)
			del n
		del lstfiles
		Repaint = 1
	elif (evt == EVENT_BROWSE):
		Blender.Window.FileSelector(GetFilename,"Get File")
	elif (evt == EVENT_SEQ_FLAG) or (evt==EVENT_NUM_SEQ_F) or (evt == EVENT_VEC_TYPE):
		Repaint = 1
	elif (evt == EVENT_PARAMS):
		ans = Blender.Draw.PupMenu("Parameters%t|Save%x1|Restore%x2")
		if ans==1:
			Blender.Window.FileSelector(SaveParameters,"Save *.sfp File")	
		elif ans==2:
			Blender.Window.FileSelector(GetParameters,"Get *.sfp File")
	elif (evt == EVENT_FLARE):
		if gFlare.val == 1:
			gFlareObjName=PupStrInput("Obj:","None",100)
		Repaint = 1
	elif (evt == EVENT_SHADOW):
		pass
	elif (evt == EVENT_LAMP_SHADOW):
		pass
		
	if Repaint == 1:	Draw()
# --------------------------------------------------------------
#
# Definition of global variables
#
# --------------------------------------------------------------
gbLines = Create(0)				# Flag to Draw or not the lines
gbSilhouette = Create(0)  # Flag to Draw or not the silhouette
gbMaterial = Create(0)			# Flag to Draw or not the material lines
gbToonLines = Create(0)		# Flag to Draw or not the toon lines
gB = Create(1.0)
gBrush = Create(0)
buffImage  = None					# Image Buffer 
framebuff = None					# Frame Buffer
gCancel = Create(0)						
gCreateSWF = Create(0)		# Flag button to create swf
gCreateBMP = Create(0)		# Flag button to save tga
gCreateTIFF = Create(0)		# Flag button to save tiff
gCurrentFrame = 1
gCurrentColMask = Create(3)	# Current mask color idx
gCreateSq = Create(0)
gColordic = {}
gColors=[]
gCompress = Create(0)			# Flag to indicate if SWF youd be compressed
gCurveMax = Create(1.0)		# Curvature factor
								
gDirty = 0
gDoubleSided = Create(0)	#Draw Double side faces (backfaces)
gDecrement = Create(0) 
gEnableMask = Create(1)		# Flag to use color mask or not 
gExporting = 0
gEndFrame = Create(1)
gEndFrame.val = Blender.Get('endframe')
gError = 4.0

gFX = Create(0)				# Flag button to special effect image
gFXType = Create(0)			# Type of effect
gFilename = Create("demo")
gFPS = Create(24)
gFlare = Create(0)		
gFlareObjName = None
gFlareLoc = [0,0]
	
gG = Create(1.0)
gGenCol = [[0.0,0.0,0.0],[0.0,0.0,0.0],[0.0,0.0,0.0],[0.0,0.0,0.0],[1.0,1.0,1.0],[0.0,0.0,0.0],[1.0,0.0,1.0]]

gIncrement = Create(0)

gLastEvent = 0
gLineRegions=[]
gLastEnable = Create(3)		# Last color toggle
gLevel = Create(16)
vLight  =  Vector() # Light vector from
gLineWidth = Create(1) 		# Line width
gLoopAnimation = Create(1)


gMatWidth = Create(1)
gMB = [0,0,0]
gMenuOption = 0

gMinDistance = Create(1.5)
gMouseXY = [0,0]
gMsg = ""					# Message to be display in progress bar

gNoise = Create(0)
vNormal =  Vector() # Normal vector of the face 
gNumSeqFiles = Create(1)	# Number of Sequences files to create	

gOldXY = [0,0]
gOK = Create(0)

gPathname = Create("c:\swf")
gPalette = CPickPalette(15,170,260,45,5)
gPalette.ResetContent()
gPalette.Visible(0)
gPercentage = 0.0			# Percentage of the progress bar
gPreview= Create(0)

gQlty = Create(1)
gQuit = Create(0)

gRenderType = Create(1)		# Render Type: 0 - Wire Frame, 1 - Flat, 2 - Shade, 3 - Shade, 4 -Pixelate
gRendering = 0
gR = Create(1.0)

gRenderBtn = [CFlatButton(25,214,100,30,[0,90,255],[0,45,155],"Render"),
							CFlatButton(140,214,100,30,[0,90,255],[0,45,155],"Export"),
							CFlatButton(256,214,100,30,[0,90,255],[0,45,155],"Sequencer")]
gRenderBtn[0].SetState(1)							
gColorP1 = CColorPicker(30,70,150,150)
gColorP1.setRGB(255,0,0)	
gColorP1.refresh()
gScroll1 = CVScrollLst(25,90,150,80)
gScroll1.ClearLst()
gScroll2 = CVScrollLst(215,90,150,80,[0.7,0.3,0.0])
gScroll2.ClearLst()
gSequenceFileFlag = Create(0)
gShadow = Create(0)
gStrokes = Create(0)
SetColorsMask(gCurrentColMask.val)
gSilWidth = Create(1)		# Silhouette width
gSilhouette = []
gStartFrame = Create(1)
gStartFrame.val = Blender.Get('staframe')
gStepFrame = Create(1)
gSpacing = Create(1)


vSight 	=  Vector() # Sight vector formed by the camera position and a face point 
gToonWidth = Create(1)
gVertexLst = [0]

glogo = [[[0, 90, 255, 255],
	[[480, 212], [[481, 212], [482, 213], [483, 211]], [[483, 211], [484, 209],[488, 198]],
	[[488, 198], [492, 187], [495, 168]], [[495, 168], [498, 150],[499, 138]],
	[[499, 138], [499, 126], [496, 112]], [[496, 112], [493, 99], [490, 91]],
	[[490, 91], [486, 83], [485, 82]], [483, 82], [[481, 84], [479, 86], [482, 92]],
	[[482, 92], [485, 98], [488, 111]], [[488, 111], [491, 124], [491, 141]],
	[[491, 141], [490, 159], [488, 173]], [[488, 173], [485, 188], [481, 197]],
	[[481, 197], [477, 207], [477, 209]], [[477, 209], [477, 211], [479, 211]]]],
	[[0, 90, 255, 255],
	[[203, 85], [[205, 85], [206, 86], [221, 75]], [[221, 75], [235, 64], [254, 55]],
	[272, 47], [[292, 41], [312, 35], [329, 32]], [345, 29], [398, 28],
	[[408, 30],[417, 32], [429, 36]], [[429, 36], [441, 41], [453, 51]],
	[[453, 51], [465, 62],[469, 67]], [[469, 67], [473, 73], [476, 72]],
	[478, 72], [[479, 70], [479, 69],[475, 64]], [[475, 64], [471, 60], [469, 56]],
	[466, 52], [[456, 42], [445,32], [435, 26]],[424, 21], [405, 15], [356, 15],
	[291, 30], [261, 42], [[245, 50], [229, 58], [216, 67]],[203, 76], [[200, 79], [197, 82], [200, 83]]]],
	[[0, 90, 255, 255],
	[[[116, 432], [115, 434], [140, 433]], [[140, 433], [164, 432], [184, 427]],
	[204, 423], [248, 410], [337, 371], [[358, 357], [378, 344], [399, 326]],
	[419, 309], [[429, 298], [438, 288], [451, 271]], [[451, 271], [463, 254], [469, 243]],
	[474, 232], [[474, 230], [474, 229], [473, 229]], [472, 229], [468, 229],
	[[463,241], [457, 253], [445, 269]], [[445, 269], [433, 285], [418, 301]],
	[[418, 301], [402, 317], [386, 329]], [[386, 329], [370, 341], [351, 352]],
	[[351, 352], [332, 364], [306, 375]], [280, 386], [227, 404], [132, 426], 
	[[125, 428], [117, 431], [116, 432]]]],
	[[0, 90, 255, 255],
	[[[184, 349], [188, 349], [197, 348]], [[197, 348], [206, 348], [213, 344]],
	[220, 341], [[205, 342], [190, 343], [182, 341]], [[182, 341], [173, 340],
	[160, 331]], [[160, 331], [147, 323], [142, 316]], [[142, 316], [137, 309], [134, 301]],
	[130, 294], [[127, 277], [123, 261], [123, 249]], [[123, 249], [123, 238], [125, 221]],
	[127, 205], [137, 173], [[144, 159], [150, 145], [159, 133]], [167, 122],
	[188, 101], [189, 98], [[188, 98], [187, 98], [184, 96]], [181, 95], 
	[[172, 105], [162, 116], [154, 128]], [145, 140], [[139, 152], [133, 165], [129, 177]],
	[[129, 177], [124, 190], [122, 200]], [120, 210], [[119, 231], [117, 253], [119, 267]],
	[[119, 267], [120, 281], [124, 291]], [[124, 291], [127, 302], [132, 311]],
	[[132, 311], [137, 321], [142, 326]], [[142, 326], [146, 332], [154, 337]],
	[162, 343], [[171, 346], [179, 349], [184, 349]]]],
	[[255, 0, 0, 255],
	[[265, 349], [[268, 349], [271, 350], [274, 349]], [276, 348], [289, 331],
	[[286, 331], [282, 331], [278, 334]], [[278, 334], [274, 338], [270, 340]],
	[265, 342], [[262, 342], [258, 342], [255, 338]], [[255, 338], [251, 334], [252, 328]],
	[[252, 328], [253, 323], [256, 318]], [[256, 318], [259, 313], [255, 312]],
	[[255, 312], [250, 311], [249, 314]], [[249, 314], [248, 317], [248, 326]],
	[[248, 326], [247, 335], [248, 338]], [[248, 338], [249, 341], [252, 343]], [255, 346]]],
	[[255, 0, 0, 255],
	[[292, 316], [[301, 316], [309, 316], [309, 311]], [309, 307], 
	[[296, 303], [283, 299], [279, 300]], [[279, 300], [274, 301], [270, 299]],
	[266, 297], [259, 294], [[255, 294], [250, 295], [249, 296]], 
	[[249, 296], [247, 297], [248, 300]], [249, 303], [[263, 308], [276, 314], [284, 315]]]],
	[[255, 0, 0, 255],
	[[293, 275], [[303, 275], [312, 276], [317, 275]], [322, 274], [[327, 272], [331, 270],[333, 268]],
	[334, 267], [[334, 266], [333, 265], [325, 266]], [[325, 266], [316, 268], [303, 268]],
	[[303, 268], [289, 268], [283, 266]], [[283, 266],[277, 265], [275, 261]], 
	[273, 258], [[273, 256], [272, 254], [268, 255]], [264, 256], 
	[[263, 258], [261, 260], [262, 264]], [[262, 264], [263, 268], [271, 271]], [279, 274]]],
	[[255, 0, 0, 255],
	[[287, 220], [[288, 220], [289, 221], [289, 197]], [[289, 197], [289, 174], [292, 154]], 
	[294, 134], [[294, 124], [294, 114], [293, 111]], [291, 109], [286, 108],
	[[285, 109], [284, 111], [282, 122]], [280, 134], [280, 188]]],
	[[255, 0, 0, 255],
	[[[279, 292], [290, 293], [295, 293]], [[295, 293], [300, 294], [309, 292]], 
	[[309, 292], [317, 291], [321, 288]], [[321, 288], [325, 286], [325, 284]],
	[[325,284], [325, 283], [317, 284]], [[317, 284], [308, 286], [295, 286]],
	[[295, 286], [281, 286], [275, 284]], [[275, 284], [268, 282], [267, 279]],
	[265, 276], [[265, 274], [264, 272], [260, 273]], [[260, 273], [255, 275], [255, 279]],
	[254, 283], [[255, 284], [256, 286], [262, 288]], [[262, 288], [268, 291], [279, 292]]]],
	[[255, 0, 0, 255],
	[[[292, 102], [293, 103], [297, 103]], [[297, 103], [300, 104], [305, 100]],
	[[305, 100], [309, 97], [312, 89]], [315, 81], [[320, 74], [325, 68], [329, 65]],
	[[329, 65], [333, 63], [340, 61]], [[340, 61], [347, 60], [356, 61]],
	[[356, 61], [364, 63], [369, 71]], [[369, 71], [373, 79], [374, 85]],
	[[374, 85], [374, 92], [378, 95]], [[378, 95], [382, 98], [383, 98]], 
	[[383, 98], [384, 98], [385, 95]], [386, 93], [[389, 84], [391, 76], [391, 71]],
	[[391, 71], [391, 66], [389, 63]], [[389, 63], [387, 61], [382, 59]], 
	[[382, 59], [377, 57], [364, 55]], [[364, 55], [351, 54], [341, 56]],
	[[341, 56], [331, 59], [319, 67]], [[319, 67], [307, 75], [302, 81]],
	[[302, 81], [296, 87], [294, 91]], [[294, 91], [292, 95], [292, 98]], [291, 101]]],
	[[255, 0, 0, 255],
	[[[295, 255], [302, 256], [311, 256]], [319, 257], [[327, 255], [334, 254], [338, 251]],
	[[338, 251], [342, 249], [342, 247]], [[342, 247], [342, 246], [333, 247]],
	[[333, 247], [323, 249], [311, 249]], [[311, 249], [298, 249], [292, 247]],
	[[292, 247], [286, 246], [284, 242]], [[284, 242], [281, 239], [281, 237]],
	[[281, 237], [281, 235], [279, 235]], [[279, 235], [277, 235], [274, 237]],
	[[274,237], [270, 240], [270, 243]], [270, 247], [[272, 248], [273, 250], [281, 252]],
	[288, 255]]],
	[[255, 0, 0, 255],
	[[[326, 240], [326, 242], [328, 242]], [[328, 242], [329, 242], [348, 216]], [366, 191],
	[407, 141], [[409, 134], [411, 127], [409, 126]], [406, 126], [386, 146], [343, 206],
	[326, 238]]],
	[[255, 204, 0, 255],
	[[175, 227], [[177, 227], [179, 228], [187, 225]], [[187, 225], [195, 222], [209, 213]],
	[[209, 213], [222, 205], [229, 200]], [[229, 200], [235, 196], [232, 194]],
	[[232, 194], [229, 192], [228, 191]], [[228, 191], [226, 191], [205, 199]],
	[183, 207], [[177, 211], [171, 216], [171, 220]], [[171, 220], [170, 224], [173, 225]]]],
	[[255, 204, 0, 255],
	[[426, 109], [[428, 109], [430, 110], [435, 108]], [440, 106], [[466, 92], [491, 78], [518, 68]],
	[544, 58], [549, 54], [[549, 50], [549, 47], [544, 46]], [[544, 46], [538, 45], [536, 44]],
	[[536, 44], [534, 44], [520, 50]], [505, 56], [430, 96], 
	[[426, 101], [421, 106], [424, 107]]]],
	[[255, 204, 0, 255],
	[[[230, 113], [240, 115], [245, 115]], [250, 116], [[256, 114], [261, 112], [258, 109]],
	[255, 106], [[245, 103], [234, 101], [222, 95]], [[222, 95], [209, 89], [198, 81]],
	[[198, 81], [186, 74], [179, 72]], [[179, 72], [171, 71], [170, 70]],
	[[170, 70], [169, 70], [167, 74]], [[167, 74], [165, 79], [169, 85]], [173, 91], [219, 112]]],
	[[255, 204, 0, 255],
	[[[296, 226], [301, 232], [302, 232]], [[302, 232], [303, 233], [314, 229]], 
	[[314, 229], [325, 225], [329, 222]], [[329, 222], [332, 219], [340, 210]],
	[348, 202], [387, 146], [395, 138], [[397, 119], [398, 101], [395, 89]], [392, 78],
	[[391, 77], [389, 76], [386, 87]], [383, 98], [[379, 95], [375, 92], [375, 87]],
	[374, 83], [374, 79], [[370, 71], [365, 63], [361, 61]], [[361, 61], [356, 60],[351, 60]],
	[[351, 60], [346, 60], [337, 62]], [[337, 62], [328, 65], [321, 74]],
	[[321, 74], [313, 83], [312, 87]], [[312, 87], [311, 91], [307, 99]],
	[[307, 99], [302, 107], [299, 120]], [296, 134], [293, 166], [291, 220]]],
	[[255, 255, 255, 255],
	[[[357, 137], [353, 137], [351, 130]], [[351, 130], [349, 124], [348, 124]],
	[[348, 124], [346, 124], [339, 129]], [332, 135], [332, 119], [[327, 121], [321, 124], [319, 127]],
	[[319, 127], [316, 130], [316, 128]], [[316, 128], [315, 126],[316, 125]],
	[[316, 125], [317, 125], [319, 122]], [[319, 122], [320, 120], [326, 117]],
	[[326, 117], [332, 114], [335, 114]], [[335, 114], [338, 115], [339, 119]],
	[340, 123], [356, 115], [360, 129], [[365, 127], [370, 126], [372, 126]],
	[[372, 126], [373, 126], [373, 127]], [[373, 127], [373, 128], [369, 129]],
	[365, 131], [[363, 134], [360, 137], [357, 137]]]],
	[[255, 204, 0, 255],
	[[[495, 241], [507, 247], [512, 247]], [[512, 247], [516, 247], [517, 243]],
	[[517, 243], [518, 240], [512, 233]], [505, 226], [433, 184],
	[[424, 180], [415, 177], [411, 177]], [[411, 177], [407, 177], [407, 181]],
	[407, 185], [427, 202], [482, 236]]]]
sflender=	[[[178, 178, 178, 255],
	[[245, 279], [259, 279], [271, 274], [[276, 269], [280, 265], [282, 259]],
	[[282, 259], [283, 254], [275, 254]], [[275, 254], [267, 254], [267, 257]],
	[266, 260], [261, 265], [[258, 266], [254, 268], [248, 268]], [[248, 268],[242, 268], [239, 266]],
	[235, 265], [[232, 261], [228, 257], [226, 249]], [224, 241], [285, 241],
	[[285, 232], [284, 224], [281, 217]], [278, 211], [273, 204], [263, 198],
	[[260, 197], [257, 196], [247, 196]], [[247, 196], [237, 196], [230, 199]],
	[[230, 199], [222, 203], [217, 211]], [[217, 211], [211, 219], [210, 228]],
	[[210, 228], [208, 238], [209, 245]], [210, 253], [215, 264], [[218, 267], [221, 271], [226, 274]],
	[231, 277]]],
	[[178, 178, 178, 255],
	[[411, 279], [[414, 279], [416, 280], [422, 278]], [[422, 278], [428, 277], [433, 272]],
	[[433, 272], [437, 268], [437, 273]], [[437, 273], [437, 278], [445, 278]],
	[452, 278], [452, 171], [452, 167], [437, 167], [437, 203], [[431, 199], [424, 196], [416, 196]],
	[[416, 196], [407, 196], [402, 198]], [396, 201], [389, 208], [383, 220],
	[[382, 234], [381, 248], [383, 254]], [[383, 254], [384, 260],[389, 266]],
	[[389, 266], [393, 273], [399, 276]], [[399, 276], [405, 279], [408, 279]]]],
	[[178, 178, 178, 255],
	[[503, 279], [517, 279], [528, 275], [[533, 271], [537, 267], [540, 260]], [542, 254],
	[[534, 254], [526, 254], [525, 257]], [524, 261], [[521, 263], [518, 266], [509, 267]],
	[[509, 267], [500, 268], [496, 265]], [491, 263], [487, 258], [483, 241], [543, 241],
	[[543, 234], [543, 227], [540, 219]], [[540, 219], [536, 211], [533, 207]],
	[530, 203], [[525, 200], [519, 197], [507, 196]], [[507, 196],[495, 196], [489, 199]],
	[482, 202], [474, 210], [[472, 214], [470, 218], [469,223]], [[469, 223], [467, 229], [467, 237]],
	[[467, 237], [467, 246], [470, 254]], [[470, 254], [473, 263], [479, 269]],
	[[479, 269], [485, 275], [491, 277]], [[491, 277], [496, 279], [500, 279]]]],
	[[178, 178, 178, 255],
	[[138, 277], [153, 278], [153, 209], [168, 209], [168, 197], [153, 197],
	[[153,191], [153, 185], [156, 181]], [[156, 181], [158, 178], [165, 178]], [172, 178],
	[[172, 172], [172, 167], [171, 166]], [[171, 166], [170, 165], [162, 165]],
	[[162, 165], [153, 165], [151, 166]], [148, 167], [[145, 170], [141, 174], [140, 178]],
	[[140, 178], [138, 182], [138, 189]], [138, 197], [126, 197], [126, 209], [138, 209]]],
	[[178, 178, 178, 255],
	[[178, 277], [194, 278], [194, 168], [178, 167]]],
	[[178, 178, 178, 255],
	[[300, 277], [315, 278], [315, 220], [323, 212], [331, 208], [[337, 208], [343,208], [347, 212]],
	[350, 216], [351, 278], [366, 278], [366, 258], [366, 218], [[363, 210], [359, 202], [354, 199]],
	[[354, 199], [348, 196], [340, 196]], [[340, 196], [331, 196], [325, 199]],
	[[325, 199], [319, 202], [317, 204]], [315, 207], [[315, 202], [315, 197], [308, 197]],
	[300, 197]]],
	[[178, 178, 178, 255],
	[[558, 277], [573, 278], [573, 221], [[580, 215], [586, 210], [594, 210]], [601, 210],
	[601, 196], [[594, 196], [587, 196], [582, 200]], [[582, 200], [576, 204], [575, 206]],
	[[575, 206], [573, 208], [573, 202]], [[573, 202], [573, 197], [566, 197]], [558, 197]]],	
	[[178, 178, 178, 255],
	[[225, 230], [227, 219], [233, 211], [241, 207], [[247, 207], [252, 207], [258,211]],
	[[258, 211], [264, 215], [267, 222]], [269, 230]]],
	[[178, 178, 178, 255],
	[[483, 230], [[485, 223], [487, 216], [490, 213]], [[490, 213], [493, 210], [497, 208]],
	[500, 207], [[506, 207], [511, 207], [517, 211]], [[517, 211], [523, 216], [525, 223]], [527, 230]]],
	[[255, 100, 0, 255],
	[[[63, 278], [72, 279], [80, 279]], [[80, 279], [88, 279], [97, 275]], [[97, 275], [106, 271], [109, 268]],
	[112, 265], [[115, 260], [117, 255], [117, 246]], [[117, 246], [117, 238], [115, 233]], [112, 228],
	[[109, 225], [105, 222], [98, 219]], [[98, 219], [91, 216], [79, 213]], [[79, 213], [66, 211], [60, 208]],
	[[60, 208], [53, 206], [51, 203]], [[51, 203], [48, 200], [49, 194]], [[49, 194], [49, 188], [53, 184]],
	[[53, 184], [56, 181], [67, 179]], [[67, 179], [77, 178], [84, 180]], [[84, 180], [91, 182], [95, 186]],
	[98, 190], [[99, 194], [100, 198],[108, 198]], [[108, 198], [115, 198], [115, 195]],
	[[115, 195], [115, 193], [112, 186]], [[112, 186], [109, 179], [105, 175]], [100, 171],
	[[96, 169], [91, 167], [77, 166]], [[77, 166], [63, 165], [58, 166]], [[58, 166], [52, 168], [45, 173]],
	[[45, 173], [37, 179], [35, 183]], [33, 187], [32, 200], [[34, 204], [35, 209], [38, 212]],
	[41, 216], [52, 222], [86, 230], [[92, 232], [97, 235], [100, 238]], [[100, 238], [102, 242], [102, 247]],
	[[102, 247], [102, 253], [97, 258]],[[97, 258], [91, 264], [79, 265]], [[79, 265], [66, 266], [58, 262]],
	[[58, 262], [50, 258], [48, 254]], [[48, 254], [45, 250], [45, 246]], [[45, 246], [44, 242], [36, 242]],
	[[36, 242], [28, 242], [29, 246]], [29, 250], [33, 261], [42, 271], [[48, 274], [54, 277], [63, 278]]]],
	[[178, 178, 178, 255],
	[[[417, 267], [410, 268], [406, 265]], [402, 262], [[400, 257], [398, 253], [398, 240]],
	[[398, 240], [397, 227], [399, 221]], [[399, 221], [401, 215], [404, 212]],
	[[404, 212], [407, 209], [415, 208]], [[415, 208], [422, 207], [430, 211]],
	[437, 216], [437, 255], [[434, 259], [430, 263], [427, 265]], [[427, 265], [423, 267], [417, 267]]]]]


Register(draw, event, bevent)