#!BPY
"""
Name: 'Torus_Knot_248'
Blender: 241
Group: 'Add'
Tip: 'Create a Torus knot in text editor.'
"""
#noeud de trefle (trefoil knot)
# by JMS  www.zoo-logique.org/

import Blender
from Blender import NMesh
from math import *
me=NMesh.GetRaw()
#drapeau indiquant qu'il n'ya pas d'uvmapping
#me.has_uvco=0
#drapeau indiquant que les facettes ne sont pas colorees
#me.has_col=0

#on peut jouer sur ces 6 parametres:

a=3 #dimension du noeud
b=1.8 #ondulation
c=2.2 #hauteur
d=0.2 #diametre du tube
nb=150 #nb d'anneaux le long du tube
np=8 #nb de points par anneau



prec=[a+b,0.0,0.0]
liste=[]
for i in range(1,nb+1):
	t=i*4*pi/nb
	r=a+b*cos(3*t/2)
	x=r*cos(t)
	y=r*sin(t)
	z=c*sin(3*t/2)
	vn=[x-prec[0],y-prec[1],z-prec[2]]
	V=sqrt(vn[0]*vn[0]+vn[1]*vn[1]+vn[2]*vn[2])
	vn=[vn[0]/V,vn[1]/V,vn[2]/V]
	st=vn[2]
	ct=sqrt(vn[0]*vn[0]+vn[1]*vn[1])
	sp=0
	cp=1
	if ct!=0:
		sp=vn[1]/ct
		cp=vn[0]/ct
	for j in range(np):
		al=j*2*pi/np
		xp=d*(cos(al)*st*cp+sin(al)*sp)+x
		yp=d*(cos(al)*st*sp-sin(al)*cp)+y
		zp=-d*cos(al)*ct+z
		liste.append([xp,yp,zp])

	prec=[x,y,z]

for point in liste:
	v=NMesh.Vert(point[0],point[1],point[2])
	me.verts.append(v)


for i in range(nb-2):
	for j in range(np):
		f=NMesh.Face()
		vx=me.verts[i*np+j]
		f.v.append(vx)
		vx=me.verts[i*np+j+1]
		f.v.append(vx)
		vx=me.verts[(i+1)*np+j+1]
		f.v.append(vx)
		vx=me.verts[(i+1)*np+j]
		f.v.append(vx)
		me.faces.append(f)

for j in range(np):
	f=NMesh.Face()
	vx=me.verts[(nb-2)*np+j]
	f.v.append(vx)
	vx=me.verts[(nb-2)*np+j+1]
	f.v.append(vx)
	vx=me.verts[j+1]
	f.v.append(vx)
	vx=me.verts[j]
	f.v.append(vx)
	me.faces.append(f)

NMesh.PutRaw(me,"Noeud",1)
Blender.Redraw()