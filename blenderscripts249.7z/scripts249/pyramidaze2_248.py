#!BPY

"""
Name: '_Pyramidaze'
Blender: 232
Group: 'Misc'
Tooltip: 'In edit mode adds a "pyramid" over every selected face'
"""

__author__ = "Ari Hayrinen"  
__url__ = ("www.opendimension.org/blender_en")
__version__ = "1.2"

__bpydoc__ = """\
pyramidize.py. 
This script adds a "pyramid" over every selected face

- Open this file in the Blender's text window
- Select faces
- set settings (see below)
- run script (Alt + P)

there is nothing special in this script but it shows how to iterate 
through all faces in selected object, how to get normal and how to create new mesh object

"""
# -------------------------------------------------------------------------- 
# pyramidaze.py 
# Copyright Ari Hayrinen 2008
# -------------------------------------------------------------------------- 
# ***** BEGIN GPL LICENSE BLOCK ***** 
# 
# This program is free software; you can redistribute it and/or 
# modify it under the terms of the GNU General Public License 
# as published by the Free Software Foundation; either version 2 
# of the License, or (at your option) any later version. 
# 
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
# GNU General Public License for more details. 
# 
# You should have received a copy of the GNU General Public License 
# along with this program; if not, write to the Free Software Foundation, 
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. 
# 
# ***** END GPL LICENCE BLOCK ***** 
# -------------------------------------------------------------------------- 
#**********************************************************************************************
#
# - This script adds a "pyramid" over every selected face
#
# - Open this file in the Blender's text window
# - Select faces
# - set settings (see below)
# - run script (Alt + P)
# 
# there is nothing special in this script but it shows how to iterate 
# through all faces in selected object, how to get normal and how to create new mesh object.
#
# Feel free to use this script any way you like, I'm sure this is very usefull ;)
#
#Ari Hayrinen 29.11.2006 (ari.hayrinen at gmail.com)
#www.opendimension.org/blender_en
#
# TODO:
# - GUI 
# 
#*************************************************************************************************

import Blender
from Blender import Mesh, Window, Mathutils
from Blender.Mathutils import *

#************************************************************************************************
# settings
#************************************************************************************************
py_height = 1       # pyramid height if use_area is 0, negative value inverts pyramid
use_area = 0        # if 1, uses face area as pyramid height
area_multi = 2      # multiplier for face area, negative values inverts pyramid
copy_location = 1   # if 1 then new object is created to the same location as original


#************************************************************************************************
#main
#************************************************************************************************

# save Editmode state so we can restore it afterwards
editmode = Window.EditMode()
# if user is in editmode, we have to change to objectmode  
if editmode: Window.EditMode(0) 

#get selected object and get mesh data from it
objekti = Blender.Object.GetSelected()
current = objekti[0]
me = current.getData(mesh=True)	

# list for new faces
coords = []
faces = []
  
# counter so we know where to add new faces 
verts = 0  

# let's go through all faces in selected object
for face in me.faces:
    #use only selected faces    
    if face.sel:

        # get normal and normalize it
        normal = Vector(face.no)
        normal.normalize()
        center = face.cent

        #number of vertices
        vco = len(face.v) 

        if use_area:
            py_height = face.area * area_multi

        
        #multiple normal with pyramid height and add result to the center of the face
        center.x = center.x + normal[0] * py_height
        center.y = center.y + normal[1] * py_height
        center.z = center.z + normal[2] * py_height
    
        #create vertices	
        coords.append([center.x,center.y,center.z])
        verts +=1

        for i in range(vco):
            coords.append([face.v[i].co[0],face.v[i].co[1],face.v[i].co[2]])
            verts +=1

      
        #create triangles
        cco = vco + 1                        # number of created vertices
        for j in range(vco):
            if j < (vco-1):
                faces.append([verts-cco, verts-(cco-(j+1)), verts-(vco-j-1)])
            else:
                faces.append([verts-cco, verts-(cco-(j+1)), verts-(cco-1)])


# Create new mesh block and add faces to it
pyrad = Mesh.New("pyra")
pyrad.verts.extend(coords)
pyrad.faces.extend(faces)

obj = Blender.Object.New("Mesh","MyPyramid")
obj.link(pyrad)

if copy_location: 
	loc = current.getLocation()
else:
    loc = Blender.Window.GetCursorPos()

obj.setLocation(loc)

sc = Blender.Scene.GetCurrent()
sc.link(obj)

#if user was in edit mode, then we should't change that
if editmode: Window.EditMode(1)

Blender.Redraw()