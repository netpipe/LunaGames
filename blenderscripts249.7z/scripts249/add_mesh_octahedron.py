#!BPY
# By Ed Montgomery (edmontgomery@hotmail.com), August 12, 2007
"""
Name: 'Octrahedron'
Blender: 244
Group: 'AddMesh'
"""
import BPyAddMesh
import Blender

def add_mymesh(PREF_WIDTH, PREF_LENGTH, PREF_HEIGHT, PREF_DEPTH):

	verts = []
	faces = []
	
	# define object vertices	
	verts.append([-(PREF_WIDTH/2),(PREF_LENGTH/2),0.0])
	verts.append([-(PREF_WIDTH/2),-(PREF_LENGTH/2),0.0])
	verts.append([(PREF_WIDTH/2),-(PREF_LENGTH/2),0.0])
	verts.append([(PREF_WIDTH/2),(PREF_LENGTH/2),0.0])
        verts.append([0.0,0.0,(PREF_HEIGHT/2)])
	verts.append([0.0,0.0,-(PREF_DEPTH/2)])
	
	# define object faces
        faces.append([0,1,2,3])
        faces.append([0,1,4])
        faces.append([1,2,4])
        faces.append([2,3,4])
        faces.append([3,0,4])
	faces.append([0,1,5])
	faces.append([1,2,5])
	faces.append([2,3,5])
	faces.append([3,0,5])
	
	return verts, faces

def main():
	
	# Numeric input with default value of 1
	octahedronWidthInput = Blender.Draw.Create(1.0)
	
	# and same for length
	octahedronLengthInput  = Blender.Draw.Create(1.0)

        # And height of octahedron
        octahedronHeightInput = Blender.Draw.Create(1.0)

	# depth of octahedron
	octahedronDepthInput = Blender.Draw.Create(1.0)

	# array for popup window's content	
	block = []
	
	# add inputs to array with title, min/max values and tooltip
	block.append(("width: ", octahedronWidthInput, 0.01, 100, "width of the octahedron"))
	block.append(("length: ", octahedronLengthInput, 0.01, 100, "length of the octahedron"))
        block.append(("height: ", octahedronHeightInput, 0.01, 100, "height of the octahedron"))
	block.append(("depth: ", octahedronDepthInput, 0.01, 100, "depth of the octahedron"))
	
	# draw	popup if it is not open allready 
	if not Blender.Draw.PupBlock("Create octahedron",block):
		return
	
        verts, faces = add_mymesh(octahedronWidthInput.val, octahedronLengthInput.val, octahedronHeightInput.val, octahedronDepthInput.val)
	
        BPyAddMesh.add_mesh_simple('Octahedron', verts, [], faces)

main()
