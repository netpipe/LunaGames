import Blender
from Blender import *
from Blender.Draw import *
from Blender.BGL import *


def write(scale, c1, c2, c3, matc, backcol, shade, data, refl, wire): #writes out a script to make the custom data then execs and removes it
	string = """
import Blender
from Blender import *
from Blender.Draw import *
from Blender.BGL import *

#################################################################################



global scale
scale = %i




#materials, there's only 3 for now, and a line material.
#RGB VALUES (between 0 and 1)
#the colors of the materials
global col1
col1 = %s # default = [.8,.8,.25] = a kinda yellow color
global col2
col2 = %s # default = .25,.25,.8] = a kinda blue color
global col3
col3 = %s # default = [.25,.8,.25] = a kinda green color

#which material to use, 0 = col1, 1 = col2, 2 = col3, 3 = cycle between 1,2 and 3
global matc
matc = %i


#color of backdrop
global backc
backc = %s
#color of backdrop lables
global labelc
labelc = 0.0,0.0,0.0
#color of text
global textc
textc = 0.0,0.0,0.0
shade = %i




global dem
dem = 2


def blDrawBack(): #draws a backdrop
	x = len(data) - 1
	highx = x * 1.5 * dem + dem
	lowx = -1.5 * dem
	highy = 1.5 * dem
	lowy = -highy
	lowz = -.05
	
	z = data[0]
	#find highest point in data
	for d in range(0, len(data)):
		if data[d] > z:
			z = data[d]	
		
	highz = z + dem
	highz = highz * 1.5
	
	points = [1,2,3,4,5,6,7] #generate verts
	points[0] = [highx, lowy, lowz]
	points[1] = [lowx, lowy, lowz]
	points[2] = [lowx, highy, lowz]
	points[3] = [highx, highy, lowz]
	points[4] = [lowx, lowy, highz]
	points[5] = [lowx, highy, highz]
	points[6] = [highx, highy, highz]
	
	#generate faces
	faces = [[0,1,2,3],[1,4,5,2],[2,5,6,3]]
	
	me = Mesh.New("Backdrop")  #new mesh
	ob = Object.New("Mesh", "Backdrop")#new object
	scn = Scene.GetCurrent()   #get scene
	
	me.verts.extend(points) #add verts
	me.faces.extend(faces)  #add faces
	
	#linking
	ob.link(me)
	scn.link(ob)
	
	ma1 = Material.New("backdrop")
	ma1.rgbCol = backc
	if refl:
		ma1.setMode("RayMirr")
		ma1.setRayMirr(.25)
	
	me.materials = [ma1]



def barDrawCube(dim, x, z, mat, line, d): #draws the graph
	add = dim / 2 #amount to add to x
	#define points
	points = [1,2,3,4,5,6,7,8]
	#base
	points[0] = [-add, add, 0]
	points[1] = [-add, -add, 0]
	points[2] = [+add, -add, 0]
	points[3] = [+add, add, 0]
	#top
	points[4] = [-add, add, z]
	points[5] = [-add, -add, z]
	points[6] = [+add, -add, z]
	points[7] = [+add, add, z]
	
	#define faces
	faces = [1,2,3,4,5,6]
	faces[0] = [0,1,2,3]
	faces[1] = [4,5,6,7]
	faces[2] = [0,4,7,3]
	faces[3] = [1,5,6,2]
	faces[4] = [1,5,4,0]
	faces[5] = [2,6,7,3]
	
	#generate intelligible name	
	name = str(x) + " bar"
	
	ob = Object.New("Mesh", name) #new object, type = mesh, name = name
	me = Mesh.New(name) #new mesh, name = name
	scn = Scene.GetCurrent() #get scene
	
	me.verts.extend(points) #add verts to new mesh
	me.faces.extend(faces) #add faces
	
	ob.link(me) #link mesh to object
	scn.link(ob) #link object to scene
	if matc > 2:
		me.materials = mat[d] #link material to mesh, cycling if set to
	else:
		me.materials = mat # link material to mesh, not cycling if not set to.
	ob.LocX = x #move to correct location
	""" % (scale, c1, c2, c3, matc, backcol, shade)
	if wire: # if we want to make an outline:
		string = string + """
	#deselect all objects
	for obj in Object.GetSelected():
		obj.sel = 0		
	#select graph object just created
	ob.sel = 1
	Object.Duplicate(1,0,0,0,0,0,0,0,0,0) #duplicate linked, make new mesh (not linked)
	lineob = Object.GetSelected()[0] #get the new object
	lime = lineob.getData(False,True) #get the new object's mesh
	lime.materials = line #set material to outline
	#scale up alittle so you can see the outline's edges better
	lineob.SizeX = 1.01
	lineob.SizeY = 1.01
	lineob.SizeZ = 1.01
		"""
	string = string + """	

def barGraph(mat, line): #calculates the graph
	
	# leave editmode if in it
	editmode = Window.EditMode()
	if editmode: Window.EditMode(0)
	
	# get box dim.
	dim = 2 * scale
	
	for d in range(0, len(data)): #for each data piece:
		# get the x location
		x = dim * 1.5 * scale * d
		# get the height (magnitude of data)
		z = data[d]
		# pass parameters and draw
		barDrawCube(dim, x, z, mat, line, d)
		
# start main function (temp, to be replaced with gui




def main():
	#color for material, to be replaced in gui
	matcol1 = Material.New("colorone")
	if not shade: matcol1.setMode("Shadeless") #make shadeless
	matcol1.setRGBCol(col1) # a yellowy color
	
	matcol2 = Material.New("colortwo")
	if not shade: matcol2.setMode("Shadeless") #make shadeless
	matcol2.setRGBCol(col2) # a bluey color
	
	matcol3 = Material.New("colorthree")
	if not shade: matcol3.setMode("Shadeless") #make shadeless
	matcol3.setRGBCol(col3) # a greeny color
	
	#outline material, again, to be replaced
	matline = Material.New("outline")
	matline.setMode("Shadeless","Wire") #make shadeless and wire
	matline.setRGBCol() #no flags = set to black
	
	
	#generate list of materials
	if matc == 0:
		mat = [[matcol1]]
	elif matc == 1:
		mat = [[matcol2]]
	elif matc == 2:
		mat = [[matcol3]]
	else:
		mat = range(0, len(data))
		a = 0
		for d in range(0, len(data)):
			if a == 3: a = 0
			if a == 0: mat[d] = [matcol1]
			if a == 1: mat[d] = [matcol2]
			if a == 2: mat[d] = [matcol3]
			a = a + 1
	
	
	line = [matline]
	
	barGraph(mat, line)
	blDrawBack()
global data
global refl
data = [%s]
refl = %i
main()
	""" % (data, refl)
	# ^^ adding back the data ^^
	# scale = to scale the graph up or down, don't use!
	# c1 - c3 = the rgb values of the three materials
	# matc = which color to use... or cycle
	# backcol = the backdrop's color
	# shade = whether or not shadeless materials
	# data = the data in string format
	# refl = whether the backdrop is reflective
	
	# make text and run
	txt = Blender.Text.New("runme.py")
	txt.write(string)
	Run("runme.py")
	# unlink text
	Blender.Text.unlink(txt)