#!BPY

import Blender
from Blender import BGL, Draw, Window
from Blender.BGL import *

#import numpy
#from numpy import array

"""
DESCRIPTION
This class provides the user interface for a pseudo-interactive panel. The
panel displays a somewhat accurate representation of a wave-form.
"""
class WaveFormPanel:

  # Define the (x, y) and (width, height) parameters that define the size
  # of the canvas upon which the curve is plotted.
  #
  __canvas_x = 520
  __canvas_y = 5
  __canvas_w = 500
  __canvas_h = 230

  __samples = []

  # Minimum and maximum wave form values
  #
  __minPeak = 0
  __maxPeak = 32768

  # Defines the threshold lines
  #
  __minThreshold = __minPeak
  __maxThreshold = __maxPeak

  # Colour definitions for the minimum and maximum lines.
  #
  min_R = 0
  min_G = 1
  min_B = 0
  max_R = 1
  max_G = 0
  max_B = 0

  bg_R = bg_G = bg_B = 0
  fg_R = fg_G = fg_B = 1

  """
  DESCRIPTION
  Sets the (x, y) coordinates of the canvas.
  """
  def setCanvasLocation( self, x, y ):
    self.__canvas_x = x
    self.__canvas_y = y

  """
  DESCRIPTION
  Sets the width of the canvas.
  """
  def setCanvasWidth( self, w ):
    self.__canvas_w = w

  """
  DESCRIPTION
  Sets the height of the canvas.
  """
  def setCanvasHeight( self, h ):
    self.__canvas_h = h

  """
  DESCRIPTION
  Returns the location of the canvas along the horizontal, in pixels.
  """
  def getCanvasX( self ):
    return self.__canvas_x

  """
  DESCRIPTION
  Returns the location of the canvas along the vertical, in pixels.
  """
  def getCanvasY( self ):
    return self.__canvas_y

  """
  DESCRIPTION
  Returns the width of the canvas, in pixels.
  """
  def getCanvasWidth( self ):
    return self.__canvas_w

  """
  DESCRIPTION
  Returns the height of the canvas, in pixels.
  """
  def getCanvasHeight( self ):
    return self.__canvas_h

  """
  DESCRIPTION
  Sets the sample data to use for drawing the wave form.
  """
  def setSamples( self, samples ):
    self.__samples = samples

  """
  DESCRIPTION
  Returns the sample data to use for drawing the wave form.
  """
  def getSamples( self ):
    return self.__samples

  """
  DESCRIPTION
  Sets the minimum and maximum extents from the sample data.
  """
  def setPeaks( self, minPeak, maxPeak ):
    self.setMinPeak( minPeak )
    self.setMaxPeak( maxPeak )

  """
  DESCRIPTION
  Sets the minimum peak value (from the sample data).
  """
  def setMinPeak( self, minPeak ):
    self.__minPeak = minPeak
    self.setMinThreshold( minPeak )

  """
  DESCRIPTION
  Returns the minimum peak value.
  """
  def getMinPeak( self ):
    return self.__minPeak

  """
  DESCRIPTION
  Sets the maximum peak value (from the sample data).
  """
  def setMaxPeak( self, maxPeak ):
    self.__maxPeak = maxPeak
    self.setMaxThreshold( maxPeak )

  """
  DESCRIPTION
  Returns the maximum peak value.
  """
  def getMaxPeak( self ):
    return self.__maxPeak

  """
  DESCRIPTION
  Returns the ratio of the maximum peak to the canvas height. This allows
  the threshold lines to be drawn relative to the scaled size of the wave
  form.
  """
  def getPixelScale( self ):
    return float( self.getMaxPeak() ) / self.getCanvasHeight()

  """
  DESCRIPTION
  Sets the minimum threshold value; used to draw the min threshold line.
  """
  def setMinThreshold( self, minThreshold ):
    self.__minThreshold = minThreshold
    self.draw()

  """
  DESCRIPTION
  Returns the minimum threshold value; used to draw the min threshold line.
  """
  def getMinThreshold( self ):
    return self.__minThreshold

  """
  DESCRIPTION
  Sets the maximum threshold value; used to draw the max threshold line.
  """
  def setMaxThreshold( self, maxThreshold ):
    self.__maxThreshold = maxThreshold
    self.draw()

  """
  DESCRIPTION
  Returns the maximum threshold value; used to draw the max threshold line.
  """
  def getMaxThreshold( self ):
    return self.__maxThreshold

  """
  DESCRIPTION
  Resizes the given value so that it fits to the canvas height.

  PARAMETERS
  value - A value from the sample data

  RETURNS
  The given value scaled with respect to the canvas height.
  """
  def scaleToHeight( self, value ):
    return (float( value ) / self.getMaxPeak()) * self.getCanvasHeight()

  """
  DESCRIPTION
  Change the drawing colour to the background colour.
  """
  def useBackgroundColour( self ):
    glColor3f( self.bg_R, self.bg_G, self.bg_B )

  """
  DESCRIPTION
  Change the drawing colour to the foreground colour.
  """
  def useForegroundColour( self ):
    glColor3f( self.fg_R, self.fg_G, self.fg_B )

  """
  DESCRIPTION
  Change the drawing colour to the minimum threhold line colour.
  """
  def useMinimumColour( self ):
    glColor3f( self.min_R, self.min_G, self.min_B )

  """
  DESCRIPTION
  Change the drawing colour to the maximum threhold line colour.
  """
  def useMaximumColour( self ):
    glColor3f( self.max_R, self.max_G, self.max_B )

  """
  DESCRIPTION
  Free the sample data from memory.
  """
  def clearSamples( self ):
    self.__samples = []

  """
  DESCRIPTION
  Add a new sample into the samples array. The index is unused. This method
  is called from AudioAnalysis (as set up in AudioAnalysisUI) whenever a new
  piece of sample data has been read from disk.
  """
  def appendSample( self, index, value ):
    samples = self.getSamples()
    samples.append( value )

  """
  DESCRIPTION
  Redraws the canvas.
  """
  def draw( self ):
    self.drawBackground()
    self.drawSamples()
    self.drawThresholds()

  """
  DESCRIPTION
  Using the current location and dimensions, this redraws the background.
  """
  def drawBackground( self ):
    x1 = self.getCanvasX()
    y1 = self.getCanvasY()
    x2 = x1 + self.getCanvasWidth()
    y2 = y1 + self.getCanvasHeight()

    self.useBackgroundColour()
    glRectf( x1, y1, x2, y2 )

  """
  DESCRIPTION
  Draws the wave form, defined by the sample data.
  """
  def drawSamples( self ):
    x = self.getCanvasX()
    y = self.getCanvasY()

    scaleHeight = self.getCanvasHeight()
    scaleWidth = self.getCanvasWidth()
    samples = self.getSamples()
    numSamples = len( samples )
    stepSamples = float( numSamples / scaleWidth )

    if stepSamples < 1:
      stepSamples = 1

    self.useForegroundColour()

    glBegin( GL_LINE_STRIP )
    count = 0

    for i in range( 0, numSamples, int( stepSamples ) ):
      glVertex2i( x + count, y + int( self.scaleToHeight( samples[ i ] ) ) )
      count += 1

    glEnd()

  """
  DESCRIPTION
  Draws a threshold line at the given value. The value must be within the
  limits of the sample data. The value is scaled to fit the height of the
  canvas.
  """
  def drawThreshold( self, value ):
    x = self.getCanvasX()
    y = self.getCanvasY()
    value = int( self.scaleToHeight( value ) )

    glBegin( GL_LINE_STRIP )
    glVertex2i( x, y + value )
    glVertex2i( x + self.getCanvasWidth(), y + value )
    glEnd()

  """
  DESCRIPTION
  Draws the minimum and maximum threshold lines.
  """
  def drawThresholds( self ):
    self.drawThresholdMinimum()
    self.drawThresholdMaximum()

  """
  DESCRIPTION
  Colours and draws the minimum threshold line.
  """
  def drawThresholdMinimum( self ):
    self.useMinimumColour()
    self.drawThreshold( self.getMinThreshold() )

  """
  DESCRIPTION
  Colours and draws the maximum threshold line.
  """
  def drawThresholdMaximum( self ):
    self.useMaximumColour()
    self.drawThreshold( self.getMaxThreshold() )

