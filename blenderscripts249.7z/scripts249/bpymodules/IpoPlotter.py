import sys, random, string, Blender
from Blender import Ipo, Scene, Camera, Lamp, Material, Object, Texture, World

"""
DESCRIPTION
This class is responsible for converting a set of sample data into an Ipo
curve.
"""
class IpoPlotter:
  IPO_TYPE_NAMES = [
    'Action', 'Camera', 'Constraint', 'Curve', 'Key', 'Lamp', \
    'Material', 'Object', 'Sequence', 'Texture', 'World'
  ]

  # IPO_TYPE_NAMES index.
  #
  __ipoType = 0

  # Corresponding curve type for a given Ipo type (e.g., Energ, Lens).
  #
  __curveType = 'Energ'

  # Minimum and maximum possible values for the data. These are used when
  # converting the actual data values into Blender's Ipo data values. The
  # scaling then affects the converted value. Technically, we could derive
  # these values from analysing the __plotData list, but that would take
  # a lot of time ...
  #
  __dataPointMin = 0
  __dataPointMax = 65535
  __framesPerSec = 25

  # The maximum data point value becomes this value, the minimum becomes 0,
  # and the rest fall somewhere in between.
  #
  __scale          = 100.0

  __attack         = 0.0
  __decay          = 0.0
  __oscillateDecay = 0.0
  __rndAttack      = False
  __rndDecay       = False
  __rndOscillate   = False

  __name           = 'WavIpo'

  __plotData = []

  def __init__( self ):
    pass

  """
  DESCRIPTION
  Sets the string name that corresponds to the selected curve type.
  For example, 'Energ' (for a 'Lamp'). No cross-checking is performed;
  caveat emptor!
  """
  def setCurveType( self, curveType ):
    self.__curveType = curveType

  """
  DESCRIPTION
  Returns the string name that corresponds to the selected curve type.
  For example, 'Energ' (for a 'Lamp').
  """
  def getCurveType( self ):
    return self.__curveType
  
  """
  DESCRIPTION
  Returns a list of human-readable names. For example, 'Lamp', 'Object',
  'Material', etc.
  """
  def getIpoTypeNames( self ):
    return self.IPO_TYPE_NAMES

  """
  DESCRIPTION
  Returns a specific human-readable name for an IpoType. For example,
  'Lamp', 'Object', 'Material', etc.
  """
  def getIpoTypeName( self ):
    return self.IPO_TYPE_NAMES[ self.getIpoType() ]

  """
  DESCRIPTION
  Sets the index into the IPO_TYPE_NAMES list, which should correspond to
  an available IpoType name.
  """
  def setIpoType( self, ipoType ):
    self.__ipoType = ipoType

  """
  DESCRIPTION
  Returns the index into the IPO_TYPE_NAMES list, which should correspond to
  an available IpoType name.
  """
  def getIpoType( self ):
    return self.__ipoType

  """
  DESCRIPTION
  When greater than zero, every data point is preceeded by a point whose
  amplitude is 0 and whose distance from the data point is equal to the
  number of frames corresponding to the attack time (given in seconds).
  """
  def setAttack( self, attack ):
    self.__attack = attack

  def getAttack( self ):
    return self.__attack

  """
  DESCRIPTION
  When greater than zero, every data point is superceded by a point whose
  amplitude is 0 and whose distance from the data point is equal to the
  number of frames corresponding to the decay time (given in seconds).
  """
  def setDecay( self, decay ):
    self.__decay = decay

  def getDecay( self ):
    return self.__decay

  def setScale( self, scale ):
    self.__scale = scale

  def getScale( self ):
    return self.__scale

  def setOscillateDecay( self, oscillateDecay ):
    self.__oscillateDecay = oscillateDecay

  def getOscillateDecay( self ):
    return self.__oscillateDecay

  def setRandomAttack( self, rndAttack ):
    self.__rndAttack = rndAttack

  def getRandomAttack( self ):
    return self.__rndAttack

  def setRandomDecay( self, rndDecay ):
    self.__rndDecay = rndDecay

  def getRandomDecay( self ):
    return self.__rndDecay

  def setRandomOscillate( self, rndOscillate ):
    self.__rndOscillate = rndOscillate

  def getRandomOscillate( self ):
    return self.__rndOscillate

  """
  DESCRIPTION
  Sets the user-defined name for the Ipo curve.
  """
  def setName( self, ipoName ):
    self.__ipoName = ipoName

  """
  DESCRIPTION
  Returns the user-defined name for the Ipo curve.
  """
  def getName( self ):
    return self.__ipoName

  """
  DESCRIPTION
  Sets the data to use for plotting an Ipo curve. The data should be
  untouched, yet ready for massaging.
  """
  def setPlotData( self, plotData ):
    self.__plotData = plotData

  """
  DESCRIPTION
  Returns the data to use for plotting an Ipo curve.
  """
  def getPlotData( self ):
    return self.__plotData

  def setDataPointMin( self, dataPointMin ):
    self.__dataPointMin = dataPointMin

  def getDataPointMin( self ):
    return self.__dataPointMin

  def setDataPointMax( self, dataPointMax ):
    self.__dataPointMax = dataPointMax

  def getDataPointMax( self ):
    return self.__dataPointMax

  def setFramesPerSecond( self, fps ):
    self.__framesPerSec = fps

  def getFramesPerSecond( self ):
    return self.__framesPerSec

  """
  DESCRIPTION
  Converts the given number from seconds to a frame number.
  """
  def __convertFrameUnits( self, seconds ):
    return int( round( seconds * self.getFramesPerSecond() ) )

  """
  DESCRIPTION
  Converts the given power value so it fits within the desired scale.
  """
  def __convertPowerUnits( self, power ):
    min = self.getDataPointMin()
    return ((power - min) / (self.getDataPointMax() - min)) * self.getScale()

  """
  DESCRIPTION
  Creates an Ipo curve based on the type selected by the user.
  """
  def __createCurve( self ):
    ipo = Ipo.New( self.getIpoTypeName(), self.getName() )
    curve = ipo.addCurve( self.getCurveType() )

    curve.setInterpolation( 'Bezier' )
    curve.addBezier( (0, 0) )

    return curve

  """
  DESCRIPTION
  Creates an Ipo curve based on the data returned from getPlotData().
  """
  def plot( self ):
    curve = self.__createCurve()

    attack = self.__convertFrameUnits( self.getAttack() )
    decay  = self.__convertFrameUnits( self.getDecay() )

    prevFrame = 0

    # Add a starting data point to ensure the first attack value behaves.
    #
    curve.addBezier( (0, 0) )

    frame = 0

    for tuple in self.getPlotData():
      # Plot Data is currently in seconds per amplitude; it must be converted
      # into frames per amplitude.
      #
      frame = self.__convertFrameUnits( float( tuple[0] ) )
      amplitude = self.__convertPowerUnits( float( tuple[1] ) )

      # Plot the attack, data point, and decay values.
      #
      if attack > 0:
        curve.addBezier( (frame - attack, 0) )

      curve.addBezier( (frame, amplitude) )

      if decay > 0:
        curve.addBezier( (frame + decay, 0) )

    # Add an ending data point to ensure the curve is reset.
    #
    if frame > 0:
      curve.addBezier( (frame + decay + 1, 0) )

    curve.update()
    Blender.Redraw()

