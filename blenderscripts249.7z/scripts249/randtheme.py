#!BPY

# RANDOM THEMER
# Will generate a theme with random colors, sizes, and button styles
# Try Setting 'Gray' to True (or a non-zero number) to get Gray Themes

# Copyright 2008, Kevin Morgan
# -------------------------------------------------------------------------- 
# ***** BEGIN GPL LICENSE BLOCK ***** 
# 
# This program is free software; you can redistribute it and/or 
# modify it under the terms of the GNU General Public License 
# as published by the Free Software Foundation; either version 2 
# of the License, or (at your option) any later version. 
# 
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the 
# GNU General Public License for more details. 
# 
# You should have received a copy of the GNU General Public License 
# along with this program; if not, write to the Free Software Foundation, 
# Inc., 59 Temple Place - Suite 330, Boston, MA	02111-1307, USA. 
# 
# ***** END GPL LICENCE BLOCK ***** 
# --------------------------------------------------------------------------


import Blender
from Blender.Window import Theme
from Blender.Noise import random

theme = Theme.Get()[0]

# Set to True to restrict colors to grays
Gray = False

if Gray:
	ui = theme.get('ui')

	num = int(random()*255)
	ui.action = [num, num, num, 255]
	ui.drawType = int(random() * 4)

	num = int(random()*255)
	ui.menu_back = [num, num, num, 255]

	num = int(random()*255)
	ui.menu_hilite = [num, num, num, 255]

	num = int(random()*255)
	ui.menu_item = [num, num, num, 255]

	num = int(random()*255)
	ui.menu_text = [num, num, num, 255]

	num = int(random()*255)
	ui.menu_text_hi = [num, num, num, 255]

	num = int(random()*255)
	ui.neutral = [num, num, num, 255]

	num = int(random()*255)
	ui.num = [num, num, num, 255]

	num = int(random()*255)
	ui.outline = [num, num, num, 255]

	num = int(random()*255)
	ui.popup = [num, num, num, 255]

	num = int(random()*255)
	ui.setting = [num, num, num, 255]

	num = int(random()*255)
	ui.setting1 = [num, num, num, 255]

	num = int(random()*255)
	ui.setting2 = [num, num, num, 255]

	num = int(random()*255)
	ui.text = [num, num, num, 255]

	num = int(random()*255)
	ui.text_hi = [num, num, num, 255]

	num = int(random()*255)
	ui.textfield = [num, num, num, 255]

	num = int(random()*255)
	ui.textfield_hi = [num, num, num, 255]
	buts = theme.get('buts')

	num = int(random()*255)
	buts.active = [num, num, num, 255]

	num = int(random()*255)
	buts.audio = [num, num, num, 255]

	num = int(random()*255)
	buts.back = [num, num, num, 255]

	num = int(random()*255)
	buts.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	buts.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	buts.edge = [num, num, num, 255]

	num = int(random()*255)
	buts.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	buts.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	buts.edge_select = [num, num, num, 255]

	num = int(random()*255)
	buts.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	buts.effect = [num, num, num, 255]

	num = int(random()*255)
	buts.face = [num, num, num, 255]

	num = int(random()*255)
	buts.face_dot = [num, num, num, 255]

	num = int(random()*255)
	buts.face_select = [num, num, num, 255]
	buts.facedot_size = int(random() * 10)

	num = int(random()*255)
	buts.grid = [num, num, num, 255]

	num = int(random()*255)
	buts.group = [num, num, num, 255]

	num = int(random()*255)
	buts.group_active = [num, num, num, 255]

	num = int(random()*255)
	buts.header = [num, num, num, 255]

	num = int(random()*255)
	buts.hilite = [num, num, num, 255]

	num = int(random()*255)
	buts.image = [num, num, num, 255]

	num = int(random()*255)
	buts.lamp = [num, num, num, 255]

	num = int(random()*255)
	buts.meta = [num, num, num, 255]

	num = int(random()*255)
	buts.movie = [num, num, num, 255]

	num = int(random()*255)
	buts.normal = [num, num, num, 255]

	num = int(random()*255)
	buts.panel = [num, num, num, 255]

	num = int(random()*255)
	buts.plugin = [num, num, num, 255]

	num = int(random()*255)
	buts.scene = [num, num, num, 255]

	num = int(random()*255)
	buts.select = [num, num, num, 255]

	num = int(random()*255)
	buts.shade1 = [num, num, num, 255]

	num = int(random()*255)
	buts.shade2 = [num, num, num, 255]

	num = int(random()*255)
	buts.strip = [num, num, num, 255]

	num = int(random()*255)
	buts.strip_select = [num, num, num, 255]

	num = int(random()*255)
	buts.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	buts.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	buts.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	buts.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	buts.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	buts.text = [num, num, num, 255]

	num = int(random()*255)
	buts.text_hi = [num, num, num, 255]

	num = int(random()*255)
	buts.transform = [num, num, num, 255]

	num = int(random()*255)
	buts.transition = [num, num, num, 255]

	num = int(random()*255)
	buts.vertex = [num, num, num, 255]

	num = int(random()*255)
	buts.vertex_select = [num, num, num, 255]
	buts.vertex_size = int(random() * 10)

	num = int(random()*255)
	buts.wire = [num, num, num, 255]
	view3d = theme.get('view3d')

	num = int(random()*255)
	view3d.active = [num, num, num, 255]

	num = int(random()*255)
	view3d.audio = [num, num, num, 255]

	num = int(random()*255)
	view3d.back = [num, num, num, 255]

	num = int(random()*255)
	view3d.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	view3d.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	view3d.edge = [num, num, num, 255]

	num = int(random()*255)
	view3d.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	view3d.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	view3d.edge_select = [num, num, num, 255]

	num = int(random()*255)
	view3d.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	view3d.effect = [num, num, num, 255]

	num = int(random()*255)
	view3d.face = [num, num, num, 255]

	num = int(random()*255)
	view3d.face_dot = [num, num, num, 255]

	num = int(random()*255)
	view3d.face_select = [num, num, num, 255]
	view3d.facedot_size = int(random() * 10)

	num = int(random()*255)
	view3d.grid = [num, num, num, 255]

	num = int(random()*255)
	view3d.group = [num, num, num, 255]

	num = int(random()*255)
	view3d.group_active = [num, num, num, 255]

	num = int(random()*255)
	view3d.header = [num, num, num, 255]

	num = int(random()*255)
	view3d.hilite = [num, num, num, 255]

	num = int(random()*255)
	view3d.image = [num, num, num, 255]

	num = int(random()*255)
	view3d.lamp = [num, num, num, 255]

	num = int(random()*255)
	view3d.meta = [num, num, num, 255]

	num = int(random()*255)
	view3d.movie = [num, num, num, 255]

	num = int(random()*255)
	view3d.normal = [num, num, num, 255]

	num = int(random()*255)
	view3d.panel = [num, num, num, 255]

	num = int(random()*255)
	view3d.plugin = [num, num, num, 255]

	num = int(random()*255)
	view3d.scene = [num, num, num, 255]

	num = int(random()*255)
	view3d.select = [num, num, num, 255]

	num = int(random()*255)
	view3d.shade1 = [num, num, num, 255]

	num = int(random()*255)
	view3d.shade2 = [num, num, num, 255]

	num = int(random()*255)
	view3d.strip = [num, num, num, 255]

	num = int(random()*255)
	view3d.strip_select = [num, num, num, 255]

	num = int(random()*255)
	view3d.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	view3d.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	view3d.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	view3d.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	view3d.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	view3d.text = [num, num, num, 255]

	num = int(random()*255)
	view3d.text_hi = [num, num, num, 255]

	num = int(random()*255)
	view3d.transform = [num, num, num, 255]

	num = int(random()*255)
	view3d.transition = [num, num, num, 255]

	num = int(random()*255)
	view3d.vertex = [num, num, num, 255]

	num = int(random()*255)
	view3d.vertex_select = [num, num, num, 255]
	view3d.vertex_size = int(random() * 10)

	num = int(random()*255)
	view3d.wire = [num, num, num, 255]
	file = theme.get('file')

	num = int(random()*255)
	file.active = [num, num, num, 255]

	num = int(random()*255)
	file.audio = [num, num, num, 255]

	num = int(random()*255)
	file.back = [num, num, num, 255]

	num = int(random()*255)
	file.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	file.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	file.edge = [num, num, num, 255]

	num = int(random()*255)
	file.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	file.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	file.edge_select = [num, num, num, 255]

	num = int(random()*255)
	file.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	file.effect = [num, num, num, 255]

	num = int(random()*255)
	file.face = [num, num, num, 255]

	num = int(random()*255)
	file.face_dot = [num, num, num, 255]

	num = int(random()*255)
	file.face_select = [num, num, num, 255]
	file.facedot_size = int(random() * 10)

	num = int(random()*255)
	file.grid = [num, num, num, 255]

	num = int(random()*255)
	file.group = [num, num, num, 255]

	num = int(random()*255)
	file.group_active = [num, num, num, 255]

	num = int(random()*255)
	file.header = [num, num, num, 255]

	num = int(random()*255)
	file.hilite = [num, num, num, 255]

	num = int(random()*255)
	file.image = [num, num, num, 255]

	num = int(random()*255)
	file.lamp = [num, num, num, 255]

	num = int(random()*255)
	file.meta = [num, num, num, 255]

	num = int(random()*255)
	file.movie = [num, num, num, 255]

	num = int(random()*255)
	file.normal = [num, num, num, 255]

	num = int(random()*255)
	file.panel = [num, num, num, 255]

	num = int(random()*255)
	file.plugin = [num, num, num, 255]

	num = int(random()*255)
	file.scene = [num, num, num, 255]

	num = int(random()*255)
	file.select = [num, num, num, 255]

	num = int(random()*255)
	file.shade1 = [num, num, num, 255]

	num = int(random()*255)
	file.shade2 = [num, num, num, 255]

	num = int(random()*255)
	file.strip = [num, num, num, 255]

	num = int(random()*255)
	file.strip_select = [num, num, num, 255]

	num = int(random()*255)
	file.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	file.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	file.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	file.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	file.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	file.text = [num, num, num, 255]

	num = int(random()*255)
	file.text_hi = [num, num, num, 255]

	num = int(random()*255)
	file.transform = [num, num, num, 255]

	num = int(random()*255)
	file.transition = [num, num, num, 255]

	num = int(random()*255)
	file.vertex = [num, num, num, 255]

	num = int(random()*255)
	file.vertex_select = [num, num, num, 255]
	file.vertex_size = int(random() * 10)

	num = int(random()*255)
	file.wire = [num, num, num, 255]
	ipo = theme.get('ipo')

	num = int(random()*255)
	ipo.active = [num, num, num, 255]

	num = int(random()*255)
	ipo.audio = [num, num, num, 255]

	num = int(random()*255)
	ipo.back = [num, num, num, 255]

	num = int(random()*255)
	ipo.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	ipo.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	ipo.edge = [num, num, num, 255]

	num = int(random()*255)
	ipo.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	ipo.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	ipo.edge_select = [num, num, num, 255]

	num = int(random()*255)
	ipo.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	ipo.effect = [num, num, num, 255]

	num = int(random()*255)
	ipo.face = [num, num, num, 255]

	num = int(random()*255)
	ipo.face_dot = [num, num, num, 255]

	num = int(random()*255)
	ipo.face_select = [num, num, num, 255]
	ipo.facedot_size = int(random() * 10)

	num = int(random()*255)
	ipo.grid = [num, num, num, 255]

	num = int(random()*255)
	ipo.group = [num, num, num, 255]

	num = int(random()*255)
	ipo.group_active = [num, num, num, 255]

	num = int(random()*255)
	ipo.header = [num, num, num, 255]

	num = int(random()*255)
	ipo.hilite = [num, num, num, 255]

	num = int(random()*255)
	ipo.image = [num, num, num, 255]

	num = int(random()*255)
	ipo.lamp = [num, num, num, 255]

	num = int(random()*255)
	ipo.meta = [num, num, num, 255]

	num = int(random()*255)
	ipo.movie = [num, num, num, 255]

	num = int(random()*255)
	ipo.normal = [num, num, num, 255]

	num = int(random()*255)
	ipo.panel = [num, num, num, 255]

	num = int(random()*255)
	ipo.plugin = [num, num, num, 255]

	num = int(random()*255)
	ipo.scene = [num, num, num, 255]

	num = int(random()*255)
	ipo.select = [num, num, num, 255]

	num = int(random()*255)
	ipo.shade1 = [num, num, num, 255]

	num = int(random()*255)
	ipo.shade2 = [num, num, num, 255]

	num = int(random()*255)
	ipo.strip = [num, num, num, 255]

	num = int(random()*255)
	ipo.strip_select = [num, num, num, 255]

	num = int(random()*255)
	ipo.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	ipo.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	ipo.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	ipo.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	ipo.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	ipo.text = [num, num, num, 255]

	num = int(random()*255)
	ipo.text_hi = [num, num, num, 255]

	num = int(random()*255)
	ipo.transform = [num, num, num, 255]

	num = int(random()*255)
	ipo.transition = [num, num, num, 255]

	num = int(random()*255)
	ipo.vertex = [num, num, num, 255]

	num = int(random()*255)
	ipo.vertex_select = [num, num, num, 255]
	ipo.vertex_size = int(random() * 10)

	num = int(random()*255)
	ipo.wire = [num, num, num, 255]
	info = theme.get('info')

	num = int(random()*255)
	info.active = [num, num, num, 255]

	num = int(random()*255)
	info.audio = [num, num, num, 255]

	num = int(random()*255)
	info.back = [num, num, num, 255]

	num = int(random()*255)
	info.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	info.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	info.edge = [num, num, num, 255]

	num = int(random()*255)
	info.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	info.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	info.edge_select = [num, num, num, 255]

	num = int(random()*255)
	info.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	info.effect = [num, num, num, 255]

	num = int(random()*255)
	info.face = [num, num, num, 255]

	num = int(random()*255)
	info.face_dot = [num, num, num, 255]

	num = int(random()*255)
	info.face_select = [num, num, num, 255]
	info.facedot_size = int(random() * 10)

	num = int(random()*255)
	info.grid = [num, num, num, 255]

	num = int(random()*255)
	info.group = [num, num, num, 255]

	num = int(random()*255)
	info.group_active = [num, num, num, 255]

	num = int(random()*255)
	info.header = [num, num, num, 255]

	num = int(random()*255)
	info.hilite = [num, num, num, 255]

	num = int(random()*255)
	info.image = [num, num, num, 255]

	num = int(random()*255)
	info.lamp = [num, num, num, 255]

	num = int(random()*255)
	info.meta = [num, num, num, 255]

	num = int(random()*255)
	info.movie = [num, num, num, 255]

	num = int(random()*255)
	info.normal = [num, num, num, 255]

	num = int(random()*255)
	info.panel = [num, num, num, 255]

	num = int(random()*255)
	info.plugin = [num, num, num, 255]

	num = int(random()*255)
	info.scene = [num, num, num, 255]

	num = int(random()*255)
	info.select = [num, num, num, 255]

	num = int(random()*255)
	info.shade1 = [num, num, num, 255]

	num = int(random()*255)
	info.shade2 = [num, num, num, 255]

	num = int(random()*255)
	info.strip = [num, num, num, 255]

	num = int(random()*255)
	info.strip_select = [num, num, num, 255]

	num = int(random()*255)
	info.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	info.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	info.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	info.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	info.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	info.text = [num, num, num, 255]

	num = int(random()*255)
	info.text_hi = [num, num, num, 255]

	num = int(random()*255)
	info.transform = [num, num, num, 255]

	num = int(random()*255)
	info.transition = [num, num, num, 255]

	num = int(random()*255)
	info.vertex = [num, num, num, 255]

	num = int(random()*255)
	info.vertex_select = [num, num, num, 255]
	info.vertex_size = int(random() * 10)

	num = int(random()*255)
	info.wire = [num, num, num, 255]
	sound = theme.get('sound')

	num = int(random()*255)
	sound.active = [num, num, num, 255]

	num = int(random()*255)
	sound.audio = [num, num, num, 255]

	num = int(random()*255)
	sound.back = [num, num, num, 255]

	num = int(random()*255)
	sound.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	sound.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	sound.edge = [num, num, num, 255]

	num = int(random()*255)
	sound.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	sound.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	sound.edge_select = [num, num, num, 255]

	num = int(random()*255)
	sound.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	sound.effect = [num, num, num, 255]

	num = int(random()*255)
	sound.face = [num, num, num, 255]

	num = int(random()*255)
	sound.face_dot = [num, num, num, 255]

	num = int(random()*255)
	sound.face_select = [num, num, num, 255]
	sound.facedot_size = int(random() * 10)

	num = int(random()*255)
	sound.grid = [num, num, num, 255]

	num = int(random()*255)
	sound.group = [num, num, num, 255]

	num = int(random()*255)
	sound.group_active = [num, num, num, 255]

	num = int(random()*255)
	sound.header = [num, num, num, 255]

	num = int(random()*255)
	sound.hilite = [num, num, num, 255]

	num = int(random()*255)
	sound.image = [num, num, num, 255]

	num = int(random()*255)
	sound.lamp = [num, num, num, 255]

	num = int(random()*255)
	sound.meta = [num, num, num, 255]

	num = int(random()*255)
	sound.movie = [num, num, num, 255]

	num = int(random()*255)
	sound.normal = [num, num, num, 255]

	num = int(random()*255)
	sound.panel = [num, num, num, 255]

	num = int(random()*255)
	sound.plugin = [num, num, num, 255]

	num = int(random()*255)
	sound.scene = [num, num, num, 255]

	num = int(random()*255)
	sound.select = [num, num, num, 255]

	num = int(random()*255)
	sound.shade1 = [num, num, num, 255]

	num = int(random()*255)
	sound.shade2 = [num, num, num, 255]

	num = int(random()*255)
	sound.strip = [num, num, num, 255]

	num = int(random()*255)
	sound.strip_select = [num, num, num, 255]

	num = int(random()*255)
	sound.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	sound.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	sound.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	sound.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	sound.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	sound.text = [num, num, num, 255]

	num = int(random()*255)
	sound.text_hi = [num, num, num, 255]

	num = int(random()*255)
	sound.transform = [num, num, num, 255]

	num = int(random()*255)
	sound.transition = [num, num, num, 255]

	num = int(random()*255)
	sound.vertex = [num, num, num, 255]

	num = int(random()*255)
	sound.vertex_select = [num, num, num, 255]
	sound.vertex_size = int(random() * 10)

	num = int(random()*255)
	sound.wire = [num, num, num, 255]
	action = theme.get('action')

	num = int(random()*255)
	action.active = [num, num, num, 255]

	num = int(random()*255)
	action.audio = [num, num, num, 255]

	num = int(random()*255)
	action.back = [num, num, num, 255]

	num = int(random()*255)
	action.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	action.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	action.edge = [num, num, num, 255]

	num = int(random()*255)
	action.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	action.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	action.edge_select = [num, num, num, 255]

	num = int(random()*255)
	action.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	action.effect = [num, num, num, 255]

	num = int(random()*255)
	action.face = [num, num, num, 255]

	num = int(random()*255)
	action.face_dot = [num, num, num, 255]

	num = int(random()*255)
	action.face_select = [num, num, num, 255]
	action.facedot_size = int(random() * 10)

	num = int(random()*255)
	action.grid = [num, num, num, 255]

	num = int(random()*255)
	action.group = [num, num, num, 255]

	num = int(random()*255)
	action.group_active = [num, num, num, 255]

	num = int(random()*255)
	action.header = [num, num, num, 255]

	num = int(random()*255)
	action.hilite = [num, num, num, 255]

	num = int(random()*255)
	action.image = [num, num, num, 255]

	num = int(random()*255)
	action.lamp = [num, num, num, 255]

	num = int(random()*255)
	action.meta = [num, num, num, 255]

	num = int(random()*255)
	action.movie = [num, num, num, 255]

	num = int(random()*255)
	action.normal = [num, num, num, 255]

	num = int(random()*255)
	action.panel = [num, num, num, 255]

	num = int(random()*255)
	action.plugin = [num, num, num, 255]

	num = int(random()*255)
	action.scene = [num, num, num, 255]

	num = int(random()*255)
	action.select = [num, num, num, 255]

	num = int(random()*255)
	action.shade1 = [num, num, num, 255]

	num = int(random()*255)
	action.shade2 = [num, num, num, 255]

	num = int(random()*255)
	action.strip = [num, num, num, 255]

	num = int(random()*255)
	action.strip_select = [num, num, num, 255]

	num = int(random()*255)
	action.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	action.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	action.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	action.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	action.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	action.text = [num, num, num, 255]

	num = int(random()*255)
	action.text_hi = [num, num, num, 255]

	num = int(random()*255)
	action.transform = [num, num, num, 255]

	num = int(random()*255)
	action.transition = [num, num, num, 255]

	num = int(random()*255)
	action.vertex = [num, num, num, 255]

	num = int(random()*255)
	action.vertex_select = [num, num, num, 255]
	action.vertex_size = int(random() * 10)

	num = int(random()*255)
	action.wire = [num, num, num, 255]
	nla = theme.get('nla')

	num = int(random()*255)
	nla.active = [num, num, num, 255]

	num = int(random()*255)
	nla.audio = [num, num, num, 255]

	num = int(random()*255)
	nla.back = [num, num, num, 255]

	num = int(random()*255)
	nla.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	nla.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	nla.edge = [num, num, num, 255]

	num = int(random()*255)
	nla.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	nla.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	nla.edge_select = [num, num, num, 255]

	num = int(random()*255)
	nla.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	nla.effect = [num, num, num, 255]

	num = int(random()*255)
	nla.face = [num, num, num, 255]

	num = int(random()*255)
	nla.face_dot = [num, num, num, 255]

	num = int(random()*255)
	nla.face_select = [num, num, num, 255]
	nla.facedot_size = int(random() * 10)

	num = int(random()*255)
	nla.grid = [num, num, num, 255]

	num = int(random()*255)
	nla.group = [num, num, num, 255]

	num = int(random()*255)
	nla.group_active = [num, num, num, 255]

	num = int(random()*255)
	nla.header = [num, num, num, 255]

	num = int(random()*255)
	nla.hilite = [num, num, num, 255]

	num = int(random()*255)
	nla.image = [num, num, num, 255]

	num = int(random()*255)
	nla.lamp = [num, num, num, 255]

	num = int(random()*255)
	nla.meta = [num, num, num, 255]

	num = int(random()*255)
	nla.movie = [num, num, num, 255]

	num = int(random()*255)
	nla.normal = [num, num, num, 255]

	num = int(random()*255)
	nla.panel = [num, num, num, 255]

	num = int(random()*255)
	nla.plugin = [num, num, num, 255]

	num = int(random()*255)
	nla.scene = [num, num, num, 255]

	num = int(random()*255)
	nla.select = [num, num, num, 255]

	num = int(random()*255)
	nla.shade1 = [num, num, num, 255]

	num = int(random()*255)
	nla.shade2 = [num, num, num, 255]

	num = int(random()*255)
	nla.strip = [num, num, num, 255]

	num = int(random()*255)
	nla.strip_select = [num, num, num, 255]

	num = int(random()*255)
	nla.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	nla.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	nla.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	nla.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	nla.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	nla.text = [num, num, num, 255]

	num = int(random()*255)
	nla.text_hi = [num, num, num, 255]

	num = int(random()*255)
	nla.transform = [num, num, num, 255]

	num = int(random()*255)
	nla.transition = [num, num, num, 255]

	num = int(random()*255)
	nla.vertex = [num, num, num, 255]

	num = int(random()*255)
	nla.vertex_select = [num, num, num, 255]
	nla.vertex_size = int(random() * 10)

	num = int(random()*255)
	nla.wire = [num, num, num, 255]
	seq = theme.get('seq')

	num = int(random()*255)
	seq.active = [num, num, num, 255]

	num = int(random()*255)
	seq.audio = [num, num, num, 255]

	num = int(random()*255)
	seq.back = [num, num, num, 255]

	num = int(random()*255)
	seq.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	seq.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	seq.edge = [num, num, num, 255]

	num = int(random()*255)
	seq.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	seq.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	seq.edge_select = [num, num, num, 255]

	num = int(random()*255)
	seq.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	seq.effect = [num, num, num, 255]

	num = int(random()*255)
	seq.face = [num, num, num, 255]

	num = int(random()*255)
	seq.face_dot = [num, num, num, 255]

	num = int(random()*255)
	seq.face_select = [num, num, num, 255]
	seq.facedot_size = int(random() * 10)

	num = int(random()*255)
	seq.grid = [num, num, num, 255]

	num = int(random()*255)
	seq.group = [num, num, num, 255]

	num = int(random()*255)
	seq.group_active = [num, num, num, 255]

	num = int(random()*255)
	seq.header = [num, num, num, 255]

	num = int(random()*255)
	seq.hilite = [num, num, num, 255]

	num = int(random()*255)
	seq.image = [num, num, num, 255]

	num = int(random()*255)
	seq.lamp = [num, num, num, 255]

	num = int(random()*255)
	seq.meta = [num, num, num, 255]

	num = int(random()*255)
	seq.movie = [num, num, num, 255]

	num = int(random()*255)
	seq.normal = [num, num, num, 255]

	num = int(random()*255)
	seq.panel = [num, num, num, 255]

	num = int(random()*255)
	seq.plugin = [num, num, num, 255]

	num = int(random()*255)
	seq.scene = [num, num, num, 255]

	num = int(random()*255)
	seq.select = [num, num, num, 255]

	num = int(random()*255)
	seq.shade1 = [num, num, num, 255]

	num = int(random()*255)
	seq.shade2 = [num, num, num, 255]

	num = int(random()*255)
	seq.strip = [num, num, num, 255]

	num = int(random()*255)
	seq.strip_select = [num, num, num, 255]

	num = int(random()*255)
	seq.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	seq.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	seq.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	seq.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	seq.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	seq.text = [num, num, num, 255]

	num = int(random()*255)
	seq.text_hi = [num, num, num, 255]

	num = int(random()*255)
	seq.transform = [num, num, num, 255]

	num = int(random()*255)
	seq.transition = [num, num, num, 255]

	num = int(random()*255)
	seq.vertex = [num, num, num, 255]

	num = int(random()*255)
	seq.vertex_select = [num, num, num, 255]
	seq.vertex_size = int(random() * 10)

	num = int(random()*255)
	seq.wire = [num, num, num, 255]
	image = theme.get('image')

	num = int(random()*255)
	image.active = [num, num, num, 255]

	num = int(random()*255)
	image.audio = [num, num, num, 255]

	num = int(random()*255)
	image.back = [num, num, num, 255]

	num = int(random()*255)
	image.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	image.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	image.edge = [num, num, num, 255]

	num = int(random()*255)
	image.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	image.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	image.edge_select = [num, num, num, 255]

	num = int(random()*255)
	image.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	image.effect = [num, num, num, 255]

	num = int(random()*255)
	image.face = [num, num, num, 255]

	num = int(random()*255)
	image.face_dot = [num, num, num, 255]

	num = int(random()*255)
	image.face_select = [num, num, num, 255]
	image.facedot_size = int(random() * 10)

	num = int(random()*255)
	image.grid = [num, num, num, 255]

	num = int(random()*255)
	image.group = [num, num, num, 255]

	num = int(random()*255)
	image.group_active = [num, num, num, 255]

	num = int(random()*255)
	image.header = [num, num, num, 255]

	num = int(random()*255)
	image.hilite = [num, num, num, 255]

	num = int(random()*255)
	image.image = [num, num, num, 255]

	num = int(random()*255)
	image.lamp = [num, num, num, 255]

	num = int(random()*255)
	image.meta = [num, num, num, 255]

	num = int(random()*255)
	image.movie = [num, num, num, 255]

	num = int(random()*255)
	image.normal = [num, num, num, 255]

	num = int(random()*255)
	image.panel = [num, num, num, 255]

	num = int(random()*255)
	image.plugin = [num, num, num, 255]

	num = int(random()*255)
	image.scene = [num, num, num, 255]

	num = int(random()*255)
	image.select = [num, num, num, 255]

	num = int(random()*255)
	image.shade1 = [num, num, num, 255]

	num = int(random()*255)
	image.shade2 = [num, num, num, 255]

	num = int(random()*255)
	image.strip = [num, num, num, 255]

	num = int(random()*255)
	image.strip_select = [num, num, num, 255]

	num = int(random()*255)
	image.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	image.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	image.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	image.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	image.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	image.text = [num, num, num, 255]

	num = int(random()*255)
	image.text_hi = [num, num, num, 255]

	num = int(random()*255)
	image.transform = [num, num, num, 255]

	num = int(random()*255)
	image.transition = [num, num, num, 255]

	num = int(random()*255)
	image.vertex = [num, num, num, 255]

	num = int(random()*255)
	image.vertex_select = [num, num, num, 255]
	image.vertex_size = int(random() * 10)

	num = int(random()*255)
	image.wire = [num, num, num, 255]
	imasel = theme.get('imasel')

	num = int(random()*255)
	imasel.active = [num, num, num, 255]

	num = int(random()*255)
	imasel.audio = [num, num, num, 255]

	num = int(random()*255)
	imasel.back = [num, num, num, 255]

	num = int(random()*255)
	imasel.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	imasel.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	imasel.edge = [num, num, num, 255]

	num = int(random()*255)
	imasel.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	imasel.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	imasel.edge_select = [num, num, num, 255]

	num = int(random()*255)
	imasel.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	imasel.effect = [num, num, num, 255]

	num = int(random()*255)
	imasel.face = [num, num, num, 255]

	num = int(random()*255)
	imasel.face_dot = [num, num, num, 255]

	num = int(random()*255)
	imasel.face_select = [num, num, num, 255]
	imasel.facedot_size = int(random() * 10)

	num = int(random()*255)
	imasel.grid = [num, num, num, 255]

	num = int(random()*255)
	imasel.group = [num, num, num, 255]

	num = int(random()*255)
	imasel.group_active = [num, num, num, 255]

	num = int(random()*255)
	imasel.header = [num, num, num, 255]

	num = int(random()*255)
	imasel.hilite = [num, num, num, 255]

	num = int(random()*255)
	imasel.image = [num, num, num, 255]

	num = int(random()*255)
	imasel.lamp = [num, num, num, 255]

	num = int(random()*255)
	imasel.meta = [num, num, num, 255]

	num = int(random()*255)
	imasel.movie = [num, num, num, 255]

	num = int(random()*255)
	imasel.normal = [num, num, num, 255]

	num = int(random()*255)
	imasel.panel = [num, num, num, 255]

	num = int(random()*255)
	imasel.plugin = [num, num, num, 255]

	num = int(random()*255)
	imasel.scene = [num, num, num, 255]

	num = int(random()*255)
	imasel.select = [num, num, num, 255]

	num = int(random()*255)
	imasel.shade1 = [num, num, num, 255]

	num = int(random()*255)
	imasel.shade2 = [num, num, num, 255]

	num = int(random()*255)
	imasel.strip = [num, num, num, 255]

	num = int(random()*255)
	imasel.strip_select = [num, num, num, 255]

	num = int(random()*255)
	imasel.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	imasel.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	imasel.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	imasel.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	imasel.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	imasel.text = [num, num, num, 255]

	num = int(random()*255)
	imasel.text_hi = [num, num, num, 255]

	num = int(random()*255)
	imasel.transform = [num, num, num, 255]

	num = int(random()*255)
	imasel.transition = [num, num, num, 255]

	num = int(random()*255)
	imasel.vertex = [num, num, num, 255]

	num = int(random()*255)
	imasel.vertex_select = [num, num, num, 255]
	imasel.vertex_size = int(random() * 10)

	num = int(random()*255)
	imasel.wire = [num, num, num, 255]
	text = theme.get('text')

	num = int(random()*255)
	text.active = [num, num, num, 255]

	num = int(random()*255)
	text.audio = [num, num, num, 255]

	num = int(random()*255)
	text.back = [num, num, num, 255]

	num = int(random()*255)
	text.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	text.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	text.edge = [num, num, num, 255]

	num = int(random()*255)
	text.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	text.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	text.edge_select = [num, num, num, 255]

	num = int(random()*255)
	text.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	text.effect = [num, num, num, 255]

	num = int(random()*255)
	text.face = [num, num, num, 255]

	num = int(random()*255)
	text.face_dot = [num, num, num, 255]

	num = int(random()*255)
	text.face_select = [num, num, num, 255]
	text.facedot_size = int(random() * 10)

	num = int(random()*255)
	text.grid = [num, num, num, 255]

	num = int(random()*255)
	text.group = [num, num, num, 255]

	num = int(random()*255)
	text.group_active = [num, num, num, 255]

	num = int(random()*255)
	text.header = [num, num, num, 255]

	num = int(random()*255)
	text.hilite = [num, num, num, 255]

	num = int(random()*255)
	text.image = [num, num, num, 255]

	num = int(random()*255)
	text.lamp = [num, num, num, 255]

	num = int(random()*255)
	text.meta = [num, num, num, 255]

	num = int(random()*255)
	text.movie = [num, num, num, 255]

	num = int(random()*255)
	text.normal = [num, num, num, 255]

	num = int(random()*255)
	text.panel = [num, num, num, 255]

	num = int(random()*255)
	text.plugin = [num, num, num, 255]

	num = int(random()*255)
	text.scene = [num, num, num, 255]

	num = int(random()*255)
	text.select = [num, num, num, 255]

	num = int(random()*255)
	text.shade1 = [num, num, num, 255]

	num = int(random()*255)
	text.shade2 = [num, num, num, 255]

	num = int(random()*255)
	text.strip = [num, num, num, 255]

	num = int(random()*255)
	text.strip_select = [num, num, num, 255]

	num = int(random()*255)
	text.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	text.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	text.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	text.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	text.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	text.text = [num, num, num, 255]

	num = int(random()*255)
	text.text_hi = [num, num, num, 255]

	num = int(random()*255)
	text.transform = [num, num, num, 255]

	num = int(random()*255)
	text.transition = [num, num, num, 255]

	num = int(random()*255)
	text.vertex = [num, num, num, 255]

	num = int(random()*255)
	text.vertex_select = [num, num, num, 255]
	text.vertex_size = int(random() * 10)

	num = int(random()*255)
	text.wire = [num, num, num, 255]
	oops = theme.get('oops')

	num = int(random()*255)
	oops.active = [num, num, num, 255]

	num = int(random()*255)
	oops.audio = [num, num, num, 255]

	num = int(random()*255)
	oops.back = [num, num, num, 255]

	num = int(random()*255)
	oops.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	oops.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	oops.edge = [num, num, num, 255]

	num = int(random()*255)
	oops.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	oops.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	oops.edge_select = [num, num, num, 255]

	num = int(random()*255)
	oops.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	oops.effect = [num, num, num, 255]

	num = int(random()*255)
	oops.face = [num, num, num, 255]

	num = int(random()*255)
	oops.face_dot = [num, num, num, 255]

	num = int(random()*255)
	oops.face_select = [num, num, num, 255]
	oops.facedot_size = int(random() * 10)

	num = int(random()*255)
	oops.grid = [num, num, num, 255]

	num = int(random()*255)
	oops.group = [num, num, num, 255]

	num = int(random()*255)
	oops.group_active = [num, num, num, 255]

	num = int(random()*255)
	oops.header = [num, num, num, 255]

	num = int(random()*255)
	oops.hilite = [num, num, num, 255]

	num = int(random()*255)
	oops.image = [num, num, num, 255]

	num = int(random()*255)
	oops.lamp = [num, num, num, 255]

	num = int(random()*255)
	oops.meta = [num, num, num, 255]

	num = int(random()*255)
	oops.movie = [num, num, num, 255]

	num = int(random()*255)
	oops.normal = [num, num, num, 255]

	num = int(random()*255)
	oops.panel = [num, num, num, 255]

	num = int(random()*255)
	oops.plugin = [num, num, num, 255]

	num = int(random()*255)
	oops.scene = [num, num, num, 255]

	num = int(random()*255)
	oops.select = [num, num, num, 255]

	num = int(random()*255)
	oops.shade1 = [num, num, num, 255]

	num = int(random()*255)
	oops.shade2 = [num, num, num, 255]

	num = int(random()*255)
	oops.strip = [num, num, num, 255]

	num = int(random()*255)
	oops.strip_select = [num, num, num, 255]

	num = int(random()*255)
	oops.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	oops.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	oops.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	oops.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	oops.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	oops.text = [num, num, num, 255]

	num = int(random()*255)
	oops.text_hi = [num, num, num, 255]

	num = int(random()*255)
	oops.transform = [num, num, num, 255]

	num = int(random()*255)
	oops.transition = [num, num, num, 255]

	num = int(random()*255)
	oops.vertex = [num, num, num, 255]

	num = int(random()*255)
	oops.vertex_select = [num, num, num, 255]
	oops.vertex_size = int(random() * 10)

	num = int(random()*255)
	oops.wire = [num, num, num, 255]
	time = theme.get('time')

	num = int(random()*255)
	time.active = [num, num, num, 255]

	num = int(random()*255)
	time.audio = [num, num, num, 255]

	num = int(random()*255)
	time.back = [num, num, num, 255]

	num = int(random()*255)
	time.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	time.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	time.edge = [num, num, num, 255]

	num = int(random()*255)
	time.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	time.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	time.edge_select = [num, num, num, 255]

	num = int(random()*255)
	time.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	time.effect = [num, num, num, 255]

	num = int(random()*255)
	time.face = [num, num, num, 255]

	num = int(random()*255)
	time.face_dot = [num, num, num, 255]

	num = int(random()*255)
	time.face_select = [num, num, num, 255]
	time.facedot_size = int(random() * 10)

	num = int(random()*255)
	time.grid = [num, num, num, 255]

	num = int(random()*255)
	time.group = [num, num, num, 255]

	num = int(random()*255)
	time.group_active = [num, num, num, 255]

	num = int(random()*255)
	time.header = [num, num, num, 255]

	num = int(random()*255)
	time.hilite = [num, num, num, 255]

	num = int(random()*255)
	time.image = [num, num, num, 255]

	num = int(random()*255)
	time.lamp = [num, num, num, 255]

	num = int(random()*255)
	time.meta = [num, num, num, 255]

	num = int(random()*255)
	time.movie = [num, num, num, 255]

	num = int(random()*255)
	time.normal = [num, num, num, 255]

	num = int(random()*255)
	time.panel = [num, num, num, 255]

	num = int(random()*255)
	time.plugin = [num, num, num, 255]

	num = int(random()*255)
	time.scene = [num, num, num, 255]

	num = int(random()*255)
	time.select = [num, num, num, 255]

	num = int(random()*255)
	time.shade1 = [num, num, num, 255]

	num = int(random()*255)
	time.shade2 = [num, num, num, 255]

	num = int(random()*255)
	time.strip = [num, num, num, 255]

	num = int(random()*255)
	time.strip_select = [num, num, num, 255]

	num = int(random()*255)
	time.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	time.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	time.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	time.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	time.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	time.text = [num, num, num, 255]

	num = int(random()*255)
	time.text_hi = [num, num, num, 255]

	num = int(random()*255)
	time.transform = [num, num, num, 255]

	num = int(random()*255)
	time.transition = [num, num, num, 255]

	num = int(random()*255)
	time.vertex = [num, num, num, 255]

	num = int(random()*255)
	time.vertex_select = [num, num, num, 255]
	time.vertex_size = int(random() * 10)

	num = int(random()*255)
	time.wire = [num, num, num, 255]
	node = theme.get('node')

	num = int(random()*255)
	node.active = [num, num, num, 255]

	num = int(random()*255)
	node.audio = [num, num, num, 255]

	num = int(random()*255)
	node.back = [num, num, num, 255]

	num = int(random()*255)
	node.bone_pose = [num, num, num, 255]

	num = int(random()*255)
	node.bone_solid = [num, num, num, 255]

	num = int(random()*255)
	node.edge = [num, num, num, 255]

	num = int(random()*255)
	node.edge_facesel = [num, num, num, 255]

	num = int(random()*255)
	node.edge_seam = [num, num, num, 255]

	num = int(random()*255)
	node.edge_select = [num, num, num, 255]

	num = int(random()*255)
	node.edge_sharp = [num, num, num, 255]

	num = int(random()*255)
	node.effect = [num, num, num, 255]

	num = int(random()*255)
	node.face = [num, num, num, 255]

	num = int(random()*255)
	node.face_dot = [num, num, num, 255]

	num = int(random()*255)
	node.face_select = [num, num, num, 255]
	node.facedot_size = int(random() * 10)

	num = int(random()*255)
	node.grid = [num, num, num, 255]

	num = int(random()*255)
	node.group = [num, num, num, 255]

	num = int(random()*255)
	node.group_active = [num, num, num, 255]

	num = int(random()*255)
	node.header = [num, num, num, 255]

	num = int(random()*255)
	node.hilite = [num, num, num, 255]

	num = int(random()*255)
	node.image = [num, num, num, 255]

	num = int(random()*255)
	node.lamp = [num, num, num, 255]

	num = int(random()*255)
	node.meta = [num, num, num, 255]

	num = int(random()*255)
	node.movie = [num, num, num, 255]

	num = int(random()*255)
	node.normal = [num, num, num, 255]

	num = int(random()*255)
	node.panel = [num, num, num, 255]

	num = int(random()*255)
	node.plugin = [num, num, num, 255]

	num = int(random()*255)
	node.scene = [num, num, num, 255]

	num = int(random()*255)
	node.select = [num, num, num, 255]

	num = int(random()*255)
	node.shade1 = [num, num, num, 255]

	num = int(random()*255)
	node.shade2 = [num, num, num, 255]

	num = int(random()*255)
	node.strip = [num, num, num, 255]

	num = int(random()*255)
	node.strip_select = [num, num, num, 255]

	num = int(random()*255)
	node.syntaxb = [num, num, num, 255]

	num = int(random()*255)
	node.syntaxc = [num, num, num, 255]

	num = int(random()*255)
	node.syntaxl = [num, num, num, 255]

	num = int(random()*255)
	node.syntaxn = [num, num, num, 255]

	num = int(random()*255)
	node.syntaxv = [num, num, num, 255]

	num = int(random()*255)
	node.text = [num, num, num, 255]

	num = int(random()*255)
	node.text_hi = [num, num, num, 255]

	num = int(random()*255)
	node.transform = [num, num, num, 255]

	num = int(random()*255)
	node.transition = [num, num, num, 255]

	num = int(random()*255)
	node.vertex = [num, num, num, 255]

	num = int(random()*255)
	node.vertex_select = [num, num, num, 255]
	node.vertex_size = int(random() * 10)

	num = int(random()*255)
	node.wire = [num, num, num, 255]

else:
	ui = theme.get('ui')
	ui.action = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.drawType = int(random() * 4)
	ui.menu_back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.menu_hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.menu_item = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.menu_text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.menu_text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.neutral = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.num = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.outline = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.popup = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.setting = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.setting1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.setting2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.textfield = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ui.textfield_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts = theme.get('buts')
	buts.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.facedot_size = int(random() * 10)
	buts.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	buts.vertex_size = int(random() * 10)
	buts.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d = theme.get('view3d')
	view3d.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.facedot_size = int(random() * 10)
	view3d.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	view3d.vertex_size = int(random() * 10)
	view3d.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file = theme.get('file')
	file.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.facedot_size = int(random() * 10)
	file.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	file.vertex_size = int(random() * 10)
	file.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo = theme.get('ipo')
	ipo.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.facedot_size = int(random() * 10)
	ipo.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	ipo.vertex_size = int(random() * 10)
	ipo.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info = theme.get('info')
	info.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.facedot_size = int(random() * 10)
	info.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	info.vertex_size = int(random() * 10)
	info.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound = theme.get('sound')
	sound.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.facedot_size = int(random() * 10)
	sound.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	sound.vertex_size = int(random() * 10)
	sound.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action = theme.get('action')
	action.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.facedot_size = int(random() * 10)
	action.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	action.vertex_size = int(random() * 10)
	action.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla = theme.get('nla')
	nla.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.facedot_size = int(random() * 10)
	nla.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	nla.vertex_size = int(random() * 10)
	nla.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq = theme.get('seq')
	seq.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.facedot_size = int(random() * 10)
	seq.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	seq.vertex_size = int(random() * 10)
	seq.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image = theme.get('image')
	image.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.facedot_size = int(random() * 10)
	image.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	image.vertex_size = int(random() * 10)
	image.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel = theme.get('imasel')
	imasel.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.facedot_size = int(random() * 10)
	imasel.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	imasel.vertex_size = int(random() * 10)
	imasel.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text = theme.get('text')
	text.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.facedot_size = int(random() * 10)
	text.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	text.vertex_size = int(random() * 10)
	text.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops = theme.get('oops')
	oops.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.facedot_size = int(random() * 10)
	oops.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	oops.vertex_size = int(random() * 10)
	oops.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time = theme.get('time')
	time.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.facedot_size = int(random() * 10)
	time.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	time.vertex_size = int(random() * 10)
	time.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node = theme.get('node')
	node.active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.audio = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.back = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.bone_pose = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.bone_solid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.edge = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.edge_facesel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.edge_seam = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.edge_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.edge_sharp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.effect = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.face = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.face_dot = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.face_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.facedot_size = int(random() * 10)
	node.grid = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.group = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.group_active = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.header = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.hilite = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.image = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.lamp = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.meta = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.movie = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.normal = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.panel = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.plugin = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.scene = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.shade1 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.shade2 = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.strip = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.strip_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.syntaxb = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.syntaxc = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.syntaxl = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.syntaxn = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.syntaxv = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.text = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.text_hi = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.transform = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.transition = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.vertex = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.vertex_select = [int(random() * 255), int(random() * 255), int(random() * 255), 255]
	node.vertex_size = int(random() * 10)
	node.wire = [int(random() * 255), int(random() * 255), int(random() * 255), 255]

Blender.Redraw(-1)